#!/bin/bash

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then
   printf "\n\n*************** Please run as root ***************\n\n\n"
   exit 1
fi

HDIR="/home/${SUDO_USER}"
LOG="${HDIR}/update.log"
ValidOS="DEBIAN,ALPINE,VOID,ARCH"
VER="3.47"

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release >>$LOG 2>&1
   REALOS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   REALOS=$( uname )
fi
  
OS="UNKNOWN"
case ${REALOS^^} in
    DEBIAN)      OS="DEBIAN" ;;
    ELEMENTARY)  OS="DEBIAN" ;;
    BUNSENLABS)  OS="DEBIAN" ;;
    LINUXMINT)   OS="DEBIAN" ;;
    SPARKY)      OS="DEBIAN" ;;
    UBUNTU)      OS="DEBIAN" ;;
    LBUNTU)      OS="DEBIAN" ;;
    XBUNTU)      OS="DEBIAN" ;;
    ZORIN)       OS="DEBIAN" ;;
    ALPINE)      OS="ALPINE" ;;
    VOID)        OS="VOID" ;;
	 ARCH)        OS="ARCH" ;;
	 ARTIX)       OS="ARCH" ;;
	 MANJARO)     OS="ARCH" ;;
esac  

# Operating system must be one of the valid ones
if [[ ${ValidOS^^} != *${OS^^}* ]]; then
   printf "\n\n********** [${REALOS^^}] Is An Invalid OS. *******\n\n\n";
   exit 1
fi

if [[ ! -d /$HDIR/scripts ]]; then
   printf "\n\n********** Script Directory does NOT exist. *******\n\n\n";
   exit 1
fi

# Ensure we have the proper working directories
cd /$HDIR/scripts
if [[ ! -d /$HDIR/scripts/skipdir ]]; then mkdir /$HDIR/scripts/skipdir; fi

# Include the proper source files
source base.sh
case ${OS^^} in
  'ALPINE') source alpine.sh ;;
    'ARCH') source arch.sh ;;
    'VOID') source void.sh ;;
  'DEBIAN') source debian.sh ;;
esac

# Detect if device is a laptop
_run "xbps-install -y dmidecode"
DEVICE=$(dmidecode -s chassis-type)
DEVTYPE=${DEVICE^^}
case ${DEVTYPE^^} in
  'NOTEBOOK') DEVTYPE="LAPTOP" ;;
  'PORTABLE') DEVTYPE="LAPTOP" ;;
  'HAND HELD') DEVTYPE="LAPTOP" ;;
  'SUB NOTEBOOK') DEVTYPE="LAPTOP" ;;
esac

# Get Memory Size
MEMSIZE=$(dmidecode | grep 'Maximum Capacity:' | cut -d ' ' -f3)

# Get Desktop Environment
DSKTOPENV=$(echo "$XDG_CURRENT_DESKTOP")
case ${DSKTOPENV^^} in
   'X-CINNAMON') DSKTOPENV="CINNAMON" ;;
esac

# Write header to Log File
log-msg "OS=${OS}, REALOS=${REALOS^^}"
log-msg "DEVICE=${DEVICE}"
log-msg "DEVTYPE=${DEVTYPE}"
log-msg "MEMSIZE=${MEMSIZE}"
log-msg "DSKTOPENV=${DSKTOPENV}"

#=======================================
# Main Code - Start
#=======================================
_title
if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
_run "touch ${LOG}"
_run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

# === Install Prerequisites ===
if [[ ! -f $HDIR/scripts/skipdir/.prereq ]]; then 
   printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n";
   _prereqs;  
fi

# === Process Main Menu ===
while [[ ${STP^^} != "99" ]]
do
   _main_menu
   case ${STP^^} in
      1) _main_desktop ;;
      2) _main_server ;;
      3) _process_update ;;
     99) break ;;
   esac
   if [ ${STP^^} != "99" ]; then STP="777"; fi
done 



