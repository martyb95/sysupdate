
Thanks for downloading 

Catalinas - Octo Edition - Cool Version ... from Cupertino Series
    
Created	by PT_Alfred
 
 
-------------

FIND ME AT...

Mastodon: https://mastodon.art/@PTAlfred

Pixelfed: https://pixelfed.social/ptalfred


-------------

LICENSE

This work is licensed under:

CC BY NC ND
Creative Commons - Attribution - Non commercial - No Derivative Works  4.0 License
https://creativecommons.org/licenses/by-nc-nd/4.0/


