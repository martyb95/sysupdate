#!/bin/bash

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then
   printf "\n\n*************** Please run as root ***************\n\n\n"
   exit 1
fi

apk add sudo bash xz curl shadow
sh <(curl -L https://nixos.org/nix/install) --daemon
rm -f /etc/init.d/nix-daemon
touch /etc/init.d/nix-daemon
echo '#!/sbin/openrc-run' >> /etc/init.d/nix-daemon
echo 'description="Nix multi-user support daemon"' >> /etc/init.d/nix-daemon
echo ' ' >> /etc/init.d/nix-daemon
echo 'command="/usr/sbin/nix-daemon"' >> /etc/init.d/nix-daemon
echo 'command_background="yes"' >> /etc/init.d/nix-daemon
echo 'pidfile="/run/$RC_SVCNAME.pid"' >> /etc/init.d/nix-daemon
chmod a+rx /etc/init.d/nix-daemon
cp /root/.nix-profile/bin/nix-daemon /usr/sbin
rc-update add nix-daemon
rc-service nix-daemon start
adduser ${SUDO_USER} nixbld