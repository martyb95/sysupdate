#!/bin/bash

#docker ps | grep "portainer" | tail -c 25 |sed s'/ //g'
while IFS= read -a LINE ; do {  # reads single/one line
   ID=$(echo "${LINE}" |head -c 14 |sed s'/ //g');
   if [[ ${ID^^} != "CONTAINERID" ]]; then
      CNAME=$(echo "${LINE}" |tail -c 16 |sed s'/ //g' |sed s'#880/tcp##g');
      printf "$ID   $CNAME\n"
   fi
};
done < <(docker ps);
unset oL;