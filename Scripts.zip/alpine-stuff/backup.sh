#!/bin/ash

LOG=/home/martin/backup.log

if [[ -f $LOG ]]; then rm -f $LOG; fi

printf "+=========================================+\n" >$LOG
printf "|                                         |\n" >>$LOG
printf "|    Docker01 Backup of Containers        |\n" >>$LOG
printf "|       Started: $(date +'%D %T')        |\n" >>$LOG
printf "|                                         |\n" >>$LOG
printf "+=========================================+\n\n\n" >>$LOG

printf "=== Stopping Docker Containers ===\n" >>$LOG
docker stop $(docker ps -a -q) >>$LOG 2>&1

printf "\n\n=== Setting Permissions on Docker Containers ===\n" >>$LOG
chown -R martin:docker /home/martin/docker/  >>$LOG 2>&1 
chmod -R 777 /home/martin/docker/ >>$LOG 2>&1

printf "\n\n=== Backing Up Docker Containers ===\n" >>$LOG
rclone sync --ignore-case-sync --checkers 4 --transfers 4 /home/martin/docker mb-nas:/Docker01 >>$LOG 2>&1

printf "\n\n=== Restarting Docker Containers ===\n" >>$LOG
docker start $(docker ps -a -q) >>$LOG 2>&1

chown martin:docker $LOG >>$LOG 2>&1

printf "\n\n+=========================================+\n" >>$LOG
printf "|                                         |\n" >>$LOG
printf "|     Completed: $(date +'%D %T')        |\n" >>$LOG
printf "|                                         |\n" >>$LOG
printf "+=========================================+\n\n\n" >>$LOG
