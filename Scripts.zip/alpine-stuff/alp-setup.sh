#!/bin/bash

# script must be run as root
if [[ $(id -u) -ne 0 ]]; then 
   printf "\n\n*************** Please run as root ***************\n\n\n"
   exit 1
fi

HDIR="/home/${SUDO_USER}"
LOG="${HDIR}/update.log"

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release >>$LOG 2>&1
   OS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   OS=$( uname )
fi

if [[ ${OS^^} != "ALPINE" ]]; then 
   printf "\n\n********** [${OS^^}] Is An Invalid OS.  Should be Alpine Linux *******\n\n\n"
   exit 1
fi

#=======================================
# Initialize Variables
#=======================================
TASK=""
REPLY=""
DSK="777"
STP="777"


#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'
LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'
OVERWRITE='\e[1A\e[K'

PS1="\[\033[0;31m\]\342\224\214\342\224\200\[\[\033[0;39m\]\u\[\033[01;33m\]@\[\033[01;96m\]\h\[\033[0;31m\]]\342\224\200[\[\033[0;32m\]\w\[\033[0;31m\]]\n\[\033[0;31m\]\342\224\224\342\224\200\342\224\200\342\224\200 \[\033[0m\]\[\e[01;33m\]\\$\[\e[0m\] "
ADDList+=("gnome-software-plugin-apk" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "htop")
DELList=("xterm" "xfce4-terminal" "firefox" "evolution-data-server")
APPList+=("=== Choose System Tools ===||"
          "Clam Anti Virus|clamav|N"
          "Disk Utility|gnome-disk-utility|Y" 
          "Gnome Software Manager|gnome-software|Y"
          "gParted Disk Partioning|gparted|Y"
          "LX Terminal|lxterminal|Y"
          "Neofetch|neofetch|Y"
          "Putty SSH Utility|putty|N"
          "WINE|wine|N"
          "=== Choose Virtualization Tools ===||"
          "DistroBox|distrobox|N"
          "Gnome Boxes|gnome-boxes|Y"
          "Vir-Manager|virt-manager|N"
          "=== Choose Browser(s) ===||"
          "Chromium|chromium|Y"
          "FireFox|firefox|N"
          "=== Choose Office Tools ===||"
          "Abiword Word Processor|abiword|Y"
          "Geary Email Client|geary|N"
		  "Gnome Editor|gedit|Y"
          "Gnome Calendar|gnome-calendar|Y"
          "Gnome Calculator|gnome-calculator|Y"
          "gNumeric Spreadsheet|gnumeric|Y"
          "Libre Office|libreoffice|N"
          "=== Choose Applications ===||"
          "Cheese Camera Utility|cheese|N"
          "gThumb Image Viewer|gthumb|Y"
          "Kodi Media Center|kodi|N"
          "Mousepad Notepad Utility|mousepad|Y"
          "Spotify Client|spotify-qt|N"
          "VLC Media Player|vlc|Y")				

#========================================================
#    Input Functions
#========================================================
function _Ask(){
  if  [[ ${2} != "" ]]; then
    printf "${LGREEN}${1} ${YELLOW}[${2}]: ${RESTORE}"
    read REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="${2}" ; fi
  else
    printf "${LGREEN}${1}: ${RESTORE}"
    read REPLY
  fi
  REPLY=${REPLY^^}
}

function _AskYN(){
  local __flg="N"
  while [[ ${__flg} == "N" ]]
  do
    printf "${LGREEN}${1}? ${YELLOW}[${2}]: ${RESTORE}"
    read -n 1 REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="$2" ; else echo " "; fi

    case ${REPLY^^} in
      [Y]* ) __flg="Y";;
      [N]* ) __flg="Y";;
      [R]* ) __flg="Y";;
      * ) printf "${RED}ERROR - Invalid Option Entered [Y/N]${RESTORE}\n\n"; __flg="N";;
    esac
  done
  REPLY=${REPLY^^}
}

function _chooser() {
   if [ ${#APPList[@]} -gt 0 ]; then
     for i in {0..999}; do
        if (( i == ${#APPList[@]} )); then break; fi
        IFS='|' read -ra arr <<< "${APPList[i]}"
        if [ ${#arr[@]} -gt 0 ]; then
          FLG="I"
          if [[ "${arr[0]}" =~ ^"===" ]]; then FLG="H"; fi
          
          case ${FLG^^} in
            [I]*)
	              if (( $(_exists "${arr[1]}") == 0 )); then
                     _AskYN "Install ${arr[0]}${LGREEN} (y/n/r)" ${arr[2]^^}
	              else
                     _AskYN "Install $LRED${arr[0]}$RESTORE (y/n/r)" ${arr[2]^^}
                  fi
                  _PKG_List ${REPLY^^} ${arr[1]}
                  ;;
            [H]*)
                  printf "\n${LPURPLE}${arr[0]}${RESTORE}\n"
                  ;;
          esac
        fi
     done
  fi
}


#========================================================
#    Task Functions
#========================================================
function _run() {
    local _cmd="$1 >>$LOG 2>&1"
    printf "\n==== $TASK:  $1 ====\n\n" >> $LOG
    eval ${_cmd}
}

function _task-begin() {
   TASK=$1
   printf "\n\n============================= Start of $TASK =============================\n\n" >> ${LOG}
   printf "${LCYAN} [ ]  ${TASK} \n${LRED}"
}

function _task-end() {
   printf "\n\n============================= End of $TASK =============================\n\n" >> ${LOG}
   printf "${OVERWRITE}${LGREEN} [✓]  ${LGREEN}${TASK}${RESTORE}\n"
   TASK=""
}


#========================================================
#    Package Functions
#========================================================
function _exists() {
  local VAL=$(apk list -I ${1} 2>/dev/null | grep -c "${1}")
  printf "%u" ${VAL}
}

function _PKG_List() {
  local _Ans=${1^^}
  local _Pkg=${2}
  
  case ${_Ans^^} in
     Y) ADDList+=(${_Pkg}) ;;
     R) if [ ${_Pkg^^} == "CLAMAV" ]; then _Pkg="clam*"; fi
	    if [ ${_Pkg^^} == "LIBREOFFICE" ]; then _Pkg="libreoffice*"; fi
        if [ ${_Pkg^^} == "WINEHQ-STABLE" ]; then _Pkg="wine*"; fi
        if [ ${_Pkg^^} == "WINE" ]; then _Pkg="wine*"; fi
        DELList+=(${_Pkg})
       ;;
  esac  
}

function _add_pkg() {
  if (( $(_exists $1) == 0 )); then 
     _task-begin "Installing ${1^^}"
     _run "apk add --upgrade $1"; 
     _task-end
  fi
}

function _add_by_list() {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
          _add_pkg ${_pkg}
    done
  fi
}

function _del_pkg() {
  if (( $(_exists $1) > 0 )); then  
    _task-begin "Removing ${1^^}"
    _run "apk del $1"
    _task-end
  fi
}

function _del_by_list() {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
      _del_pkg ${_pkg}
    done
  fi
}


#========================================================
#    Processing Functions
#========================================================
function _del_language() {
  local PList=("hunspell-de-de-frami" "hunspell-de-at-frami" "hunspell-de-ch-frami"
               "hunspell-en-au" "hunspell-en-gb" "hunspell-en-za" "hunspell-es" "hunspell-fr-classical"
               "hunspell-fr" "hunspell-it" "hunspell-pt-br" "hunspell-pt-pt" "hunspell-ru" "hunspell-en-au")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused OS Language Packs ======================
  PList=("language-pack-bg" "language-pack-ca" "language-pack-cs" "language-pack-da"
         "language-pack-de" "language-pack-es" "language-pack-fr" "language-pack-hu"
         "anguage-pack-id" "language-pack-it" "language-pack-ja" "language-pack-ko"
         "language-pack-nb" "language-pack-nl" "language-pack-pl" "language-pack-pt"
         "language-pack-ru" "language-pack-sv" "language-pack-th" "language-pack-tr"
         "language-pack-uk" "language-pack-vi" "language-pack-zh-hans" "language-pack-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused GNOME Language Packs ======================
  PList=("language-pack-gnome-bg" "language-pack-gnome-ca" "language-pack-gnome-cs" "language-pack-gnome-da"
         "language-pack-gnome-de" "language-pack-gnome-es" "language-pack-gnome-fr" "language-pack-gnome-hu"
         "language-pack-gnome-id" "language-pack-gnome-it" "language-pack-gnome-ja" "language-pack-gnome-ko"
         "language-pack-gnome-nb" "language-pack-gnome-nl" "language-pack-gnome-pl" "language-pack-gnome-pt"
         "language-pack-gnome-ru" "language-pack-gnome-sv" "language-pack-gnome-th" "language-pack-gnome-tr"
         "language-pack-gnome-uk" "language-pack-gnome-vi" "language-pack-gnome-zh-hans" "language-pack-gnome-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused Language Packs ======================
  PList=("wbrazilian" "wbritish" "wbulgarian" "wcatalan" "wdanish" "wdutch" "wfrench" "wngerman" "wnorwegian" 
         "wogerman" "wpolish" "wportuguese" "wspanish" "wswedish" "wswiss" "wukrainian")
  _del_by_list ${PList[*]}
}

function _set_swappiness() {
  #============================ Update Swap File Swappiness ===========================================
  _task-begin "Update Swap File Swappiness"
  _SWP=$(cat /etc/sysctl.conf | grep 'vm.swappiness' | cut -d "=" -f2)
  if [ -z ${_SWP} ]; then
    _run "echo 'vm.swappiness=10' | tee -a /etc/sysctl.conf"
  else
    if [ ! ${_SWP} == "10" ]; then
      _run "sed -i 's/vm.swappiness=${_SWP}/vm.swappiness=10/g' /etc/sysctl.conf"
    fi
  fi
  _task-end
}

function _install_xfce() {
  #============================ Install XFCE Desktop ============================================
  printf "\n\n${LPURPLE}=== Install XFCE Desktop  ===${RESTORE}\n"
  local PList=("xfce4-screensaver" "xfce4-clipman-plugin" "xfce4-whiskermenu-plugin"
               "lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman")
  _task-begin "Installing XFCE Desktop Components" 
  _run "setup-desktop xfce"
  _task-end
  _add_by_list ${PList[*]}
  _run "rc-update add lightdm"
}

function _install_gnome() {
  #============================ Install GNOME Desktop ============================================
  printf "\n\n${LPURPLE}=== Install Gnome Desktop  ===${RESTORE}\n"
  local PList=("lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
  _task-begin "Installing GNOME Desktop Components" 
  _run "setup-desktop gnome"
  _task-end
  _add_by_list ${PList[*]}
  _run "rc-update add lightdm"
}

function _install_mate() {
  #============================ Install MATE Desktop ============================================
  printf "\n\n${LPURPLE}=== Install MATE Desktop  ===${RESTORE}\n"
  local PList=("lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
  _task-begin "Installing MATE Desktop Components" 
  _run "setup-desktop mate"
  _task-end
  _add_by_list ${PList[*]}
  _run "rc-update add lightdm"
}

function _install_plasma() {
  #============================ Install PLASMA Desktop ============================================
  printf "\n\n${LPURPLE}=== Install PLASMA Desktop  ===${RESTORE}\n"
  local PList=("lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
  _task-begin "Installing KDE Desktop Components" 
  _run "setup-desktop plasma"
  _task-end
  _add_by_list ${PList[*]}
  _run "rc-update add lightdm"
}

function _process_step_1() {
  printf "\n  ${YELLOW}Step 1 - Install System Tools${RESTORE}\n\n"
  printf "\n${LPURPLE}=== Configure System Settings ===${RESTORE}\n"
  rm -f ${LOG} > /dev/null 2>&1

  #=============================
  # Setup Alpine Repositories
  #=============================
  _task-begin "Updating Alpine Repositories"
  local RET=$( cat /etc/apk/repositories | grep -c 'uwaterloo.ca/alpine/edge/community' )
  if [ ${RET} == 0 ]; then
     if [ ! -f /etc/apk/repositories.bak ]; then _run "mv /etc/apk/repositories /etc/apk/repositories.bak"; fi
	 _run "touch /etc/apk/repositories"
	 _run "echo 'http://mirror.csclub.uwaterloo.ca/alpine/latest-stable/main' >> /etc/apk/repositories"
	 _run "echo 'http://mirror.csclub.uwaterloo.ca/alpine/latest-stable/community' >> /etc/apk/repositories"
	 _run "echo 'http://mirror.csclub.uwaterloo.ca/alpine/edge/main' >> /etc/apk/repositories"
	 _run "echo 'http://mirror.csclub.uwaterloo.ca/alpine/edge/community' >> /etc/apk/repositories"
	 _run "echo '#http://mirror.csclub.uwaterloo.ca/alpine/edge/testing' >> /etc/apk/repositories"
  fi
  _task-end
	   
  #=============================
  # Upgrade Linux Packages
  #=============================
  _task-begin "Update System"
  _run "apk update"
  _run "apk upgrade"
  _task-end

  #=============================
  #  Setup SUDO for Users
  #=============================
  _task-begin "Setup SUDO Command"
  if (( $(_exists 'sudo') == 0 )); then
     _run "apk add sudo"
     if [ ! -f /etc/sudoers.d/wheel ]; then
	    _run "echo '%wheel ALL=(ALL) ALL' > /etc/sudoers.d/wheel"
     fi
  fi
  _task-end

  #=============================
  #  Add User to Wheel
  #=============================
  _task-begin "Add ${SUDO_USER} to SUDO Group"
  if [ $(id ${SUDO_USER} 2>/dev/null | grep -c '${SUDO_USER}') = 1 ]; then
	 if [ $(id -nG ${SUDO_USER} 2>/dev/null | grep -c 'wheel') = 0 ]; then _run "adduser ${SUDO_USER} wheel"; fi
  fi
  _task-end

  #=============================
  # Update Terminal Profile
  #=============================
  _task-begin "Update Terminal Profile"
  RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
  if [ ${RET} == 0 ]; then
     echo "PS1='${PS1}'" >> /etc/profile
	 echo "export PS1" >> /etc/profile
  fi
  _task-end

  #=============================
  # Remove MOTD
  #=============================
  _task-begin "Removing MOTD"
  if [ -f /etc/motd ]; then _run "rm /etc/motd"; fi
  _task-end	 

  #===============================
  # Install required system files
  #===============================
  printf "\n${LPURPLE}=== Update System Dependencies ===${RESTORE}\n"
  local PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi" "bash"
               "bash-completion" "bluez" "blueman" "cifs-utils" 
			   "cups" "curl" "dconf" "flatpak" "gvfs" "gvfs-fuse"
			   "gvfs-smb" "gvfs-mtp" "gvfs-nfs" "nano" "sed" "sudo"
			   "udisks2" "unzip" "wget")
  _add_by_list ${PList[*]}

  #===============================
  # Create Network Mount Points
  #===============================
  printf "\n${LPURPLE}=== Setup System Environment ===${RESTORE}\n"
  _task-begin "Create Network Mount Points"
  if [ ! -d /media/documents ]; then _run "mkdir /media/documents"; fi
  if [ ! -d /media/utilities ]; then _run "mkdir /media/utilities"; fi
  if [ ! -d /media/multimedia ]; then _run "mkdir /media/multimedia"; fi
  if [ ! -d /media/backups ]; then _run "mkdir /media/backups"; fi
  if [ ! -d /media/private ]; then _run "mkdir /media/private"; fi
  _task-end
   
  #=============================
  # Change SSH Config File
  #=============================
  if [[ -f /etc/ssh/sshd_config ]]; then
     if (( $(cat /etc/ssh/sshd_config | grep -c "9922") == 0 )); then
        _task-begin "Updating SSH Configuration"
        if [ -f /etc/ssh/sshd_config ]; then
	       _run "sed -i 's/#Port 22/Port 9922/' /etc/ssh/sshd_config"
        fi
        _task-end
	 fi
  fi
  
  #===============================
  # Create User Directories
  #===============================
  _task-begin "Create User Directories"
  if [ ! -d ${HDIR}/Documents ]; then _run "mkdir ${HDIR}/Documents"; fi
  if [ ! -d ${HDIR}/Downloads ]; then _run "mkdir ${HDIR}/Downloads"; fi
  if [ ! -d ${HDIR}/Pictures ]; then _run "mkdir ${HDIR}/Pictures"; fi
  _task-end

  #=============================
  # Install Pipewire
  #=============================
  if (( $(_exists "pipewire") == 0 )); then
     printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
     _task-begin "Set Pipewire User Groups"
     _run "addgroup ${SUDO_USER} audio"
     _run "addgroup ${SUDO_USER} video"
	 _task-end
	 local PList=("pipewire" "wireplumber" "pipewire-pulse" "pipewire-alsa" "pipewire-spa-bluez")
	 _add_by_list ${PList[*]}
  fi
  
  #==================================
  # Remove non required applications
  #==================================
  printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
  _del_by_list ${DELList[*]}

  #==================================
  # Remove Language Files
  #==================================
  printf "\n\n${LPURPLE}=== Removing Language Packs ===${RESTORE}\n"
  _del_language
  
  #==================================
  # Setup OS Environment
  #==================================
  _set_swappiness  
  
  #==================================
  # Install System Fonts
  #==================================
  printf "\n${LPURPLE}=== Install System Fonts ===${RESTORE}\n"
  PList=("font-cascadia-code-nerd" "font-dejavu-sans-mono-nerd" "font-fira-code-nerd" "font-go-mono-nerd"
         "font-hack-nerd" "font-inconsolata-nerd" "font-iosevka" "font-jetbrains-mono-nerd" 
         "font-liberation-mono-nerd" "font-mononoki-nerd" "font-noto" "font-roboto-mono" 
         "font-source-code-pro-nerd" "font-terminus-nerd" "font-ubuntu-mono-nerd" )
  _add_by_list ${PList[*]}
  
  #==================================
  # Starting Services
  #==================================
  printf "\n${LPURPLE}=== Starting Services ===${RESTORE}\n"
  _task-begin "Starting Services"
  _run "rc-update add acpid"
  _run "rc-update add avahi-daemon"
  _run "rc-update add cupsd"
  _run "rc-update add bluetooth"
  _task-end
}

function _process_step_2() {
   printf "\n  ${YELLOW}Step 2 - Install Desktop${RESTORE}\n\n"
   #=============================
   # Choose Desktop Environment
   #=============================
   printf "  ${LPURPLE}      DESKTOP ENVIRONMENT\n"
   printf "  ${LGREEN}+-------------------------------+\n"
   printf "  |                               |\n"
   printf "  |   1) XFCE Desktop             |\n"
   printf "  |   2) Gnome Desktop            |\n"
   printf "  |   3) Mate Desktop             |\n"
   printf "  |   4) Plasma Desktop           |\n"
   printf "  |                               |\n"
   printf "  |  99) NO Desktop               |\n"
   printf "  |                               |\n"
   printf "  +-------------------------------+${RESTORE}\n\n\n"
   while [[ "123499" != *${DSK}* ]]
   do
      _Ask "${OVERWRITE}Choose the Desktop Environment (1-5 or 99)" "1" && DSK=$REPLY
   done
   printf "\n\n"

   case ${DSK^^} in
      1) _install_xfce ;;
      2) _install_gnome ;;
      3) _install_mate ;;
      4) _install_plasma ;;
   esac
   printf "\n\n"  

   #==================================
   # Remove non required applications
   #==================================
   printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
  _del_by_list ${DELList[*]}

   #==================================
   # Restarting System
   #==================================
   printf "\n\n${LPURPLE}=== Restarting System - Step 2 ===${RESTORE}\n"
   _AskYN "OK to Reboot Now (y/n)" "Y"
   if [ ${REPLY^^} = "Y" ]; then reboot; fi
}

function _process_step_3() {
   printf "\n  ${YELLOW}Step 3 - Install Desktop Applications${RESTORE}\n\n"
   #==================================
   # Choose Packages to Install
   #==================================
   _chooser
   printf "\n\n"
   
   #==================================
   # Install required applications
   #==================================
   printf "\n${LPURPLE}=== Installing Required Packages ===${RESTORE}\n"
   _add_by_list ${ADDList[*]}

   
   #==================================
   # Remove non required applications
   #==================================
   printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
   _del_by_list ${DELList[*]}
}

function _process_step_4() {
   local file=""
   printf "\n  ${YELLOW}Step 4 - Install Desktop Customizations${RESTORE}\n\n"
   #===============================
   # Get Themes & Icons
   #===============================
   _task-begin "Get Themes and Icons"
   if [ ! -d ${HDIR}/sys-setup ]; then
      _run "cd ${HDIR}"
      _run "mkdir ${HDIR}/sys-setup"
   fi

   #Download file
   if [ ! -f ${HDIR}/sys-setup/sys.zip ]; then
     _run "cd ${HDIR}/sys-setup"
     _run "wget -q https://tinyurl.com/alpine-base"
     if [ -f ${HDIR}/sys-setup/alpine-base ]; then
       _run "mv -f alpine-base sys.zip"
       _run "unzip -o -q sys.zip"
     fi
     _run "cd ${HDIR}"	 
   fi

   #Backgrounds
   if [ ! -f /usr/share/backgrounds/.setup ]; then
      _run "mv -f ${HDIR}/sys-setup/backgrounds/* /usr/share/backgrounds"
      _run "touch /usr/share/backgrounds/.setup"
   fi

   #Start Icons
   if [ ! -d /usr/share/icons/start ]; then _run "mkdir -p /usr/share/icons/start"; fi
   if [ ! -f /usr/share/icons/start/.setup ]; then
      _run "mv -f ${HDIR}/sys-setup/start/* /usr/share/icons/start/"
      _run "touch /usr/share/icons/start/.setup"
   fi

   #User Files
   if [ ! -f ${HDIR}/.hushlogin ]; then
      _run "mv -f ${HDIR}/sys-setup/.bashrc ${HDIR}"
      _run "mv -f ${HDIR}/sys-setup/.bash_aliases ${HDIR}"
      _run "mv -f ${HDIR}/sys-setup/.hushlogin ${HDIR}"
   fi
   _task-end

   #===============================
   # Install Icons
   #===============================
   _task-begin "Install Icons"
   if [ -f ${HDIR}/sys-setup/sys.zip ]; then
      if [ ! -d /usr/share/icons/kora-yellow ]; then
         _run "cp -fr ${HDIR}/sys-setup/icons/kora* /usr/share/icons"
         _run "cd /usr/share/icons"
		 # Loop through files in the target directory
         for file in /usr/share/icons/kora*.tar.xz; do
          if [ -f "$file" ]; then
             _run "tar -xf $file"
	         _run "rm $file"
			 if [ -d /usr/share/icons/kora_green ]; then
			    _run "mv -f /usr/share/icons/kora_green/* /usr/share/icons"
				_run "rm -rf /usr/share/icons/kora_green"
			 fi
			 if [ -d /usr/share/icons/kora_yellow ]; then
			    _run "mv -f /usr/share/icons/kora_yellow/* /usr/share/icons"
				_run "rm -rf /usr/share/icons/kora_yellow"
			 fi
          fi
         done	  
      fi
   fi
   _task-end

   #===============================
   # Install Themes
   #===============================
   _task-begin "Install Themes"
   if [ -f ${HDIR}/sys-setup/sys.zip ]; then
     if [ ! -d /usr/share/themes/Orchis-Green ]; then
        _run "cd /usr/share/themes"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Teal.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Yellow.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Green.tar.xz"
		# Loop through files in the target directory
        for file in /usr/share/themes/Orchis*.tar.xz; do
          if [ -f "$file" ]; then
             _run "tar -xf $file"
	         _run "rm $file"
          fi
        done
	    _run "cd ${HDIR}"
     fi
   fi
   _task-end

   #===============================
   # Update XFCE4 Configuration
   #===============================
   if [ -d ${HDIR}/.config/xfce4 ]; then
      _task-begin "Install XFCE4 Configuration"
      if [ ! -f ${HDIR}/.config/xfce4/.setup ]; then
         if [ -d ${HDIR}/sys-setup/xfce4 ]; then
	        local PList=("xfce4-clipman" "xfce4-clipman-plugin" "xfce4-wavelan-plugin" "xfce4-whiskermenu-plugin")
			_add_by_list ${PList[*]}
	        _run "rm -rf ${HDIR}/.config/xfce4/*"
            _run "mv -f ${HDIR}/sys-setup/xfce4/xfce_alpine.zip ${HDIR}/.config/xfce4/"
            _run "cd ${HDIR}/.config/xfce4/"			
			_run "unzip -o -q xfce_alpine.zip"
	        _run "rm -f xfce_alpine.zip"
            _run "touch ${HDIR}/.config/xfce4/.setup"
			_run "cd ${HDIR}"
	     fi
     fi
	 printf "$OVERWRITE$OVERWRITE"
     _task-end
   fi

    #===============================
    # Install LightDM Configuration
    #===============================
    _task-begin "Install LightDM Configuration"
    if [ -f ${HDIR}/sys-setup/sys.zip ]; then
       if [ ! -f /etc/lightdm/.setup ]; then
          _run "cd ${HDIR}/sys-setup/lightdm"
	      if [ -f /etc/lightdm/lightdm.conf ]; then _run "rm -f /etc/lightdm/lightdm.conf"; fi
	      _run "mv -f lightdm.conf /etc/lightdm"
	      if [ -f /etc/lightdm/lightdm-gtk-greeter.conf ]; then _run "rm -f /etc/lightdm/lightdm-gtk-greeter.conf"; fi
	      _run "mv -f lightdm-gtk-greeter.conf /etc/lightdm"
	      _run "touch /etc/lightdm/.setup"
		  _run "cd ${HDIR}"
       fi
    fi
    _task-end

    #===============================
    # Install GRUB Background
    #===============================
    _task-begin "Install Grub Background"
    if [ -f /boot/grub/.setup ]; then
       if [ ! -d ${HDIR}/sys-setup ]; then _run "mkdir -p ${HDIR}/sys-setup"; fi
       _run "cd ${HDIR}/sys-setup/"
	   if [ -d ${HDIR}/sys-setup/grub2-themes ]; then _run "rm -rf ${HDIR}/sys-setup/grub2-themes"; fi
	   _run "git clone https://github.com/vinceliuice/grub2-themes"
	   if [ -d ${HDIR}/sys-setup/grub2-themes ]; then
          _run "cd ${HDIR}/sys-setup/grub2-themes"
	      _run "${HDIR}/sys-setup/grub2-themes/install.sh -b -t vimix"
	      _run "touch /boot/grub/.setup"
       fi
	   _run "cd ${HDIR}"
    fi
    _task-end

    #===============================
    # Install LXTerminal Setup
    #===============================
    _task-begin "Install LXTerminal Setup"
    if [ $(_exists "lxterminal") > 0 ]; then
       if [ ! -f ${HDIR}/.config/lxterminal/.setup ]; then
          if [ ! -d ${HDIR}/.config/lxterminal/ ]; then _run "mkdir -p ${HDIR}/.config/lxterminal"; fi
	      if [ ! -f ${HDIR}/config/lxterminal/.setup ]; then
	         _run "cd ${HDIR}/sys-setup/applications/lxterminal"
	         _run "mv -f * ${HDIR}/.config/lxterminal/"
	         _run "touch ${HDIR}/.config/lxterminal/.setup"
			 _run "cd ${HDIR}"
          fi
       fi
    fi
    _task-end
	
	#=============================
    #  Setup FSTAB file
    #=============================
	printf "\n"
	_AskYN "    Do you wish to setup network shares to MB-NAS (y/n)" "Y"
    if [ ${REPLY^^} = "Y" ]; then
	   printf "\n"
       _task-begin "Setup Network Shares"
       RET=$( cat /etc/fstab | grep -c "10.10.10.25" )
       if [ ${RET} == "0" ]; then
          echo ""  >> /etc/fstab
          echo "//10.10.10.25/documents  /media/documents  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/utilities  /media/utilities  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/multimedia /media/multimedia cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/backups    /media/backups    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/private    /media/private    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
       fi
       _run "rm -f ${HDIR}/.smbcredentials"
       _run "mv -f ${HDIR}/sys-setup/.smbcredentials ${HDIR}"
       _run "chmod 600 ${HDIR}/.smbcredentials"
	   _task-end
	fi

    #=================================
    # Set Permissions on Directories
    #=================================
    _task-begin "Setting Up Directory Permissions"
    _run "cd ${HDIR}"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/backgrounds"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/icons"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/themes"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/local/include"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.local"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config"
    _task-end

    #===================================
    # Remove non required applications
    #===================================
    printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
    _del_by_list ${DELList[*]}

    #==================================
    # Cleanup
    #==================================
    _task-begin "Remove Temporary Files"
    if [ -d ${HDIR}/sys-setup ]; then _run "rm -rf ${HDIR}/sys-setup"; fi
    _task-end
}


#=======================================
# Title & Menu
#=======================================
function _title() {
   clear
   printf "\n${CYAN}
    ███████╗██╗   ██╗███████╗████████╗███████╗███╗   ███╗
    ██╔════╝╚██╗ ██╔╝██╔════╝╚══██╔══╝██╔════╝████╗ ████║
    ███████╗ ╚████╔╝ ███████╗   ██║   █████╗  ██╔████╔██║
    ╚════██║  ╚██╔╝  ╚════██║   ██║   ██╔══╝  ██║╚██╔╝██║
    ███████║   ██║   ███████║   ██║   ███████╗██║ ╚═╝ ██║
    ╚══════╝   ╚═╝   ╚══════╝   ╚═╝   ╚══════╝╚═╝     ╚═╝

        ███████╗███████╗████████╗██╗   ██╗██████╗
        ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗
        ███████╗█████╗     ██║   ██║   ██║██████╔╝
        ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝
        ███████║███████╗   ██║   ╚██████╔╝██║
        ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝
"
   printf "\n\t\t   ${YELLOW}${OS^^} System Setup        ${LPURPLE}Ver 1.52\n${RESTORE}"
   printf "\t\t\t\t\t${YELLOW}by: ${LPURPLE}Martin Boni${RESTORE}\n"
}

function _menu() {
   printf "\n\n${LPURPLE}       ${OS^^} Desktop Setup\n"
   printf "  ${LGREEN}+----------------------------------+\n"
   printf "  |                                  |\n"
   printf "  |   1) Initial Setup               |\n"
   printf "  |   2) Install Desktop             |\n"
   printf "  |   3) Install Applications        |\n"
   printf "  |   4) Setup Desktop               |\n"
   printf "  |  ------------------------------  |\n"
   printf "  |  99) Quit                        |\n"
   printf "  |                                  |\n"
   printf "  +----------------------------------+${RESTORE}\n\n\n"
   while [[ "123499" != *${STP}* ]]
   do
      _Ask "${OVERWRITE}Choose the step to run (1-4 or 99)" "1" && STP=$REPLY
   done
   printf "\n\n"
}


#=======================================
# Main Code - Start
#=======================================
_title
while [[ ${STP^^} != "99" ]]
do
   _menu
   case ${STP^^} in
      1) _process_step_1 ;;
      2) _process_step_2 ;;
      3) _process_step_3 ;;
      4) _process_step_4 ;;
     99) break ;;
   esac
   STP="777"
done

printf "\n\n\n${YELLOW}============= Updater Completed - Please REBOOT =============${RESTORE}\n\n"
_AskYN "OK to Reboot Now (y/n)" "Y"
if [ ${REPLY^^} = "Y" ]; then reboot; fi
