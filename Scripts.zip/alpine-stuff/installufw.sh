#!/bin/ash

#== Install UFW ==
apk update
apk upgrade
apk add ufw

#== Add Rules ==
ufw default deny incoming
ufw default deny outgoing

#== Inbound Rules ==
ufw allow from 10.10.10.1 to any port 80 proto tcp         # allow incoming HTTPS traffic only from firewall
ufw allow from 10.10.10.1 to any port 443 proto tcp        # allow incoming HTTPS traffic only from firewall
ufw allow from 192.168.10.0/24 to any port 9922 proto tcp  # allow incoming SHH traffic only from my computer

#== Outbound Rules ==
ufw allow out 123/udp          # allow outgoing NTP (Network Time Protocol)
ufw allow out DNS              # allow outgoing DNS
ufw allow out 80/tcp           # allow outgoing HTTP traffic
ufw allow out 443/tcp          # allow outgoing HTTPS traffic
ufw allow out 9921/tcp         # allow outgoing FTP traffic for RCLONE
ufw allow out 55500:56600/tcp  # allow outgoing passive FTP traffic for RCLONE
ufw allow out 55500:56600/udp  # allow outgoing passive FTP traffic for RCLONE

#== Local Override ==
ufw allow from 192.168.10.75

