#!/bin/bash
/bin/rm /var/log/dellogs.log
echo "." >> /var/log/dellogs.log
echo "." >> /var/log/dellogs.log
echo "======= Removing Old Logs ==============================" >> /var/log/dellogs.log
date >> /var/log/dellogs.log
echo "." >> /var/log/dellogs.log
/bin/rm /home/martin/backup.log >> /var/log/dellogs.log
/bin/rm /var/log/sysupdate.log >> /var/log/dellogs.log
/bin/rm /var/log/dockerclean.log >> /var/log/dellogs.log
/bin/rm /var/log/*.gz >> dellogs.log
