#!/bin/bash
echo "." >> /var/log/sysupdate.log
echo "." >> /var/log/sysupdate.log
echo "======= Updating DOCKER01 ==============================" >> /var/log/sysupdate.log
date >> /var/log/sysupdate.log
echo "." >> /var/log/sysupdate.log
/sbin/apk update
/sbin/apk upgrade
