#!/bin/ash

echo "." >> /var/log/virusscan.log
echo "." >> /var/log/virusscan.log
echo "======= Scanning DOCKER01 ==============================" >> /var/log/virusscan.log
date >> /var/log/virusscan.log
echo "." >> /var/log/virusscan.log

# Virus Scan
echo "Updating ClamAV" >> /var/log/virusscan.log
freshclam --quiet  >> /var/log/virusscan.log
echo "Scanning System" >> /var/log/virusscan.log
clamscan -r -i --exclude-dir=^/sys/ --exclude-dir=^/swap/ --exclude-dir=^/mnt/ --heuristic-scan-precedence=yes  --max-scantime=60000 --follow-dir-symlinks=0 --follow-file-symlinks=0 --move=/home/martin/virus / >> /var/log/virusscan.log

# Rootkit Scanning
echo "Updating RKHunter" >> /var/log/virusscan.log
rkhunter --update  >> /var/log/virusscan.log
echo "Scanning for Rootkits" >> /var/log/virusscan.log
rkhunter --check --sk  >> /var/log/virusscan.log

echo "." >> /var/log/virusscan.log
date >> /var/log/virusscan.log
echo "Scanning Complete" >> /var/log/virusscan.log
