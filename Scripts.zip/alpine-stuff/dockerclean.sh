#!/bin/ash
/bin/rm /var/log/dockerclean.log
echo "." >> /var/log/dockerclean.log
echo "." >> /var/log/dockerclean.log
echo "======= Removing Unused Docker Images ===============" >> /var/log/dockerclean.log
date >> /var/log/dockerclean.log
echo "." >> /var/log/dockerclean.log
docker container prune -f >> /var/log/dockerclean.log
docker image prune -af >> /var/log/dockerclean.log
docker volume prune -f >> /var/log/dockerclean.log
docker network prune -f >> /var/log/dockerclean.log
