#!/bin/bash

function _del_language {
  local PList=("hunspell-de-de-frami" "hunspell-de-at-frami" "hunspell-de-ch-frami"
               "hunspell-en-au" "hunspell-en-gb" "hunspell-en-za" "hunspell-es" "hunspell-fr-classical"
               "hunspell-fr" "hunspell-it" "hunspell-pt-br" "hunspell-pt-pt" "hunspell-ru" "hunspell-en-au")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused OS Language Packs ======================
  PList=("language-pack-bg" "language-pack-ca" "language-pack-cs" "language-pack-da"
         "language-pack-de" "language-pack-es" "language-pack-fr" "language-pack-hu"
         "anguage-pack-id" "language-pack-it" "language-pack-ja" "language-pack-ko"
         "language-pack-nb" "language-pack-nl" "language-pack-pl" "language-pack-pt"
         "language-pack-ru" "language-pack-sv" "language-pack-th" "language-pack-tr"
         "language-pack-uk" "language-pack-vi" "language-pack-zh-hans" "language-pack-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused GNOME Language Packs ======================
  PList=("language-pack-gnome-bg" "language-pack-gnome-ca" "language-pack-gnome-cs" "language-pack-gnome-da"
         "language-pack-gnome-de" "language-pack-gnome-es" "language-pack-gnome-fr" "language-pack-gnome-hu"
         "language-pack-gnome-id" "language-pack-gnome-it" "language-pack-gnome-ja" "language-pack-gnome-ko"
         "language-pack-gnome-nb" "language-pack-gnome-nl" "language-pack-gnome-pl" "language-pack-gnome-pt"
         "language-pack-gnome-ru" "language-pack-gnome-sv" "language-pack-gnome-th" "language-pack-gnome-tr"
         "language-pack-gnome-uk" "language-pack-gnome-vi" "language-pack-gnome-zh-hans" "language-pack-gnome-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused Language Packs ======================
  PList=("wbrazilian" "wbritish" "wbulgarian" "wcatalan" "wdanish" "wdutch" "wfrench" "wngerman" "wnorwegian"
         "wogerman" "wpolish" "wportuguese" "wspanish" "wswedish" "wswiss" "wukrainian")
  _del_by_list ${PList[*]}
}

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  case ${OS^^} in
     'ALPINE') # Disable Root Login
               _task-begin "Disable Root Login"
               RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
               if [ ${RET} == 0 ]; then
                 _run "sed -i s'#root:/bin/ash#root:/sbin/nologin#' /etc/passwd"
               fi
               _task-end

               # Update Alpine Terminal Profile
               _task-begin "Update Alpine Terminal Profile"
               RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
               if [ ${RET} == 0 ]; then
                 _run "printf \"PS1='${PS1}'\nexport PS1\" | tee -a /etc/profile"
               fi
               printf "${OVERWRITE}${OVERWRITE}"
               _task-end

               # Remove Alpine MOTD
               _task-begin "Removing MOTD"
               if [ -f /etc/motd ]; then _run "rm /etc/motd"; fi
               _task-end

               #================ Change Shell to Bash ===========
               if [[ $(grep -c '/bin/ash' /etc/passwd) == 0 ]]; then
                 _task-begin "Change Shell to BASH"
                 _run "sed 's#/bin/ash#/bin/bash#' /etc/passwd"
                 _task-end
               fi
               
               # Install Pipewire on Alpine
               if (( $(_Exists "pipewire") == 0 )); then
                 printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
                 _task-begin "Set Pipewire User Groups"
                 _run "addgroup ${SUDO_USER} audio"
                 _run "addgroup ${SUDO_USER} video"
	             _task-end
               fi
               _run "addgroup ${SUDO_USER} plugdev"         
               _run "setup-devd udev"
               ;;
     'DEBIAN') #============ ZRAM Tools Setup ===================
               if [ -f /etc/default/zramswap ]; then
                 _task-begin "Update ZRAM Swap Configuration"
                 _run "echo -e 'ALGO=zstd' | tee -a /etc/default/zramswap"
                 _run "echo -e 'PERCENT=35' | tee -a /etc/default/zramswap"
                 _task-end
               fi
               
               #============ Setup Swappiness ===================
               _task-begin "Update Swap File Swappiness"
               _SWP=$(cat /etc/sysctl.conf | grep 'vm.swappiness' | cut -d "=" -f2)
               if [ -z ${_SWP} ]; then
                  _run "echo 'vm.swappiness=10' | tee -a /etc/sysctl.conf"
               else
                  if [ ! ${_SWP} == "10" ]; then
                    _run "sed -i 's/vm.swappiness=${_SWP}/vm.swappiness=10/g' /etc/sysctl.conf"
                  fi
               fi
               _task-end               
               ;;
     'ARCH')   ;;
     'FEDORA') ;;
  esac
}

function _install_Desktop {
  local PROG=("")
  
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment  ===${RESTORE}\n\n"
  if [ ! -f /usr/share/.desktop ]; then
     case ${OS^^} in
       'ALPINE') _task-begin "Installing ${DSK^^} Desktop Components" 
                 _run "setup-desktop ${DSK,,}"
                 _task-end
                 PROG=("lightdm" "lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" 
                       "thunar-volman" "volumeicon-alsa" "networkmanager" "network-manager-applet")
                 _add_by_list ${PROG[*]}
                 _run "rc-update add lightdm"
                 ;;
       'DEBIAN') PROG=("xorg" "gnome-control-center" "lightdm" "dialog" "lxterminal" "thunar" 
	                   "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin" 
					   "volumeicon-alsa")
	             case ${DSK^^} in
                    'BUDGIE') PROG=("budgie-desktop" "budgie-indicator-applet" "plank") ;;
                           *) _task-begin "Installing ${DSK^^} Desktop"
                              _run "apt-get install -y task-${DSK,,}-desktop"
                              _task-end
                              ;; 
                 esac
				 _add_by_list ${PROG[*]}
				 _run "systemctl enable lightdm"
                 ;;
       'ARCH')   PROG=("xorg" "xorg-server" "gnome-control-center" "lightdm" "lightdm-gtk-greeter" 
	                   "dialog" "lxterminal" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" 
					   "thunar-volman-plugin" "volumeicon-alsa")
	             case ${DSK^^} in
                    'BUDGIE') PROG+=("budgie-desktop" "budgie-indicator-applet" "plank") ;;
                      'XFCE') PROG+=("xfce4" "xfce4-goodies") ;;
                  'CINNAMON') PROG+=("cinnamon") ;;
                 esac
				 _add_by_list ${PROG[*]}
				 _run "systemctl enable lightdm"
				 _run "systemctl enable NetworkManager"
                 ;;
       'FEDORA') ;;
     esac
     _run "touch /usr/share/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _customize_budgie {
   if (( $(_Exists "budgie-desktop") > 0 )); then
      if [ ! -f /usr/share/backgrounds/budgie/.setup ]; then
         if [ -d ${HDIR}/sys-setup/budgie ]; then
			local _STYLE=""
            local _THEME=""
            local _ICON=""

			# ====== Yellow Backgrounds ======
			# vyYvUseebgNgzzGQ.jpg   # Yellow Misty Lake
			# eGna2qBdawpRZpuq.jpg   # Yellow Tree
			# auUagbqqV2gbGi8w.jpg   # Yellow Toronto

            # ====== Blue Backgrounds ======
			# 8pplzWJvxVoxqrCE.jpg   # Volcano Lake
			# oC8iorz2BlyAeEQi.jpg   # Blue Dock
			# Cv0ZEeqOw7vMz1ez.jpg   # Blue Toronto            
            case ${LAY^^} in
              'TOPYELLOW') 
                 _THEME="Skeuos-Yellow-Dark"
                 _ICON="gnome-dust"
                 _STYLE="budgie_top_yellow.dconf"
                 _BACK="eGna2qBdawpRZpuq.jpg"
                 ;;
              'TOPBLUE') 
                 _THEME="Orchis-Dark"
                 _ICON="Boston"
                 _STYLE="budgie_top_blue.dconf" 
                 _BACK="oC8iorz2BlyAeEQi.jpg"
                 ;;
              'BOTTOMYELLOW') _THEME="Skeuos-Yellow-Dark"
                 _ICON="gnome-dust"
                 _STYLE="budgie_bottom_yellow.dconf" 
                 _BACK="eGna2qBdawpRZpuq.jpg"
                 ;;
              'BOTTOMBLUE') 
                 _THEME="Orchis-Dark"
                 _ICON="Boston"
                 _STYLE="budgie_bottom_blue.dconf"                 
                 _BACK="oC8iorz2BlyAeEQi.jpg"
                 ;;
            esac

            # Install Custom Icons & Themes
	        _customize_icons
		    _customize_themes

            _task-begin "Customize Budgie Desktop"
            _run "sudo -u $SUDO_USER DBUS_SESSION_BUS_ADDRESS="$ADDR" dconf load / < ${HDIR}/sys-setup/budgie/${_STYLE}"
            _task-end

            _task-begin "Set Power Settings"
            _setValue "/org/gnome/settings-daemon/plugins/power/idle-dim" "true"
            _setValue "/org/gnome/settings-daemon/plugins/power/sleep-inactive-ac-timeout" "1200"
            _setValue "/org/gnome/settings-daemon/plugins/power/sleep-inactive-battery-timeout" "1200"
            _task-end

            _task-begin "Set Theme & Icons for Desktop"
            _setValue "/org/gnome/desktop/interface/cursor-theme" "'Adwaita'"
            _setValue "/org/gnome/desktop/interface/gtk-theme" "'${_THEME}'"
            _setValue "/org/gnome/desktop/interface/icon-theme" "'${_ICON}'"
            _setValue "/org/gnome/desktop/interface/document-font-name" "'Sans 11'"
            _setValue "/org/gnome/desktop/interface/font-name" "'Sans 11'"
            _setValue "/org/gnome/desktop/interface/monospace-font-name" "'Monospace 11'"
            _task-end

            _task-begin "Set Desktop Background"
	        _run "rm /usr/share/backgrounds/budgie/default.jpg"
	        _run "cp -f /usr/share/backgrounds/${_BACK} /usr/share/backgrounds/budgie/default.jpg"
            _task-end
            
            _run "touch /usr/share/backgrounds/budgie/.setup"
         fi
      fi
   fi
}

function _customize_xfce {
   if (( $(_Exists "xfce4") > 0 )); then
      if [ -d ${HDIR}/.config/xfce4 ]; then
         if [ ! -f ${HDIR}/.config/xfce4/.setup ]; then
		    if [ -d ${HDIR}/sys-setup/xfce4 ]; then
			   local STYLE=""
			   local TYPE=""
               local BACK=""
               local MENU=""
	           local PList=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin" "lxterminal"
                            "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman"
                            "networkmanager" "network-manager-applet")
			   _add_by_list ${PList[*]}

			   _task-begin "Clear Existing XFCE Configuration"
               _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config/xfce4/"
	           _run "rm -rf ${HDIR}/.config/xfce4/*"
	           if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	           if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	           if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	           if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
               _task-end

			   # === Yellow Backgrounds ===
			   # vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg  # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			
			   # === Blue Backgrounds ===
			   # 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			   # oC8iorz2BlyAeEQi.jpg  # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto
               
               #== Yellow Icon Sets ===
               # gnome-dust
               # Windows Vista
               # Boston cardboard
               # buuf-nestort
               # Tango
               
               #== Blue Icon Sets ===
               # Flatery-Sky
               # kuyen-icons
               # gnome-brave
               # Tango
               
               #== Yellow Theme Sets ===
               # Skeuos-Yellow-Dark
               # Orchis-Yellow-Dark
               
               #== Blue Theme Sets ===
               # Fluent-Dark
               # Skeuos-Blue-Dark
               # Goldy-Dark-GTK
               # Orchis-Dark
               
               case ${LAY^^} in
                  'TOPYELLOW') 
                     STYLE="xfce_top_yellow.zip"
                     TYPE="Top"
                     ICON="gnome-dust"
                     THEME="Skeuos-Yellow-Dark"
                     BACK="/usr/share/backgrounds/eGna2qBdawpRZpuq.jpg"
                     MENU="menu_13.png"
                     ;;
                  'TOPBLUE') 
                     STYLE="xfce_top_blue.zip"
                     TYPE="Top"
                     ICON="Tango"
                     THEME="Goldy-Dark-GTK"
                     BACK="/usr/share/backgrounds/oC8iorz2BlyAeEQi.jpg"
                     MENU="menu_05.png"
                     ;;
                  'BOTTOMYELLOW') 
                     STYLE="xfce_bottom_yellow.zip"
                     TYPE="Bottom"
                     ICON="gnome-dust"
                     THEME="Skeuos-Yellow-Dark"
                     BACK="/usr/share/backgrounds/eGna2qBdawpRZpuq.jpg"
                     MENU="menu_13.png"
                     ;;
                  'BOTTOMBLUE') 
                     STYLE="xfce_bottom_blue.zip"
                     TYPE="Bottom"
                     ICON="Tango"
                     THEME="Goldy-Dark-GTK"
                     BACK="/usr/share/backgrounds/oC8iorz2BlyAeEQi.jpg"
                     MENU="menu_05.png"
                     ;;
               esac

               # Install Custom Icons & Themes
	           _customize_icons
		       _customize_themes

			   _task-begin "Download XFCE ${TYPE} Default Configuration"
               _run "rm -rf ${HDIR}/.config/xfce4/*"
               _run "rm -rf ${HDIR}/.config/xfce4/*"
               _run "rm -rf ${HDIR}/.config/xfce4/*"
               _run "cd ${HDIR}/.config/xfce4/"
               _run "mv -f ${HDIR}/sys-setup/xfce4/${STYLE} ${HDIR}/.config/xfce4/"
               _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config/xfce4/"
			   _run "unzip -o -q ${STYLE}"
               _run "rm -f ${HDIR}/.config/xfce4/${STYLE}"
               _run "cd ${HDIR}"
			   _task-end

               _task-begin "Set Desktop Background"
               MON=("monitor0" "monitor1" "monitorVGA-1" "monitorLVDS1" "monitorLVDS-1"
                    "monitorHDMI1" "monitorHDMI2" "monitorHDMI-0" "monitorHDMI-1" "monitorHDMI-2"
                    "monitorDVI-I-1" "monitorDVI-D-0" "monitorDVI-D-1" "monitorDP-1"
                    "monitorVirtual-1" "monitorVirtual-2" "monitorVirtual1" "monitorVirtual2")
               WORK=("workspace0" "workspace1" "workspace2" "workspace3")
               for myMon in "${MON[@]}"
               do
                 for myWork in "${WORK[@]}"
                 do
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/color-style" "0" "int"
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/image-style" "5" "int"
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/image-path" ""
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/last-image" "$BACK"
                 done
               done
               _task-end
                
               # General Settings 
               _task-begin "Set Default Fonts, Icons, and Themes"
               _setXValue "xsettings" "/Gtk/FontName" "Sans 10"
               _setXValue "xsettings" "/Gtk/MonospaceFontName" "Monospace 10"
               _setXValue "xsettings" "/Gtk/ToolbarIconSize" "3" "int"
               _setXValue "xsettings" "/Gtk/ToolbarStyle" "icons"
               _setXValue "xsettings" "/Net/IconThemeName" "$ICON"
               _setXValue "xsettings" "/Net/ThemeName" "$THEME"
               _setXValue "xsettings" "/Xfce/SyncThemes" "true" "bool"
               _task-end
                
               # Hide Suspend, Hibernate, and Hybrid Sleep from the logout dialog:
               _task-begin "Set Shutdown/Power Settings"
               _setXValue "xfce4-session" "/shutdown/ShowSuspend" "false" "bool"
               _setXValue "xfce4-session" "/shutdown/ShowHibernate" "false" "bool"
               _setXValue "xfce4-session" "/shutdown/ShowHybridSleep" "false" "bool"
               _task-end
                               
               #Desktop Setup
               _task-begin "Set Desktop Settings"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-filesystem" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-home" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-removable" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-trash" "true" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-filesystem" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-home" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-removable" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-trash" "true" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/primary" "true" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/style" "1" "int"
               _task-end
               
               _task-begin "Set Whiskermenu Icon"
               FILE="${HDIR}/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"
               _run "sed -i 's/menu_13.png/$MENU/g' $FILE"
               _run "cd ${HDIR}/.config/xfce4/"
               local SRCH=$(grep -rl 'button-icon=' . | grep -v 'show-button') >/dev/null 2>&1
               _log-msg "Looking For: $SRCH"
			   for myFILE in ${SRCH}; do
                 _log-msg "Processing: ${myFILE}"
                 if [ -f ${myFILE} ]; then
                    _log-msg "Replacing menu_13.png with ${MENU} in ${myFILE}"
		            _run "sed -i 's#menu_13.png#${MENU}#g' ${myFILE}"
                 fi
               done
               _task-end
               
               printf "\n"
               _run "cd ${HDIR}"
               _run "touch ${HDIR}/.config/xfce4/.setup"
	        fi
         fi
      fi
   fi
}

function _customize_cinnamon {
   if (( $(_Exists "cinnamon") > 0 )); then
      if [ ! -f ${HDIR}/.config/cinnamon/.setup ]; then
         if [ -d ${HDIR}/sys-setup/cinnamon ]; then
			# === Yellow Backgrounds ===
			# vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			# eGna2qBdawpRZpuq.jpg  # Yellow Tree
			# auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			
			# === Blue Backgrounds ===
			# 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			# oC8iorz2BlyAeEQi.jpg  # Blue Dock
			# Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto
            
			local COLOR=""
            local BACK=""
            local THEME=""
            local ICON=""
            local DIR=""
            
            case ${LAY^^} in
              #  ================= Yellow Theme ===================
              'BOTTOMYELLOW')
                 COLOR="YELLOW"
                 BACK="eGna2qBdawpRZpuq.jpg"
                 THEME="Skeuos-Yellow-Dark"
                 ICON="gnome-dust"
                 MENU="menu_13.png"
	             ;;
              # ================ Blue Theme ====================
              'BOTTOMBLUE') 
                 COLOR="BLUE"
                 BACK="oC8iorz2BlyAeEQi.jpg"
                 THEME="Orchis-Dark"
                 ICON="Boston"
                 MENU="menu_05.png"
	             ;;
            esac

			_customize_icons
		    _customize_themes

			#_task-begin "Install $COLOR Cinnamon Desktop"
            #_run "sudo -u $SUDO_USER dconf load / < ${HDIR}/sys-setup/cinnamon/cinnamon.dconf"
            #_task-end
            
            _task-begin "Set Desktop Background Folders"
			DIR="${HDIR}/.config/cinnamon/backgrounds/"
            if [[ ! -d ${DIR} ]]; then _run "mkdir -p $DIR"; fi
			if [[ -f ${DIR}/user-folders.lst ]]; then _run "rm -f ${DIR}/user-folders.lst"; fi
            _run "echo '/home/${SUDO_USER}/Pictures' > ${_DIR}/user-folders.lst"
            _run "echo '/user/share/backgrounds' >> ${_DIR}/user-folders.lst"
            _task-end
			
            _task-begin "Set Desktop Theme & Icon"
            _setValue "/org/cinnamon/theme/name" "'$THEME'"
            _setValue "/org/cinnamon/desktop/interface/gtk-theme" "'$THEME'"
            _setValue "/org/cinnamon/desktop/interface/cursor-theme" "'$CURSOR'"
            _setValue "/org/cinnamon/desktop/interface/icon-theme" "'$ICON'"
            _task-end
            
            _task-begin "Set Desktop Effects"
            _setValue "/org/cinnamon/desktop-effects" "false"
            _setValue "/org/cinnamon/desktop/interface/clock-show-date" "false"
            _setValue "/org/cinnamon/desklet-decorations" "0"
            _setValue "/org/cinnamon/startup-animation" "false"
            _task-end
            
            _task-begin "Set Background Image"
            _setValue "/org/cinnamon/desktop/background/picture-options" "'zoom'"
            _setValue "/org/cinnamon/desktop/background/picture-uri" "'file:///usr/share/backgrounds/$BACK'"
            _task-end
      
            _task-begin "Set Menu Icon"
			CDIR="${HDIR}/.config/cinnamon/spices/menu@cinnamon.org"
			local PASS1=$(jq '.["menu-custom"] |= (.value = true)' ${CDIR}/0.json)
            local PASS2=$(echo $PASS1 | jq '.["menu-icon"] |= (.value = "/usr/share/icons/start/==MENU==")')
            local PASS3=$(echo $PASS2 | jq '.["menu-label"] |= (.value = "")')
            if [[ ! -z $PASS3 ]]; then
			   if [[ -f $CDIR/0.json ]]; then _run "rm -f $CDIR/0.json"; fi
               printf "${PASS3/==MENU==/$MENU}" >${CDIR}/0.json
            fi
            _task-end
            
            _run "touch ${HDIR}/.config/cinnamon/.setup"		 
         fi
      fi
   fi
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"
   local NIXPATH="nix/profiles"
   
   if [[ ${PATH^^} != *${NIXPATH^^}* ]]; then
      _log-msg "Adding NIX path to PATH variable"
      PATH="/home/$SUDO_USER/.nix-profile/bin:/nix/var/nix/profiles/default/bin:$PATH"
   fi
   
   if [[ ! -f ${HDIR}/param.dat ]]; then
      printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n"
      case ${OS^^} in
        'ALPINE') _task-begin "Updating Linux System"
                  _run "apk update"
                  _run "apk upgrade"
				  _task-end
                  ;;
        'DEBIAN') _task-begin "Updating Linux System"
                  _run "apt-get update"
                  _run "apt-get full-upgrade -y"
                  _run "apt-get autoremove -y"
				  _task-end
				  if (( $(_Exists "flatpak") == 0 )); then
				     _task-begin "Installing Flatpak & Git"
                     _run "apt-get install -y flatpak git"
                     _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
                     _task-end
				  fi
                  if [[ ! -d /nix/store ]]; then
                     _task-begin "Installing NIX Package Manager"
                     _run "wget -q https://nixos.org/nix/install"
                     _run "sed -i s'#curl --fail -L#curl --fail -s -L#' install"
                     _run "sed -i s'#{ wget #{ wget -q #' install"
                     _run "sh install --daemon --yes"
					 _run "adduser ${SUDO_USER} nixbld"
					 _run "rm -f install"
                     _task-end
                     printf "\n\n"
                     _AskYN "Must reboot to complete install of Nix Package Manager" "Y"
                     reboot
                     printf "\n\n"
                  fi
                  ;;
          'ARCH') _task-begin "Updating Linux System"
                  _run "pacman -Syu --noconfirm --needed git base-devel"
				  if (( $(_Exists "yay") == 0 )); then
                     _run "git clone https://aur.archlinux.org/yay.git"
                     _run "cd yay && makepkg -si"
				  fi
				  if (( $(_Exists "flatpak") == 0 )); then
				     _task-begin "Installing Flatpak"
                     _run "yay -Syu --noconfirm flatpak"
                     _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
                     _task-end
				  fi
                  if [[ ! -d /nix/store ]]; then
                     _task-begin "Installing NIX Package Manager"
                     _run "wget -q https://nixos.org/nix/install"
                     _run "sed -i s'#curl --fail -L#curl --fail -s -L#' install"
                     _run "sed -i s'#{ wget #{ wget -q #' install"
                     _run "sh install --daemon --yes"
				     _run "adduser ${SUDO_USER} nixbld"
					 _run "rm -f install"
                     _task-end
                     printf "\n\n"
                     _AskYN "Must reboot to complete install of Nix Package Manager" "Y"
                     reboot
                     printf "\n\n"               
                  fi
                  ;;
        'FEDORA') _task-begin "Updating Linux System"
                  _run "dnf update"
                  _run "dnf upgrade --refresh"
                  _run "dnf autoremove"
                  _run "dnf install flatpak git"
				  if (( $(_Exists "flatpak") == 0 )); then
				     _task-begin "Installing Flatpak"
                     _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
                     _task-end
				  fi
                  if [[ ! -d /nix/store ]]; then
                     _task-begin "Installing NIX Package Manager"
                     _run "wget -q https://nixos.org/nix/install"
                     _run "sed -i s'#curl --fail -L#curl --fail -s -L#' install"
                     _run "sed -i s'#{ wget #{ wget -q #' install"
                     _run "sh install --daemon --yes"
				     _run "adduser ${SUDO_USER} nixbld"
					 _run "rm -f install"
                     printf "\n\n"
                     _AskYN "Must reboot to complete install of Nix Package Manager" "Y"
                     reboot
                     printf "\n\n"
                  fi
                  ;;
      esac
   fi
}

function _process_step_1 {
   printf "\n  ${YELLOW}Step 1 - Install Desktop Environment${RESTORE}\n\n"
   if [[ ! -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
  
   #=============================
   # Install Desktop Environment
   #=============================
   _desktop_menu
   if [[ ${DSK^^} != "QUIT" ]]; then 
       _layout_menu
       _install_Desktop
       
       #==================================
       # Remove non required applications
       #==================================
       printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
       _del_by_list ${DELList[*]}
       
       case ${OS^^} in
         'DEBIAN') _run "apt-get autoremove -y" ;;
           'ARCH') _run "pacman -Qtdq | pacman --noconfirm -Rns -" ;;
         'FEDORA') _run "dnf autoremove" ;;
       esac

       #==================================
       # Restarting System
       #==================================
       printf "\n\n${LPURPLE}=== Restarting System - End of Step 1 ===${RESTORE}\n"
       _AskYN "OK to Reboot Now (y/n)" "Y"
       if [ ${REPLY^^} = "Y" ]; then reboot; fi
   fi
}

function _process_step_2 {
  printf "\n  ${YELLOW}Step 2 - Update System Configuration${RESTORE}\n\n"
  if [[ ! -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
  _run "touch ${LOG}"
  _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
  
  # === Get Desktop Parameters ===
  _task-begin "Get Desktop Parameter File"
  DSK=$(_parm_in "DESKTOP")
  LAY=$(_parm_in "LAYOUT")
  _task-end
  
   case ${OS^^} in
     'ALPINE') PList=("7zip" "acpi" "acpid" "alsa-utils" "apt-transport-https" "avahi-utils" "bash"
                      "bash-completion" "bluez" "blueman" "cifs-utils" "cups" "curl" "dconf-cli"
			          "dbus-x11" "fileroller" "git" "gvfs" "gvfs-backends" "jq" "nano" "pipewire" "pipewire-alsa"
                      "pipewire-audio" "pipewire-pulse" "rar" "libspa-0.2-bluetooth" "preload" "sed" "sudo"
                      "udisks2" "unzip" "wget" "zram-tools")
               ;;
     'DEBIAN') # Upgrade Linux Reposistories
               _task-begin "Updating Linux Reposistory Permissions"
               if [[ ! -f /etc/apt/apt.conf.d/10sandbox ]]; then touch /etc/apt/apt.conf.d/10sandbox; fi
               printf "APT::Sandbox::User \"root\";" | tee -a /etc/apt/apt.conf.d/10sandbox >>$LOG 2>&1
               _run "apt-get update"
               _task-end

               PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi" "bash" "bash-completion" "bluez"
			          "blueman" "cifs-utils" "cups" "curl" "dconf" "dbus-x11" "file-roller" "git"
					  "gvfs" "gvfs-fuse" "gvfs-smb" "gvfs-mtp" "gvfs-nfs" "jq" "nano" "networkmanager"
					  "networkmanager-wifi" "networkmanager-bluetooth" "pipewire" "pipewire-spa-bluez"
					  "pipewire-alsa" "pipewire-pulse" "rar" "sed" "sudo" "udisks2" "unzip" "wget")
               ;;
       'ARCH') PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi" "bash"
                      "bash-completion" "bluez" "blueman" "cifs-utils" "cups" "curl" "dconf"
			          "dbus-x11" "file-roller" "git" "gvfs" "gvfs-fuse" "gvfs-smb" "gvfs-mtp" "gvfs-nfs"
                      "jq" "nano" "networkmanager" "networkmanager-wifi" "networkmanager-bluetooth"
                      "pipewire" "pipewire-spa-bluez" "pipewire-alsa" "pipewire-pulse" "rar" "sed" "sudo"
                      "udisks2" "unzip" "wget")
               ;;
     'FEDORA') PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi" "bash"
                      "bash-completion" "bluez" "blueman" "cifs-utils" "cups" "curl" "dconf"
			          "dbus-x11" "file-roller" "git" "gvfs" "gvfs-fuse" "gvfs-smb" "gvfs-mtp" "gvfs-nfs"
                      "jq" "nano" "networkmanager" "networkmanager-wifi" "networkmanager-bluetooth"
                      "pipewire" "pipewire-spa-bluez" "pipewire-alsa" "pipewire-pulse" "rar" "sed" "sudo"
                      "udisks2" "unzip" "wget")
               ;;
   esac

  #===============================
  # Install required system files
  #===============================
  printf "\n${LPURPLE}=== Install Required System Files ===${RESTORE}\n"
  _add_by_list ${PList[*]}

  #===============================
  # Create Network Mount Points
  #===============================
  printf "\n${LPURPLE}=== Setup System Files ===${RESTORE}\n"
  _task-begin "Create Network Mount Points"
  if [ ! -d /media/documents ]; then _run "mkdir /media/documents"; fi
  if [ ! -d /media/utilities ]; then _run "mkdir /media/utilities"; fi
  if [ ! -d /media/multimedia ]; then _run "mkdir /media/multimedia"; fi
  if [ ! -d /media/backups ]; then _run "mkdir /media/backups"; fi
  if [ ! -d /media/private ]; then _run "mkdir /media/private"; fi
  _task-end

  #=============================
  # Change SSH Config File
  #=============================
  _task-begin "Updating SSH Configuration"
  if [ -f /etc/ssh/sshd_config ]; then
     local SSHKey="ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAgEAiLjHqU7bHolOTinh2fnY0l6KKCqqkEGEv8WOCHAZNTLhrIYRyFlG2PLO9o+/kzSqtWW7ZWyRlAo4FIgu3DE64iNYFnKVfreiKCuD3t8AT8MXMORd+owcqfx7W/KqV3+ZDvA5x0K+4h6vvN1fLswL71fM70WkgQDhmvXz6Eu80KYYOxpyV9rFoH/EM2lLUawhNTsAeFak0FBAaIuTSLUAvoG9v0EbmEViga6JLoSuMllbeGvqQIr51qX1opnrylTN01c6CakeyCva8Hiqum7O1vchQyzW6B+t50TYcKTnQtFmxDujhW1ILB1wXPS1DskPaECZu0gXce8dsHUpyZ2sMu94FaqMhHbEgAZRepsPlNZfeHOxz/PhOlU5NG+oIXvWOKHWMvoHDEqDHnNbjzXZlakO+euyHqn8VfLxY2gJPQFopfI4t4Sr/JjDcWkKubyqN0aXtY1i+d+y9/osWG7OwFwtr41xmikWoVpUGBeOU2DVJlMGNS7BZUAwcyc79n5HpRkM81neJiCDTFFMzyYKh1dlGydxTNzGZHza4Fi/rHBOot1p3ipxrXXM0D/aEsZuriZwcpoK75Pc1DAH2T76QIXNSKfK45BWeXAlK0iXmgTONw6djPCKpKsqb6kEoU3dqLBJGNBlIg0gwKVMpAn8GLRjj6NzqjHni7kl3SXgOXM= rsa-key-20201229"
	 _run "sed -i 's/#Port 22/Port 9922/' /etc/ssh/sshd_config"
	 _run "sed -i 's/PermitRootLogin /#PermitRootLogin/' /etc/ssh/sshd_config" 
	 _run "sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config"
     if [ ! -d ${HDIR}/.ssh ]; then _run "mkdir -p ${HDIR}/.ssh"; fi
     if [ ! -f ${HDIR}/.ssh/authorized_keys ]; then _run "touch ${HDIR}/.ssh/authorized_keys"; fi
     _run "echo ${SSHKey} > ${HDIR}/.ssh/authorized_keys"
  fi
  _task-end

  #===============================
  # Create User Directories
  #===============================
  _task-begin "Create User Directories"
  if [ ! -d ${HDIR}/Documents ]; then _run "mkdir ${HDIR}/Documents"; fi
  if [ ! -d ${HDIR}/Downloads ]; then _run "mkdir ${HDIR}/Downloads"; fi
  if [ ! -d ${HDIR}/Pictures ]; then _run "mkdir ${HDIR}/Pictures"; fi
  _task-end

  #==================================
  # Remove non required applications
  #==================================
  printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
  _del_by_list ${DELList[*]}

  #==================================
  # Remove Language Files
  #==================================
  printf "\n\n${LPURPLE}=== Removing Language Packs ===${RESTORE}\n"
  _del_language

  #==================================
  # Setup OS Environment
  #==================================
  _setup_environment

  #==================================
  # Install Nerd Fonts
  #==================================
  _install_nerdfonts

  #==================================
  # Starting Services
  #==================================
  printf "\n${LPURPLE}=== Starting Services ===${RESTORE}\n"
  _task-begin "Starting Services"
  case ${OS^^} in
     'ALPINE') _run "rc-update add acpid"
               _run "rc-update add avahi-daemon"
               _run "rc-update add cupsd"
               _run "rc-update add bluetooth"
               _run "rc-service sshd restart"
               _run "rc-service networkmanager start"
               ;;
     'DEBIAN') _run "systemctl enable acpid"
               _run "systemctl enable avahi-daemon"
               _run "systemctl enable cups"
               _run "systemctl enable network-manager"
               _run "systemctl enable bluetooth" 
               ;;
       'ARCH')  
               ;;
     'FEDORA') 
               ;;
   esac
  _task-end
  printf "\n\n${LPURPLE}=== End of Step 2 ===${RESTORE}\n\n"
}

function _process_step_3 {
   printf "\n  ${YELLOW}Step 3 - Install Desktop Applications${RESTORE}\n\n"
   # === Get Desktop Parameters ===
   _task-begin "Get Desktop Parameter File"
   DSK=$(_parm_in "DESKTOP")
   LAY=$(_parm_in "LAYOUT")
   _task-end
   
   if [[ ! -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
   printf "\n\n"   
   
   #==================================
   # Choose Packages to Install
   #==================================
   _AskYN "Install Default Apps Only:" "Y"
   printf "\n"
   if [ ${REPLY^^} == "Y" ]; then
      _default_apps
   else
      printf "\n\n"
      _chooser
   fi

   #==================================
   # Install required applications
   #==================================
   printf "\n\n${LPURPLE}=== Installing Required Packages ===${RESTORE}\n"
   _add_by_list ${ADDList[*]}=
   
   #====================================
   # Update NIX package symbolic links
   #====================================
   if [[ ${OS^^} == 'DEBIAN' ]]; then
      _task-begin "Setting NIX Package Symbolic Links"
      _run "ln -s /root/.nix-profile/share/applications/* /usr/share/applications/"
      _run "ln -s /root/.nix-profile/bin/* /usr/bin/"
      for NDIR in $(ls /root/.nix-profile/share/icons/hicolor); do
        _run "ln -s /root/.nix-profile/share/icons/hicolor/$NDIR/apps/* /usr/share/icons/hicolor/$NDIR/apps/"
     done
	 _run "gtk-update-icon-cache -f -t /usr/share/icons/hicolor/"
	 _task-end
   fi   
  
   printf "\n\n${LPURPLE}=== End of Step 3 ===${RESTORE}\n\n"
}

function _process_step_4 {
   printf "\n  ${YELLOW}Step 4 - Install Desktop Customizations${RESTORE}\n\n"
   # === Delete any pervious logs and setup new one ===
   if [[ ! -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
  
   # === Get Desktop Parameters ===
   _task-begin "Get Desktop Parameter File"
   DSK=$(_parm_in "DESKTOP")
   LAY=$(_parm_in "LAYOUT")
   _log-msg "Parameters After Read - Desktop=$DSK, Layout=$LAY"
   _task-end


   # === Get Setup File ===
   _get_setup_file
   
   # === Seup User ===
   _customize_user_environment

   # === Customize Desktop Environment ===
   printf "\n${LPURPLE}=== Customize Desktop Environment ===${RESTORE}\n\n"
   case ${DSK^^} in
         'XFCE') if (( $(_Exists "xfce4") > 0 )); then _customize_xfce; fi ;;
       'BUDGIE') if (( $(_Exists "budgie-desktop") > 0 )); then _customize_budgie; fi ;;
     'CINNAMON') if (( $(_Exists "cinnamon") > 0 )); then _customize_cinnamon; fi ;;
   esac

   # === Customize LIGHTDM settings ===
   if (( $(_Exists "lightdm") > 0 )); then _customize_lightdm; fi

   # === Customize GRUB Settings ===
   if [[ ${OS^^} != "ALPINE" ]]; then _customize_grub; fi

   # === Customize LXTerminal Setup ===
   _customize_lxterminal
 
   # === Customize Plank Setup ===
   if (( $(_Exists "plank") > 0 )); then _customize_plank; fi

   # === Setup Autostart Files ===
   _customize_autostart

   #  === Setup FSTAB file ===
   _customize_fstab

   # === Create Desktop Shortcuts ===
   _customize_shortcuts

   # === Set Permissions on Directories ===
   _task-begin "Setting Up Directory Permissions"
   _run "cd ${HDIR}"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/backgrounds"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/icons"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/themes"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/local/include"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.local"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config"
   _task-end

   # === Cleanup ===
   _task-begin "Remove Temporary Files"
   if [[ -d ${HDIR}/sys-setup ]]; then _run "rm -rf ${HDIR}/sys-setup"; fi
   if [[ -f ${HDIR}/param.dat ]]; then _run "rm -rf ${HDIR}/param.dat"; fi
   printf "$OVERWRITE"
   _task-end
   
   # === Restarting System ===
   printf "\n\n${LPURPLE}=== Restarting System - End of Step 4 ===${RESTORE}\n"
   _AskYN "OK to Reboot Now (y/n)" "Y"
   if [ ${REPLY^^} = "Y" ]; then reboot; fi
}

