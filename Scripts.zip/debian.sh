#!/bin/bash

SYSList=("7zip" "acpi" "acpid" "alsa-utils" "apt-transport-https" "avahi-utils" "bash" "bash-completion" "bluez"
         "blueman" "cifs-utils" "cups" "curl" "dconf-cli" "dbus-x11" "fileroller" "fuse" "git" "gvfs" "gvfs-backends"
		 "jq" "nano" "pipewire" "wireplumber" "pipewire-alsa" "pipewire-audio" "pipewire-pulse" "rar" "libspa-0.2-bluetooth" "preload"
		 "sed" "sudo" "udisks2" "unzip" "wget" "xarchiver" "xz" "zram-tools")

DELList=("doas" "exfalso" "firefox" "firefox-esr" "flite" "libreoffice" "malcontent*" "parole"
         "qodlibet" "synaptic*" "xfburn" "xterm" "xfce4-notes" "xfce4-terminal")
APPList+=("=== Choose Browser(s) ===||"
          "Brave Browser|@FLT-BRAVE|N" 
          "Chromium Browser|@FLT-CHROME|N" 
		  "Falkon Browser|@FLT-FALKON|N"
          "Firefox Browser|@FLT-FIREFOX|N"
          "Floorp Browser|@FLT-FLOORP|Y"
          "Google Chrome Browser|@FLT-GOOGLE|N"
          "LibreWolf Browser|@FLT-WOLF|N"
		  "Thorium Browser|@DEB-THORIUM|Y"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|N"
		  "Vivaldi Browser|@FLT-VIVALDI|N"
          "Waterfox Browser|@FLT-WATER|N"
          "=== Choose Office Tools ===||"
		  "Abiword Word Processor|abiword|N"
          "Bluemail Email Client|@FLT-BLUE|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		  "Gnome Calculator|gnome-calculator|Y"
		  "gNumeric Spreadsheet|gnumeric|N"
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
		  "Mousepad Notepad|mousepad|Y"
		  "NotepadQQ Editor|@FLT-NOTEPAD|Y"
		  "Notepad Next Editor|@FLT-NEXT|N"
		  "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|Y"
		  "Standard Notes|@FLT-NOTES|N"
		  "Thunderbird Email Client|thunderbird|Y"
		  "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|@FLT-TWIT|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|N"
          "=== Choose Development Tools ===||"
		  "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|@FLT-VSCODE|N"
          "=== Choose System Tools ===||"
		  "Balena Etcher|@DEB-ETCHER|Y"
          "BleachBit Utility|@FLT-BLEACH|Y"
          "Clam Anti Virus|clamav|N"
          "Clam Anti Virus GUI|@FLT-CLAMTK|N"
          "Disk Utility|gnome-disk-utility|Y"
		  "Fastfetch|fastfetch|N"
		  "Flameshot Screenshot Utility|flameshot|Y"
		  "Gnome Software Manager|gnome-software|Y"
		  "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		  "Neofetch|neofetch|Y"
          "Numlockx|numlockx|Y"
          "Pika Backup|@FLT-PIKA|Y"
		  "Putty SSH Utility|putty|Y"
          "System Monitor|@FLT-MONITOR|N"
		  "Stacer|stacer|Y"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Impress USB Writer|@FLT-IMPRESS|N"
          "=== Choose Emulation Tools ===||"
		  "Bottles Windows Emulation|@FLT-BOTTLES|N"
          "Play On Linux|@FLT-PLAY|N"
		  "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine GUI|@FLT-WGUI|N"
          "=== Choose Virtualization Tools ===||"
		  "DistroBox|distrobox|N"
		  "Docker|docker|N"
		  "Gnome Boxes|gnome-boxes|Y"
		  "Podman|podman|N"
		  "Virtualization Manager|virt-manager|N"
          "=== Choose Optional Applications ===||"
		  "Calibre eBook Manager|@FLT-BOOK|Y"
		  "Cheese Camera Utility|cheese|N"
		  "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|kodi|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		  "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
		  "VLC Media Player|vlc|Y"
		  "XArchiver Utility|xarchiver|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  #============ ZRAM Tools Setup ===================
  if [ -f /etc/default/zramswap ]; then
     _task-begin "Update ZRAM Swap Configuration"
     _run "echo -e 'ALGO=zstd' | tee -a /etc/default/zramswap"
     _run "echo -e 'PERCENT=35' | tee -a /etc/default/zramswap"
     _task-end
  fi

  #============ Setup Swappiness ===================
  _task-begin "Update Swap File Swappiness"
  _SWP=$(cat /etc/sysctl.conf | grep 'vm.swappiness' | cut -d "=" -f2)
  if [ -z ${_SWP} ]; then
     _run "echo 'vm.swappiness=10' | tee -a /etc/sysctl.conf"
  else
     if [ ! ${_SWP} == "10" ]; then
        _run "sed -i 's/vm.swappiness=${_SWP}/vm.swappiness=10/g' /etc/sysctl.conf"
     fi
  fi
  _task-end               

  #============= Disable Root Login =================
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/usr/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
    _run "sed -i s'#root:/bin/bash#root:/usr/sbin/nologin#' /etc/passwd"
  fi
  _task-end
}

function _del_language {
  local PList=("hunspell-de-de-frami" "hunspell-de-at-frami" "hunspell-de-ch-frami"
               "hunspell-en-au" "hunspell-en-gb" "hunspell-en-za" "hunspell-es" "hunspell-fr-classical"
               "hunspell-fr" "hunspell-it" "hunspell-pt-br" "hunspell-pt-pt" "hunspell-ru" "hunspell-en-au")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused OS Language Packs ======================
  PList=("language-pack-bg" "language-pack-ca" "language-pack-cs" "language-pack-da"
         "language-pack-de" "language-pack-es" "language-pack-fr" "language-pack-hu"
         "anguage-pack-id" "language-pack-it" "language-pack-ja" "language-pack-ko"
         "language-pack-nb" "language-pack-nl" "language-pack-pl" "language-pack-pt"
         "language-pack-ru" "language-pack-sv" "language-pack-th" "language-pack-tr"
         "language-pack-uk" "language-pack-vi" "language-pack-zh-hans" "language-pack-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused GNOME Language Packs ======================
  PList=("language-pack-gnome-bg" "language-pack-gnome-ca" "language-pack-gnome-cs" "language-pack-gnome-da"
         "language-pack-gnome-de" "language-pack-gnome-es" "language-pack-gnome-fr" "language-pack-gnome-hu"
         "language-pack-gnome-id" "language-pack-gnome-it" "language-pack-gnome-ja" "language-pack-gnome-ko"
         "language-pack-gnome-nb" "language-pack-gnome-nl" "language-pack-gnome-pl" "language-pack-gnome-pt"
         "language-pack-gnome-ru" "language-pack-gnome-sv" "language-pack-gnome-th" "language-pack-gnome-tr"
         "language-pack-gnome-uk" "language-pack-gnome-vi" "language-pack-gnome-zh-hans" "language-pack-gnome-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused Language Packs ======================
  PList=("wbrazilian" "wbritish" "wbulgarian" "wcatalan" "wdanish" "wdutch" "wfrench" "wngerman" "wnorwegian"
         "wogerman" "wpolish" "wportuguese" "wspanish" "wswedish" "wswiss" "wukrainian")
  _del_by_list ${PList[*]}
}

function _start_services {
  printf "\n${LPURPLE}=== Starting Services ===${RESTORE}\n"
  _task-begin "Starting Services"
  _run "systemctl enable acpid"
  _run "systemctl enable avahi-daemon"
  _run "systemctl enable cupsd"
  _run "systemctl enable bluetooth"
  _run "systemctl restart sshd"
  _run "systemctl restart networkmanager"
  _task-end
}

function _set_aliases {
   _log-msg "============== Start of Setting Aliases ================"
   if [[ -f $HDIR/.bash_aliases ]]; then
     if [[ ! $HDIR/scripts/skipdir/.aliases ]]; then
	    _log-msg "   Setting Update, Install, Remove, and Clean"
        echo "alias update='sudo apt-get update && sudo apt-get upgrade -y && sudo flatpak update'" | tee $HDIR/.bash_aliases
        echo "alias install='sudo apt-get install -y '" | tee $HDIR/.bash_aliases
        echo "alias remove='sudo apt-get purge -y '" | tee $HDIR/.bash_aliases
        echo "alias clean='sudo apt-get autoremove -y'" | tee $HDIR/.bash_aliases
	    touch $HDIR/scripts/skipdir/.aliases
	 fi
   fi
   _log-msg "============== End of Setting Aliases ================"

   #============= Change FASTFETCH to NEOFETCH =================
   _log-msg "============== Start of Updating .bashrc ================"
   RET=$( grep -c 'fastfetch' $HDIR/.bashrc)
   if [ ${RET} > 0 ]; then
      _log-msg "    Changing Fastfetch to Neofetch"
     _run "sed -i s'#fastfetch#neofetch#' $HDIR/.bashrc"
   fi
   _log-msg "============== End of Updating .bashrc ================"
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment  ===${RESTORE}\n\n"
  if [ ! -f $HDIR/scripts/skipdir/.desktop ]; then
	 PROG=("curl" "dialog" "gnome-control-center" "gnome-software-plugin-flatpak" "lightdm"
	       "lxterminal" "networkmanager" "network-manager-gnome" "networkmanager-wifi"
		    "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman"
	       "wpa_supplicant" "volumeicon-alsa")
		   
	 case ${DSK^^} in
       'BUDGIE') PROG+=("budgie-desktop" "budgie-indicator-applet" "plank")
	             ;;
              *) _task-begin "Installing ${DSK^^} Desktop"
                 _run "apt-get install -y task-${DSK,,}-desktop"
                 _task-end
                 ;; 
     esac
	 _add_by_list ${PROG[*]}
	 _run "systemctl enable lightdm"
     _run "touch $HDIR/scripts/skipdir/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"
   if [[ ! -d $HDIR/scripts/skipdir/ ]]; then mkdir $HDIR/scripts/skipdir; fi

   if [[ ! -f $HDIR/scripts/skipdir/.prereq ]]; then
      _task-begin "Updating Linux System"
      _run "apt-get update"
      _run "apt-get full-upgrade -y"
      _run "apt-get autoremove -y"
	   _run "apt-get install -y curl git wget unzip nano xz"
	  _task-end

	  _task-begin "Installing Flatpak"
      _run "apt-get install -y flatpak"
      _run "flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo"
      _task-end
	  touch $HDIR/scripts/skipdir/.prereq 
   fi
}