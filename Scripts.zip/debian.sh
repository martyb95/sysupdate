#!/bin/bash
SYSList=("7zip" "acpi" "acpid" "apt-transport-https" "avahi-utils" "bash" "bash-completion" 
         "cifs-utils" "cups" "curl" "dbus" "fuse" "git" "gvfs" "gvfs-backends" "jq" "nano"
         "rar"  "preload" "sed" "sudo" "udisks2" "unzip" "wget"  "xz" "zram-tools")

DESKList=("alsa-utils" "bluez" "blueman" "cups-pk-helper" "cups-filters" "dconf-cli" 
          "dejavu-fonts-ttf" "dbus-x11" "foomatic-db" "foomatic-db-engine" "gufw" 
          "libspa-bluetooth" "NetworkManager" "pipewire" "pipewire-alsa" "pipewire-audio"
          "pipewire-pulse" "polkit" "powertop" "terminus-font" "tlp" "wireplumber" "xrandr")

DELList=("aisleriot" "brasero*" "doas" "exfalso" "firefox*" "firefox-esr" "flite" "four-in-a-row"
         "gnome-2048" "gnome-chess" "gnome-games" "gnome-klotski" "gnome-mahjongg"
         "gnome-mines" "gnome-nibbles" "gnome-robots" "gnome-sound-recorder" "gnome-sudoku"
         "gnome-taquin" "gnome-tetravex" "gnote" "hexchat*" "hitori" "hoichess" "libreoffice*" 
         "lightsoff" "malcontent*" "mate-*" "parole" "pidgin" "qodlibet" "quadrapassel" "remmina" 
         "rhythmbox" "shotwell" "sound-juicer" "swell-foop" "synaptic*" "tali" "transmission-*"
          "xfburn" "xterm" "xfce4-notes" "xfce4-terminal")
         
APPList+=("=== Choose Browser(s) ===||"
          "Brave Browser|@FLT-BRAVE|N" 
          "Chromium Browser|@FLT-CHROME|N" 
		    "Falkon Browser|@FLT-FALKON|N"
          "Firefox Browser|@FLT-FIREFOX|N"
          "Floorp Browser|@FLT-FLOORP|N"
          "Google Chrome Browser|@FLT-GOOGLE|N"
          "LibreWolf Browser|@FLT-WOLF|N"
		    "Thorium Browser|@DEB-THORIUM|Y"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|Y"
		    "Vivaldi Browser|@FLT-VIVALDI|N"
          "Waterfox Browser|@FLT-WATER|N"
          "=== Choose Office Tools ===||"
		    "Abiword Word Processor|abiword|N"
          "Bluemail Email Client|@FLT-BLUE|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		    "Gnome Calculator|gnome-calculator|Y"
		    "gNumeric Spreadsheet|gnumeric|N"
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
		    "Mousepad Notepad|mousepad|Y"
		    "NotepadQQ Editor|@FLT-NOTEPAD|N"
		    "Notepad Next Editor|@FLT-NEXT|N"
		    "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|Y"
		    "Standard Notes|@FLT-NOTES|N"
		    "Thunderbird Email Client|thunderbird|Y"
		    "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|@FLT-TWIT|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|N"
          "=== Choose Development Tools ===||"
		    "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|@FLT-VSCODE|N"
          "=== Choose System Tools ===||"
		    "Balena Etcher|@DEB-ETCHER|Y"
          "BleachBit Utility|@FLT-BLEACH|Y"
          "Clam Anti Virus|clamav|Y"
          "Clam Anti Virus GUI|@FLT-CLAMTK|Y"
          "Disk Utility|gnome-disk-utility|Y"
		    "Fastfetch|@DEB-FASTFETCH|Y"
		    "Flameshot Screenshot Utility|flameshot|Y"
		    "Gnome Software Manager|gnome-software|Y"
		    "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		    "Neofetch|neofetch|N"
          "Numlockx|numlockx|Y"
          "Pika Backup|@FLT-PIKA|Y"
		    "Putty SSH Utility|putty|N"
          "System Monitor|@FLT-MONITOR|N"
		    "Stacer|stacer|Y"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Impress USB Writer|@FLT-IMPRESS|N"
          "=== Choose Emulation Tools ===||"
		    "Bottles Windows Emulation|@FLT-BOTTLES|N"
          "Play On Linux|@FLT-PLAY|N"
		    "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine GUI|@FLT-WGUI|N"
          "=== Choose Virtualization Tools ===||"
		    "DistroBox|distrobox|N"
		    "Docker|docker|N"
		    "Gnome Boxes|gnome-boxes|N"
		    "Podman|podman|N"
		    "Virtualization Manager|virt-manager|N"
          "=== Choose Optional Applications ===||"
		    "Calibre eBook Manager|@FLT-BOOK|N"
		    "Cheese Camera Utility|cheese|N"
		    "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|kodi|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		    "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
		    "VLC Media Player|vlc|Y"
		    "XArchiver Utility|xarchiver|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  #============ ZRAM Tools Setup ===================
  if [ -f /etc/default/zramswap ]; then
     _task-begin "Update ZRAM Swap Configuration"
     _run "echo -e 'ALGO=zstd' | tee -a /etc/default/zramswap"
     _run "echo -e 'PERCENT=35' | tee -a /etc/default/zramswap"
     _task-end
  fi

  #============ Setup Swappiness ===================
  _task-begin "Update Swap File Swappiness"
  _SWP=$(cat /etc/sysctl.conf | grep 'vm.swappiness' | cut -d "=" -f2)
  if [ -z ${_SWP} ]; then
     _run "echo 'vm.swappiness=10' | tee -a /etc/sysctl.conf"
  else
     if [ ! ${_SWP} == "10" ]; then
        _run "sed -i 's/vm.swappiness=${_SWP}/vm.swappiness=10/g' /etc/sysctl.conf"
     fi
  fi
  _task-end               

  #============= Disable Root Login =================
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/usr/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
    _run "sed -i s'#root:/bin/bash#root:/usr/sbin/nologin#' /etc/passwd"
  fi
  _task-end
}

function _del_language {
  local PList=("hunspell-de-de-frami" "hunspell-de-at-frami" "hunspell-de-ch-frami"
               "hunspell-en-au" "hunspell-en-gb" "hunspell-en-za" "hunspell-es" "hunspell-fr-classical"
               "hunspell-fr" "hunspell-it" "hunspell-pt-br" "hunspell-pt-pt" "hunspell-ru" "hunspell-en-au")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused OS Language Packs ======================
  PList=("language-pack-bg" "language-pack-ca" "language-pack-cs" "language-pack-da"
         "language-pack-de" "language-pack-es" "language-pack-fr" "language-pack-hu"
         "anguage-pack-id" "language-pack-it" "language-pack-ja" "language-pack-ko"
         "language-pack-nb" "language-pack-nl" "language-pack-pl" "language-pack-pt"
         "language-pack-ru" "language-pack-sv" "language-pack-th" "language-pack-tr"
         "language-pack-uk" "language-pack-vi" "language-pack-zh-hans" "language-pack-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused GNOME Language Packs ======================
  PList=("language-pack-gnome-bg" "language-pack-gnome-ca" "language-pack-gnome-cs" "language-pack-gnome-da"
         "language-pack-gnome-de" "language-pack-gnome-es" "language-pack-gnome-fr" "language-pack-gnome-hu"
         "language-pack-gnome-id" "language-pack-gnome-it" "language-pack-gnome-ja" "language-pack-gnome-ko"
         "language-pack-gnome-nb" "language-pack-gnome-nl" "language-pack-gnome-pl" "language-pack-gnome-pt"
         "language-pack-gnome-ru" "language-pack-gnome-sv" "language-pack-gnome-th" "language-pack-gnome-tr"
         "language-pack-gnome-uk" "language-pack-gnome-vi" "language-pack-gnome-zh-hans" "language-pack-gnome-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused Language Packs ======================
  PList=("wbrazilian" "wbritish" "wbulgarian" "wcatalan" "wdanish" "wdutch" "wfrench" "wngerman" "wnorwegian"
         "wogerman" "wpolish" "wportuguese" "wspanish" "wswedish" "wswiss" "wukrainian")
  _del_by_list ${PList[*]}
}

function _start_services {
   if [[ ! -f ${HDIR}/scripts/skipdir/.services ]]; then
      _task-begin "Starting Services"
      _run "systemctl enable acpid"
      _run "systemctl enable avahi-daemon"
      _run "systemctl enable cupsd"
      _run "systemctl enable bluetooth"
      _run "systemctl restart networkmanager"
      _run "systemctl enable preload"

      if [[ ${DEVTYPE^^} == "LAPTOP" ]]; then _run "systemctl enable tlp"; fi
      if [[ ${MEMSIZE} -gt 5 ]]; then _run "systemctl enable zram"; fi

      _run "ufw enable"
      _run "systemctl enable ufw"
      _task-end

      # Remove unrequired services
      _task-begin "Removing Unrequired Services"
      _run "systemctl disable dhcpcd"
      _run "systemctl disable sshd"
      _task-end      

      _run "touch ${HDIR}/scripts/skipdir/.services"
   fi

}

function _set_aliases {
   if [[ ! -f ${HDIR}/scripts/skipdir/.aliases ]]; then
      _task-begin "Updating Aliases"
      _run "touch $HDIR/.bash_aliases"

      printf "# LS aliases\n" >> $HDIR/.bash_aliases
      printf "alias ls='ls --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias ll='ls -la '\n" >> $HDIR/.bash_aliases

      printf "\n# System tool aliases\n" >> $HDIR/.bash_aliases
      printf "alias wget='wget -c'\n" >> $HDIR/.bash_aliases
      printf "alias df='df -H'\n" >> $HDIR/.bash_aliases
      printf "alias du='du -ch'\n" >> $HDIR/.bash_aliases
      
      printf "\n# CD aliases\n" >> $HDIR/.bash_aliases
      printf "alias cd..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias ..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias .3='cd ../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .4='cd ../../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .5='cd ../../../../..'\n" >> $HDIR/.bash_aliases

      printf "\n# Colorize the grep command output\n" >> $HDIR/.bash_aliases
      printf "alias grep='grep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias egrep='egrep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias fgrep='fgrep --color=auto'\n" >> $HDIR/.bash_aliases

      printf "\n# Date & Time aliases\n" >> $HDIR/.bash_aliases
      printf "alias now='date +%%T'\n" >> $HDIR/.bash_aliases
      printf "alias nowdate='date +"%d-%m-%Y"'\n" >> $HDIR/.bash_aliases

      printf "\n# Networking aliases\n" >> $HDIR/.bash_aliases
      printf "alias ping='ping -c 5'\n" >> $HDIR/.bash_aliases
      printf "alias fping='ping -c 100 -s.2'\n" >> $HDIR/.bash_aliases
      printf "alias ports='netstat -tulanp'\n" >> $HDIR/.bash_aliases

      printf "\n# do not delete / or prompt if deleting more than 3 files at a time #\n" >> $HDIR/.bash_aliases
      printf "alias rm='rm -I --preserve-root'\n" >> $HDIR/.bash_aliases
      
      printf "\n# confirmation #\n" >> $HDIR/.bash_aliases
      printf "alias mv='mv -i'\n" >> $HDIR/.bash_aliases
      printf "alias cp='cp -i'\n" >> $HDIR/.bash_aliases
      printf "alias ln='ln -i'\n" >> $HDIR/.bash_aliases
      
      printf "\n# Parenting changing perms on / #\n" >> $HDIR/.bash_aliases
      printf "alias chown='chown --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chmod='chmod --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chgrp='chgrp --preserve-root'\n" >> $HDIR/.bash_aliases

      printf "\n# reboot / halt / poweroff\n" >> $HDIR/.bash_aliases
      printf "alias reboot='sudo /sbin/reboot'\n" >> $HDIR/.bash_aliases
      printf "alias poweroff='sudo /sbin/poweroff'\n" >> $HDIR/.bash_aliases
      printf "alias shutdown='sudo /sbin/shutdown'\n" >> $HDIR/.bash_aliases

      printf "\n# System memory, cpu usage, and gpu memory info\n" >> $HDIR/.bash_aliases
      printf "## Get server cpu info ##\n" >> $HDIR/.bash_aliases
      printf "alias cpuinfo='lscpu'\n" >> $HDIR/.bash_aliases
      printf "alias meminfo='free -m -l -t'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating memory\n" >> $HDIR/.bash_aliases
      printf "alias psmem='ps auxf | sort -nr -k 4'\n" >> $HDIR/.bash_aliases
      printf "alias psmem10='ps auxf | sort -nr -k 4 | head -10'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating cpu ##\n" >> $HDIR/.bash_aliases
      printf "alias pscpu='ps auxf | sort -nr -k 3'\n" >> $HDIR/.bash_aliases
      printf "alias pscpu10='ps auxf | sort -nr -k 3 | head -10'\n" >> $HDIR/.bash_aliases

      printf "\n# Package Manager Aliases\n" >> $HDIR/.bash_aliases
      printf "alias update='sudo apt-get update && sudo apt-get upgrade -y && sudo flatpak update -y'\n" >> $HDIR/.bash_aliases
      printf "alias install='sudo apt-get install -y '\n" >> $HDIR/.bash_aliases
      printf "alias remove='sudo apt-get remove -y && sudo apt-get autoremove -y'\n" >> $HDIR/.bash_aliases

	   _run "touch ${HDIR}/scripts/skipdir/.aliases"
      _task-end
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment  ===${RESTORE}\n\n"
  if [ ! -f $HDIR/scripts/skipdir/.desktop ]; then
     _task-begin "Installing ${DSK^^} Desktop"
     if [[ ${DSK^^} != "BUDGIE" ]]; then _run "apt-get install -fy task-${DSK,,}-desktop"; fi
     if [[ ! -z $(dpkg --configure -a 2>&1) ]]; then _run "apt-get --fix-broken install"; fi
     _task-end

     _task-begin "Installing additional packages for $DSK desktop"
	  case ${DSK^^} in
         'BUDGIE') PROG=("xorg" "xorg-fonts" "xorg-video-drivers" "xorg-input-drivers" "xdg-user-dirs" 
                         "budgie-desktop" "budgie-screensaver" "budgie-indicator-applet" "budgie-control-center") ;;
           'XFCE') PROG=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin" "xfce4-alsa-plugin"
                         "xfce4-netload-plugin" "xfce4-cpugraph-plugin" "xfce4-weather-plugin" "xfce4-mailwatch-plugin"
                         "lightdm" "lightdm-gtk-greeter") ;;
       'CINNAMON') PROG=("plank" "lightdm" "lightdm-gtk-greeter") ;;
           'LXQT') PROG=("lightdm" "lightdm-gtk-greeter") ;;
	       'GNOME') PROG=("gnome-apps" "pulseaudio" "task-gnome-desktop" "lightdm" "lightdm-gtk-greeter") ;;  
	      'PLASMA') PROG=("kde-baseapps" "sddm") ;;                    
     esac

	  _add_by_list ${PROG[*]}
	  _run "systemctl enable lightdm"
     _task-end
     _run "touch $HDIR/scripts/skipdir/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _process_update() {
  printf "\n${LPURPLE}=== Perform System Update ===${RESTORE}\n"
  _task-begin "Updating System Packages"
  _run "apt-get update && apt-get upgrade -y && apt-get autoremove -y"
  _task-end

  _task-begin "Updating Flatpak Packages"
  _run "flatpak update -y"
  _task-end

  _task-begin "Updating DEB/XDEB Packages"

  _task-end
}

function _prereqs {
   #MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   #ADDR="unix:path=/run/user/$MYUID/bus"
   if [[ ! -d $HDIR/scripts/skipdir/ ]]; then mkdir $HDIR/scripts/skipdir; fi

   if [[ ! -f $HDIR/scripts/skipdir/.prereq ]]; then
      _task-begin "Updating Linux System"
      _run "apt-get --fix-broken install"
      _run "apt-get -u dist-upgrade"
      _run "apt-get clean"
      _run "apt-get autoclean"
      _run "apt-get update"
      _run "apt-get full-upgrade -y"
      _run "apt-get autoremove -y"
      _run "apt-get --fix-broken install"
	   _run "apt-get install -fy curl git wget unzip nano xz dmidecode"
	  _task-end

	  _task-begin "Installing Flatpak"
      _run "apt-get install -fy flatpak"
      _run "flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo"
      _task-end
	  touch $HDIR/scripts/skipdir/.prereq 
   fi
}