#!/bin/bash

LOG="/home/martin/Scripts/automount.log"
echo "Current Dir = $(pwd)" >$LOG 2>&1
echo "Current User = $USER" >>$LOG 2>&1
echo "$(id)" >>$LOG 2>&1

USR=$(grep "username=" .smbcredentials | cut -d'=' -f2)
PAS=$(grep "password=" .smbcredentials | cut -d'=' -f2)
if [[ ! -z ${PAS} ]]; then echo "$PAS" | sudo -S mount -a >>$LOG 2>&1; fi