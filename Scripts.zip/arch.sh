#!/bin/bash

SYSList=("p7zip" "acpi" "acpid" "alsa-utils" "bash" "bash-completion" "bluez" "blueman" "cifs-utils" "cups" "cups-runit"
         "dconf" "dbus-runit" "fuse2" "gvfs" "gvfs-mtp" "gvfs-smb" "pipewire" "wireplumber" "pipewire-pulse" "preload" 
		 "sed" "udisks2" "xarchiver" "xrandr")
DESKList=()
DELList=("epiphany" "leafpad" "mpv" "parole" "xfburn" "xfce4-terminal" "xfce4-notes")
APPList+=("=== Choose Browser(s) ===||"
          "Brave Browser|brave-bin|N" 
          "Chromium Browser|chromium-widevine|N" 
		  "Falkon Browser|falkon|N"
          "Firefox Browser|firefox|N"
          "Floorp Browser|floorp|N"
          "Google Chrome Browser|@FLT-GOOGLE|N"
          "LibreWolf Browser|librewolf|N"
          "UnGoogled Chromium Browser|ungoogled-chromiumm-xdg-bin|Y"
		  "Vivaldi Browser|vivaldi-widevine|N"
          "Thorium Browser|thorium-browser-bin|Y"
          "Waterfox Browser|waterfox|N"
          "=== Choose Office Tools ===||"
		  "Bluemail Email Client|bluemail|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|Y"
		  "Gnome Calculator|gnome-calculator|Y"
		  "gNumeric Spreadsheet|gnumeric-minimal|N"
          "Libre Office|libreoffice-fresh|N"
          "Mailspring Email Client|mailspring|N"
		  "Mousepad Notepad|mousepad|Y"
		  "NotepadQQ Editor|notepadqq-git|N"
		  "Notepad Next Editor|notepadnext-git|N"
		  "OnlyOffice Suite|onlyoffice-bin|Y"
          "Simple Scan|simple-scan|N"
		  "Standard Notes|standardnotes-bin|N"
		  "Thunderbird Email Client|thunderbird|N"
		  "WPS Office|wps-office|N"
          "=== Choose Social Media Tools ===||"
          "Twitter Client|twitter|N"
          "Facebook Client|facebook-desktop-app|N"
          "YouTube Client|youtube|N"
          "FreeTube - YouTube Client|freetube|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|skypeforlinux-bin|N"
          "Teams Video Conferencing|teams|N"
          "WhatsApp Conferencing|whatsapp-for-linux|N"
          "Zoom Video Conferencing|zoom|N"
          "=== Choose Development Tools ===||"
		  "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|vscodium|N"
          "VSCode IDE|visual-studio-code-bin|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|bleachbit-git|Y"
          "Clam Anti Virus|clamav|Y"
          "Clam Anti Virus GUI|clamtk-gnome|Y"
          "Disk Utility|gnome-disk-utility|Y"
		  "Fastfetch|fastfetch|Y"
		  "Flameshot Screenshot Utility|flameshot|Y"
		  "Gnome Software Manager|gnome-software|Y"
		  "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		  "Neofetch|neofetch|N"
          "Numlockx|numlockx|N"
          "Pika Backup|pika-backup-git|Y"
		  "Putty SSH Utility|putty|Y"
		  "Stacer|stacer-bin|Y"
		  "System Monitor|system-monitoring-center|N"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|N"
          "Flatsweep|@FLT-SWEEP|N"
          "Balena Etcher|etcher-bin|Y"
          "=== Choose Emulation Tools ===||"
		  "Bottles Windows Emulation|bottles|N"
          "Play On Linux|playonlinux|N"
		  "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine-stable|N"
          "Wine GUI|winegui|N"
          "Wine Tricks|winetricks-git|N"
          "=== Choose Virtualization Tools ===||"
		  "Docker|docker|N"
		  "Gnome Boxes|gnome-boxes|Y"
		  "Podman|podman|N"
		  "Virtualization Manager|virt-manager|N"
		  "Distrobox|distrobox-git|N"
		  "Distrobox GUI|boxbuddy|N"
          "=== Choose Optional Applications ===||"
		  "Calibre eBook Manager|calibre-git|N"
		  "Cheese Camera Utility|cheese|N"
		  "gThumb Image Viewer|gthumb-git|N"
          "Kodi Media Center|kodi-git|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		  "Spotify Client|spotify|N"
          "Strawberry Music Player|strawberry|N"
		  "VLC Media Player|vlc|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  # Disable Root Login
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
   sed -i s'#root:/bin/bash#root:/bin/nologin#' /etc/passwd >/dev/null
  fi
  _task-end

  # Update Terminal Profile
  _task-begin "Update $OS Terminal Profile"
  RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
  if [ ${RET} == 0 ]; then
     printf \"PS1='${PS1}'\nexport PS1\" | tee -a /etc/profile >/dev/null
  fi
  printf "${OVERWRITE}${OVERWRITE}"
  _task-end

  # Install Pipewire
  if (( $(_Exists "pipewire") == 0 )); then
     printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
	 pacman --noconfirm -S pipewire-full-git wireplumber pipewire-autostart >/dev/null
     _task-begin "Set Pipewire User Groups"
     addgroup ${SUDO_USER} audio >/dev/null
     addgroup ${SUDO_USER} video >/dev/null
     addgroup ${SUDO_USER} input >/dev/null
     _task-end
  fi
  addgroup ${SUDO_USER} plugdev >/dev/null
}

function _del_language {
  _task-begin "Deleting Language Files"
  _task-end
}

function _start_services {
  _task-begin "Starting Services"
  _task-end
}

function _set_aliases {
   if [[ -f $HDIR/.bash_aliases ]]; then
     if [[ ! $HDIR/.aliases ]]; then
        echo "alias update='sudo yay -Syu && sudo flatpak update'" | tee $HDIR/.bash_aliases >/dev/null
        echo "alias install='sudo yay -Sy '" | tee $HDIR/.bash_aliases >/dev/null
        echo "alias remove='sudo yay -R '" | tee $HDIR/.bash_aliases >/dev/null
	    touch $HDIR/.aliases >/dev/null
	 fi
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment on $OS  ===${RESTORE}\n\n"
  if [ ! -f /usr/share/.desktop ]; then
	 PROG=("gnome-control-center" "gnome-software-plugin-flatpak" "gnome-software-plugin-apk"
	       "lightdm" "lxterminal" "networkmanager" "network-manager-applet" "networkmanager-wifi"
		   "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman"
	       "wpa_supplicant" "volumeicon-alsa")

     case ${DSK^^} in
        'XFCE') PROG+=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin") ;;
      'BUDGIE') PROG+=("budgie-desktop" "budgie-control-center" "magpie") ;;
    'CINNAMON') PROG+=("cinnamon" "gnome-keyring" "colord" "gnome-terminal") ;;
     esac

     _add_by_list ${PROG[*]}
     touch /usr/share/.desktop >/dev/null
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _process_update() {
  printf "\n${LPURPLE}=== Perform System Update ===${RESTORE}\n"
  _task-begin "Updating System Packages"
  _task-end

  _task-begin "Updating Flatpak Packages"
  _task-end

  _task-begin "Updating DEB/XDEB Packages"
  _task-end
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"
   local PLIST=()

   if [[ ! -f ${HDIR}/.prereq ]]; then
      _task-begin "Updating Linux System"
      pacman -Syu >/dev/null
	  _task-end
	  
	  _task-begin "Installing Yay"
	  pacman --noconfirm -S --needed git base-devel curl wget unzip nano xz lxterminal jq >/dev/null
      git clone https://aur.archlinux.org/yay.git >/dev/null
	  chown -R ${SUDO_USER}:${SUDO_USER} ./yay >/dev/null
	  chmod -R 777 ./yay >/dev/null
      cd yay >/dev/null
      sudo -u ${SUDO_USER,,} makepkg -si >/dev/null
	  rm -rf yay >/dev/null
	  _task-end

      _task-begin "Installing Flatpak"
      pacman --noconfirm -S flatpak >/dev/null
      flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo' >/dev/null
      _task-end
	  touch ${HDIR}/.prereq >/dev/null
   fi
}