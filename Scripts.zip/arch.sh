#!/bin/bash

SYSList=("p7zip" "acpi" "acpid" "alsa-utils" "bash" "bash-completion" "bluez" "blueman" "cifs-utils" "cups" "cups-runit"
         "curl" "dconf" "dbus-runit" "fuse2" "git" "gvfs" "gvfs-mtp" "gvfs-smb" "jq" "nano" "pipewire" "wireplumber" "pipewire-pulse"
		 "preload" "sed" "udisks2" "unzip" "wget" "xarchiver" "xz")

DELList=("epiphany" "leafpad" "mpv" "parole" "xfburn" "xfce4-terminal" "xfce4-notes")
APPList+=("=== Choose Browser(s) ===||"
          "Brave Browser|brave-bin|N" 
          "Chromium Browser|chromium-widevine|N" 
		  "Falkon Browser|falkon|N"
          "Firefox Browser|firefox|N"
          "Floorp Browser|floorp|Y"
          "Google Chrome Browser|@FLT-GOOGLE|N"
          "LibreWolf Browser|librewolf|N"
          "UnGoogled Chromium Browser|ungoogled-chromiumm-xdg-bin|Y"
		  "Vivaldi Browser|vivaldi-widevine|N"
          "Thorium Browser|thorium-browser-bin|Y"
          "Waterfox Browser|waterfox|N"
          "=== Choose Office Tools ===||"
		  "Abiword Word Processor|abiword-git|N"
          "Bluemail Email Client|bluemail|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		  "Gnome Calculator|gnome-calculator|Y"
		  "gNumeric Spreadsheet|gnumeric-minimal|N"
          "Libre Office|libreoffice-fresh|N"
          "Mailspring Email Client|mailspring|N"
		  "Mousepad Notepad|mousepad|Y"
		  "NotepadQQ Editor|notepadqq-git|Y"
		  "Notepad Next Editor|notepadnext-git|N"
		  "OnlyOffice Suite|onlyoffice-bin|Y"
          "Simple Scan|simple-scan|Y"
		  "Standard Notes|standardnotes-bin|N"
		  "Thunderbird Email Client|thunderbird|Y"
		  "WPS Office|wps-office|N"
          "=== Choose Social Media Tools ===||"
          "Twitter Client|twitter|N"
          "Facebook Client|facebook-desktop-app|N"
          "YouTube Client|youtube|N"
          "FreeTube - YouTube Client|freetube|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|skypeforlinux-bin|N"
          "Teams Video Conferencing|teams|N"
          "WhatsApp Conferencing|whatsapp-for-linux|N"
          "Zoom Video Conferencing|zoom|N"
          "=== Choose Development Tools ===||"
		  "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|vscodium|N"
          "VSCode IDE|visual-studio-code-bin|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|bleachbit-git|Y"
          "Clam Anti Virus|clamav|N"
          "Clam Anti Virus GUI|clamtk-gnome|N"
          "Disk Utility|gnome-disk-utility|Y"
		  "Fastfetch|fastfetch|Y"
		  "Flameshot Screenshot Utility|flameshot|Y"
		  "Gnome Software Manager|gnome-software|Y"
		  "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		  "Neofetch|neofetch|N"
          "Numlockx|numlockx|N"
          "Pika Backup|pika-backup-git|Y"
		  "Putty SSH Utility|putty|Y"
		  "Stacer|stacer-bin|Y"
		  "System Monitor|system-monitoring-center|N"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|N"
          "Flatsweep|@FLT-SWEEP|N"
          "Balena Etcher|etcher-bin|Y"
          "=== Choose Emulation Tools ===||"
		  "Bottles Windows Emulation|bottles|N"
          "Play On Linux|playonlinux|N"
		  "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine-stable|N"
          "Wine GUI|winegui|N"
          "Wine Tricks|winetricks-git|N"
          "=== Choose Virtualization Tools ===||"
		  "Docker|docker|N"
		  "Gnome Boxes|gnome-boxes|Y"
		  "Podman|podman|N"
		  "Virtualization Manager|virt-manager|N"
		  "Distrobox|distrobox-git|N"
		  "Distrobox GUI|boxbuddy|N"
          "=== Choose Optional Applications ===||"
		  "Calibre eBook Manager|calibre-git|N"
		  "Cheese Camera Utility|cheese|N"
		  "gThumb Image Viewer|gthumb-git|N"
          "Kodi Media Center|kodi-git|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		  "Spotify Client|spotify|N"
          "Strawberry Music Player|strawberry|N"
		  "VLC Media Player|vlc|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  # Disable Root Login
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
    _run "sed -i s'#root:/bin/bash#root:/bin/nologin#' /etc/passwd"
  fi
  _task-end

  # Update Terminal Profile
  _task-begin "Update $OS Terminal Profile"
  RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
  if [ ${RET} == 0 ]; then
     _run "printf \"PS1='${PS1}'\nexport PS1\" | tee -a /etc/profile"
  fi
  printf "${OVERWRITE}${OVERWRITE}"
  _task-end

  # Install Pipewire
  if (( $(_Exists "pipewire") == 0 )); then
     printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
	 _run "pacman --noconfirm -S pipewire-full-git wireplumber pipewire-autostart"
     _task-begin "Set Pipewire User Groups"
     _run "addgroup ${SUDO_USER} audio"
     _run "addgroup ${SUDO_USER} video"
     _task-end
  fi
  _run "addgroup ${SUDO_USER} plugdev"         
}

function _del_language {
  _task-begin "Deleting Language Files"
  _task-end
}

function _start_services {
  _task-begin "Starting Services"
  _task-end
}

function _set_aliases {
   if [[ -f $HDIR/.bash_aliases ]]; then
     if [[ ! $HDIR/.aliases ]]; then
        echo "alias update='sudo yay -Syu'" | tee $HDIR/.bash_aliases
        echo "alias install='sudo yay -Sy '" | tee $HDIR/.bash_aliases
        echo "alias remove='sudo yay -R '" | tee $HDIR/.bash_aliases
	    touch $HDIR/.aliases
	 fi
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment on $OS  ===${RESTORE}\n\n"
  if [ ! -f /usr/share/.desktop ]; then

     PROG=("NetworkManager" "network-manager-applet" "gvfs-mtp" "gvfs-smb" "udisks2" "lxterminal"
	       "Thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman" "volumeicon")

     case ${DSK^^} in
        'XFCE') PROG+=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin") ;;
      'BUDGIE') PROG+=("budgie-desktop" "budgie-control-center" "magpie") ;;
    'CINNAMON') PROG+=("cinnamon" "gnome-keyring" "colord" "gnome-terminal") ;;
     esac

     _add_by_list ${PROG[*]}
     _run "touch /usr/share/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"
   local PLIST=()

   if [[ ! -f ${HDIR}/.prereq ]]; then
      printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n"
      _task-begin "Updating Linux System"
      _run "pacman -Syu"
	  _task-end
	  
	  _task-begin "Installing Yay"
	  _run "pacman -Sy --needed git base-devel curl wget unzip nano xz lxterminal"
      _run "git clone https://aur.archlinux.org/yay.git"
      _run "cd yay"
      _run "makepkg -si"
	  _task-end

      _task-begin "Installing Flatpak"
      _run "xbps-install -y flatpak git"
      _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
      _task-end
	  touch ${HDIR}/.prereq
   fi
   
}
