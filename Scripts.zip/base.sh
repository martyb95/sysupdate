#!/bin/bash
#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'
LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'
OVERWRITE='\e[1A\e[K'

TASK=""
REPLY=""
STP="777"
DTP="777"
OTP="777"
DSK="777"
LAY="777"
ADDList=()
APPList=()
DELList=()
SYSList=()

if [[ -z $HDIR ]]; then HDIR="/home/${SUDO_USER}"; fi
if [[ -z $LOG ]]; then LOG="${HDIR}/update.log"; fi

PS1="\[\033[0;31m\]\342\224\214\342\224\200\[\[\033[0;39m\]\u\[\033[01;33m\]@\[\033[01;96m\]\h\[\033[0;31m\]]\342\224\200[\[\033[0;32m\]\w\[\033[0;31m\]]\n\[\033[0;31m\]\342\224\224\342\224\200\342\224\200\342\224\200 \[\033[0m\]\[\e[01;33m\]\\$\[\e[0m\] "

#========================================================
#    Task Functions
#========================================================
function _run() {
    local _cmd="$1 >>$LOG 2>&1"
    printf "\n==== $TASK:  $1 ====\n\n" >> $LOG
    eval ${_cmd}
}

function _task-begin() {
   TASK=$1
   printf "\n\n============================= Start of $TASK =============================\n\n" >> ${LOG}
   printf "${LCYAN}    [ ]  ${TASK} \n${LRED}"
}

function _task-end() {
   printf "\n\n============================= End of $TASK =============================\n\n" >> ${LOG}
   printf "${OVERWRITE}${LGREEN}    [✓]  ${LGREEN}${TASK}${RESTORE}\n"
   TASK=""
}

function _log-msg() {
   printf "     ${1}\n" >> ${LOG}
}


#========================================================
#    Input Functions
#========================================================
function _Ask(){
  if  [[ ${2} != "" ]]; then
    REPLY=""
    printf "${LCYAN}${1} ${YELLOW}[${2}]: ${RESTORE}"
    read REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="${2}" ; fi
  else
    printf "${LCYAN}${1}: ${RESTORE}"
    read REPLY
  fi
  REPLY=${REPLY}
}

function _AskYN(){
  REPLY=""
  while [[ -z ${REPLY} ]]
  do
    printf "${LGREEN}${1}? ${YELLOW}[${2}]: ${RESTORE}"
    read -n 1 REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="$2" ; else echo " "; fi

    case ${REPLY^^} in
      [Y]* ) ;;
      [N]* ) ;;
      [R]* ) ;;
      * ) printf "${RED}ERROR - Invalid Option Entered [Y/N]${RESTORE}\n\n"; REPLY="";;
    esac
  done
  REPLY=${REPLY^^}
}

function _AskPass(){
  local PASS="UNKNOWN"
  local PASS2=""

  REPLY=""
  while [[ ${PASS} != ${PASS2} ]]
  do
    printf "${LCYAN}${1}: ${RESTORE}"
    read -s PASS
    printf "\n${LCYAN}${1} (Repeat): ${RESTORE}"
    read -s PASS2
    printf "\n"
    if [[ ${PASS} != ${PASS2} ]]; then
      printf "${RED}ERROR - Passwords do not match${RESTORE}\n\n"
    fi
  done
  REPLY=${PASS}
}

#========================================================
#    Package Functions
#========================================================
function _chooser() {
   if [ ${#APPList[@]} -gt 0 ]; then
      for i in {0..999}; do
         if (( i == ${#APPList[@]} )); then break; fi
         IFS='|' read -ra arr <<< ${APPList[i]}
         if [ ${#arr[0]} -gt 0 ]; then
	         if [ ! ${arr[0]:1:1} == "=" ]; then
	            if (( $(_Exists "${arr[1]}") == 0 )); then
	               _AskYN "Install ${arr[0]}${LGREEN} (y/n/r)" ${arr[2]^^}
	            else
	               _AskYN "Install $LRED${arr[0]}${LGREEN} (y/n/r)" "N"
	            fi
	            _PKG_List ${REPLY^^} ${arr[1]}
            else
               printf "\n${LPURPLE}${arr[0]}${RESTORE}\n"
	         fi
         fi
      done
   fi
}

function _default_apps {
   if [ ${#APPList[@]} -gt 0 ]; then
      _task-begin "Selecting Default Applications"
      for i in {0..999}; do
         if (( i == ${#APPList[@]} )); then break; fi
         IFS='|' read -ra arr <<< ${APPList[i]}
         if [ ${#arr[0]} -gt 0 ]; then
            if [ ! ${arr[0]:1:1} == "=" ]; then
               if [ ${arr[2]^^} == "Y" ]; then _PKG_List "Y" ${arr[1]}; fi
            fi
         fi
      done
      _task-end
   fi
 }

function _Exists() {
  local VAL=0
  VAL=$(_IsNative "$1")
  
  if (( $(_IsNative "flatpak") > 0 )); then
     if (( ${VAL} == 0 )); then VAL=$(flatpak list | grep -ic "${1}"); fi
  fi
  printf "%u" ${VAL}
}

function _IsNative() {
  local VAL=0
  case ${OS^^} in
     'ALPINE') VAL=$(apk list -I ${1} 2>/dev/null | grep -c "${1}") ;;
     'DEBIAN') VAL=$(apt list --installed ${1} 2>/dev/null | grep -c "${1/\*/}") ;;
       'VOID') VAL=$(xbps-query -l 2>/dev/null | grep -c "ii ${1}") ;;
       'ARCH') VAL=$(yay -Q ${1} 2>/dev/null | grep -c "${1}") ;;
  esac
  if [[ VAL == 0 ]]; then VAL=$(which ${1} 2>/dev/null |grep -C "${1/\*/}"); fi
  printf "%u" ${VAL}
}

function _PKG_List() {
  local _Ans=${1}
  local _Pkg=${2}

  case ${_Ans^^} in
     Y) _log-msg "_PKG_List Adding - ${_Pkg}\n"
	     ADDList+=(${_Pkg}) ;;
     R) if [ ${_Pkg^^} == "CLAMAV" ]; then _Pkg="clam*"; fi
	     if [ ${_Pkg^^} == "LIBREOFFICE" ]; then _Pkg="libreoffice*"; fi
        if [ ${_Pkg^^} == "WINEHQ-STABLE" ]; then _Pkg="wine*"; fi
        if [ ${_Pkg^^} == "WINE-STABLE" ]; then _Pkg="wine*"; fi
        if [ ${_Pkg^^} == "WINE" ]; then _Pkg="wine*"; fi
        if [ ${_Pkg^^} == "FIREFOX" ]; then _Pkg="firefox*"; fi
        DELList+=(${_Pkg})
        ;;
  esac
}

function _add_pkg() {
  local FLG=""
  if [[ ! -z $2 ]]; then FLG="${2^^}"; fi
  if (( $(_IsNative $1) == 0 )); then
     if [[ FLG != "QUIET" ]]; then _task-begin "Installing Package ${1^^}"; fi
	  _log-msg "Add-Native-Pkg - ${1}"
     case ${OS^^} in
        'ALPINE') _run "apk add $1" ;;
        'DEBIAN') _run "apt-get install -y $1" ;;
          'VOID') _run "xbps-install -y $1" ;;
          'ARCH') _run "yay --noconfirm -S $1" ;;
     esac
     if [[ FLG != "QUIET" ]]; then _task-end; fi
  else
     if [[ FLG != "QUIET" ]]; then _task-begin "${LRED}${1^^} Exists....Skipping"; fi
	  _log-msg "Add-Native-Pkg - ${1} Already Exists - Skipping"
     if [[ FLG != "QUIET" ]]; then _task-end; fi
  fi
}

function _add_by_list() {
  local Pkgs=${*}
  local Tmp=""
  if [ ${#Pkgs[@]} -gt 0 ]; then
    for Pkg in ${Pkgs[@]}; do
	   _log-msg "Add-By-List - ${Pkg}"
      if [[ ${Pkg:0:1} == "@" ]]; then
         _add_special ${Pkg}
      else
         _add_pkg ${Pkg}
      fi
    done
  fi
}

function _del_pkg() {
  if (( $(_IsNative $1) > 0 )); then
     _task-begin "Removing ${1^^} from ${OS^^}"
	  _log-msg "DEL-PKG - Deleting Native Package - Pkg=${1}"
     case ${OS^^} in
        'ALPINE') _run "apk del $1" ;;
        'DEBIAN') _run "apt-get purge -y $1" ;;
          'VOID') _run "xbps-remove -foOy $1" ;;
          'ARCH') _run "yay --noconfirm -Rs $1" ;;
     esac
     _task-end
  else
     _task-begin "${LRED}${1^^} Does NOT Exists....Skipping"  
	  _log-msg "DEL-PKG - Pkg=${1} Does Not Exist"
     _task-end          
  fi
}

function _del_by_list() {
  local Pkgs=${*}
  if [ ${#Pkgs[@]} -gt 0 ]; then
    for Pkg in ${Pkgs[@]}; do
	   _log-msg "Del-By-List - ${Pkg}"
	   if [[ ${Pkg:0:1} == "@" ]]; then
	      _del_special ${Pkg}
	   else
	      _del_pkg ${Pkg}
	   fi
    done
  fi
}

function _add_flatpak {
  if [ $(flatpak list | grep -c ${2}) -eq 0 ]; then
    _task-begin "Installing Flatpak ${1^^}"
	 _log-msg "ADD-FLATPAK - Pkg=${2}"
    _run "flatpak install flathub -y --noninteractive --reinstall ${2}"
	 _task-end
  fi
}

function _del_flatpak {
  if [ $(flatpak list | grep -c ${2}) -gt 0 ]; then
    _task-begin "Removing Flatpak ${1^^}"
	 _log-msg "DEL-FLATPAK - Pkg=${2}"
    _run "flatpak uninstall -y --noninteractive --force-remove --delete-data ${2}"
	 _task-end
  fi
}

function _add_xdeb {
  local KEY=$(echo "${1^^}" | cut -d " " -f1)
  local REL=""
  local RELN=""
  local URL=""
  local DFIL=""
  local PKG=""
  local INST=""
  
  if [[ $(_Exists ${KEY,,}) == 0 ]]; then
  _log-msg "ADD-XDB - KEY=$KEY"
  case ${KEY^^} in
     BALENA)
	      REL=$(curl -sL https://api.github.com/repos/balena-io/etcher/releases/latest | jq -r ".tag_name")
         RELN=${REL//v}
		   #https://github.com/balena-io/etcher/releases/download/v1.19.21/balena-etcher_1.19.21_amd64.deb
         URL="https://github.com/balena-io/etcher/releases/download/${REL}/balena-etcher_${RELN}_amd64.deb"
	      DFIL="balena-etcher_${RELN}_amd64.deb"
		   PKG="balena-etcher"
         ;;
     STACER)
	      REL=$(curl -sL https://api.github.com/repos/oguzhaninan/Stacer/releases/latest | jq -r ".tag_name")
         RELN=${REL//v}
		   #https://github.com/oguzhaninan/Stacer/releases/download/v1.1.0/stacer_1.1.0_amd64.deb
         URL="https://github.com/oguzhaninan/Stacer/releases/download/${REL}/stacer_${RELN}_amd64.deb"
	      DFIL="stacer_${RELN}_amd64.deb"
		   PKG="stacer"
         ;;
     THORIUM)
	      REL=$(curl -sL https://api.github.com/repos/Alex313031/thorium/releases/latest | jq -r ".tag_name")
         RELN=${REL//M}
		   #https://github.com/Alex313031/thorium/releases/download/M124.0.6367.218/thorium-browser_124.0.6367.218_AVX2.deb
		   INST="SSE3"
		   if [[ $(grep -c sse4 /proc/cpuinfo) > 0 ]]; then INST="SSE4"; fi
		   if [[ $(grep -c avx /proc/cpuinfo) > 0 ]]; then INST="AVX"; fi
		   if [[ $(grep -c avx2 /proc/cpuinfo) > 0 ]]; then INST="AVX2"; fi
         URL="https://github.com/Alex313031/thorium/releases/download/${REL}/thorium-browser_${RELN}_${INST}.deb"
	      DFIL="thorium-browser_${RELN}_${INST}.deb"
		   PKG="thorium-browser"
         ;;
   esac
  _log-msg "ADD-XDB - REL=$REL, RELN=$RELN\n\tURL=$URL\n\tDFIL=$DFIL, PKG=$PKG"
  
  _task-begin "Installing XDEB $1"
  _run "cd $HDIR"
  _run "rm -f ./${DFIL}"
  _run "wget -q ${URL}"
  _run "xdeb ./${DFIL}"
  _run "xbps-install -y -R $HDIR/.config/xdeb/binpkgs/ ${PKG}"
  _run "rm -f ./${DFIL}"
  _run "cd $HDIR/scripts"  
  _task-end
  fi
}

function _add_deb {
  local KEY=$(echo "${1^^}" | cut -d " " -f1)
  local REL=""
  local RELN=""
  local URL=""
  local DFIL=""
  local INST=""
  
  if [[ $(_Exists ${KEY,,}) == 0 ]]; then
  _log-msg "ADD-DEB - KEY=$KEY"
  case ${KEY^^} in
     BALENA)
	      REL=$(curl -sL https://api.github.com/repos/balena-io/etcher/releases/latest | jq -r ".tag_name")
         RELN=${REL//v}
		   #https://github.com/balena-io/etcher/releases/download/v1.19.21/balena-etcher_1.19.21_amd64.deb
         URL="https://github.com/balena-io/etcher/releases/download/${REL}/balena-etcher_${RELN}_amd64.deb"
	      DFIL="balena-etcher_${RELN}_amd64.deb"
         ;;
     STACER)
	      REL=$(curl -sL https://api.github.com/repos/oguzhaninan/Stacer/releases/latest | jq -r ".tag_name")
         RELN=${REL//v}
		   #https://github.com/oguzhaninan/Stacer/releases/download/v1.1.0/stacer_1.1.0_amd64.deb
         URL="https://github.com/oguzhaninan/Stacer/releases/download/${REL}/stacer_${RELN}_amd64.deb"
	      DFIL="stacer_${RELN}_amd64.deb"
         ;;
     FASTFETCH)
	      REL=$(curl -sL https://api.github.com/repos/fastfetch-cli/fastfetch/releases/latest | jq -r ".tag_name")
         RELN=${REL//M}
         URL="https://github.com/fastfetch-cli/fastfetch/releases/download/${REL}/fastfetch-linux-amd64.deb"
	      DFIL="fastfetch-linux-amd64.deb"
         ;;
     THORIUM)
	      REL=$(curl -sL https://api.github.com/repos/Alex313031/thorium/releases/latest | jq -r ".tag_name")
         RELN=${REL//M}
		   #https://github.com/Alex313031/thorium/releases/download/M124.0.6367.218/thorium-browser_124.0.6367.218_AVX2.deb
		   INST="SSE3"
		   if [[ $(grep -c sse4 /proc/cpuinfo) > 0 ]]; then INST="SSE4"; fi
		   if [[ $(grep -c avx /proc/cpuinfo) > 0 ]]; then INST="AVX"; fi
		   if [[ $(grep -c avx2 /proc/cpuinfo) > 0 ]]; then INST="AVX2"; fi
         URL="https://github.com/Alex313031/thorium/releases/download/${REL}/thorium-browser_${RELN}_${INST}.deb"
	      DFIL="thorium-browser_${RELN}_${INST}.deb"
         ;;
   esac

  _log-msg "ADD-DEB - REL=$REL, RELN=$RELN\n\tURL=$URL\n\tDFIL=$DFIL"
  
  _task-begin "Installing DEB $1"
  _run "cd $HDIR"
  _run "rm -f ./${DFIL}"
  _run "wget -q ${URL}"
  _run "apt-get install -y ./${DFIL}"
  _run "rm -f ./${DFIL}"
  _run "cd $HDIR/scripts"  
  _task-end
  fi
}

function _add_special() {
  local KEY=${1:1:3}
  local PKG=${1:1:15}
  
  _log-msg "Adding Special - Key=${KEY}, Pkg=${PKG}"
  case ${KEY^^} in
     XDB)  case ${PKG^^} in
               XDB-ETCHER) _add_xdeb "Balena Etcher" ;;
               XDB-STACER) _add_xdeb "Stacer Monitor" ;;			   
              XDB-THORIUM) _add_xdeb "Thorium Browser" ;;			   
           esac
           ;;			   
     DEB)  case ${PKG^^} in
               DEB-ETCHER) _add_deb "Balena Etcher" ;;
               DEB-STACER) _add_deb "Stacer Monitor" ;;			   
              DEB-THORIUM) _add_deb "Thorium Browser" ;;			   
           esac
           ;;			   
     FLT) case ${PKG^^} in
            FLT-BRAVE) _add_flatpak "Brave Browser" "com.brave.Browser" ;;
           FLT-CHROME) _add_flatpak "Chromium Browser" "org.chromium.Chromium" ;;
           FLT-FALKON) _add_flatpak "Falkon Browser" "org.kde.falkon" ;;
          FLT-FIREFOX) _add_flatpak "Firefox Browser" "org.mozilla.firefox" ;;
           FLT-FLOORP) _add_flatpak "Floorp Browser" "one.ablaze.floorp" ;;
           FLT-GOOGLE) _add_flatpak "Google Browser" "com.google.Chrome" ;;
         FLT-UNGOOGLE) _add_flatpak "UnGoogled Chromium Browser" "io.github.ungoogled_software.ungoogled_chromium" ;;
          FLT-VIVALDI) _add_flatpak "Vivaldi Browser" "com.vivaldi.Vivaldi" ;;
            FLT-WATER) _add_flatpak "Waterfox Browser" "net.waterfox.waterfox" ;;
             FLT-WOLF) _add_flatpak "Librewolf Browser" "io.gitlab.librewolf-community" ;;

             FLT-BLUE) _add_flatpak "Bluemail Email Client" "net.blix.BlueMail" ;;
             FLT-MAIL) _add_flatpak "Mailspring" "com.getmailspring.Mailspring" ;;
             FLT-ONLY) _add_flatpak "Only Office" "org.onlyoffice.desktopeditors" ;;
              FLT-WPS) _add_flatpak "WPS Office" "com.wps.Office" ;;
          FLT-NOTEPAD) _add_flatpak "Notepadqq" "com.notepadqq.Notepadqq" ;;
             FLT-NEXT) _add_flatpak "Notepad Next" "com.github.dail8859.NotepadNext" ;;
            FLT-NOTES) _add_flatpak "Standard Notes" "org.standardnotes.standardnotes" ;;
           FLT-CLAMTK) _add_flatpak "ClamTK" "com.gitlab.davem.ClamTk" ;;
          FLT-MONITOR) _add_flatpak "System Monitor" "io.github.hakandundar34coding.system-monitoring-center" ;;

             FLT-BOOK) _add_flatpak "Calibre" "com.calibre_ebook.calibre" ;;
            FLT-MUSIC) _add_flatpak "Strawberry Music Player" "org.strawberrymusicplayer.strawberry" ;;
             FLT-SPOT) _add_flatpak "Spotify" "com.spotify.Client" ;;
             FLT-TWIT) _add_flatpak "Choqok Twitter Client" "org.kde.choqok" ;;
             FLT-FACE) _add_flatpak "Caprine Facebook Client" "com.sindresorhus.Caprine" ;;
             FLT-TUBE) _add_flatpak "FreeTube" "io.freetubeapp.FreeTube" ;;
            FLT-SKYPE) _add_flatpak "Skype Conferencing" "com.skype.Client" ;;
            FLT-TEAMS) _add_flatpak "Teams Conferencing" "com.github.IsmaelMartinez.teams_for_linux" ;;
             FLT-WHAT) _add_flatpak "WhatsApp" "com.github.eneshecan.WhatsAppForLinux" ;;
             FLT-ZOOM) _add_flatpak "Zoom Meeting" "us.zoom.Zoom";;
             FLT-KODI) _add_flatpak "Kodi Media Center" "tv.kodi.Kodi" ;;
              FLT-MPV) _add_flatpak "MPV" "io.mpv.Mpv" ;;

             FLT-WARE) _add_flatpak "Warehouse" "io.github.flattool.Warehouse" ;;
            FLT-SWEEP) _add_flatpak "FlatSweep Flatpak Maintenance" "io.github.giantpinkrobots.flatsweep" ;;
          FLT-IMPRESS) _add_flatpak "Impression USB Writer" "io.gitlab.adhami3310.Impression" ;;
             FLT-PLAY) _add_flatpak "Play On Linux" "com.playonlinux.PlayOnLinux4" ;;
           FLT-BLEACH) _add_flatpak "BleachBit Utility" "org.bleachbit.BleachBit" ;;
             FLT-CODE) _add_flatpak "VSCodium" "com.vscodium.codium" ;;
           FLT-VSCODE) _add_flatpak "VSCodium" "com.visualstudio.code" ;;
            FLT-FLAME) _add_flatpak "Flameshot" "org.flameshot.Flameshot" ;;
             FLT-CLAM) _add_flatpak "ClamTK" "com.github.davem.Clamtk" ;;
             FLT-PIKA) _add_flatpak "Pika Backup" "org.gnome.World.PikaBackup" ;;
           FLT-BOTTLE) _add_flatpak "Bottles" "com.usebottles.bottles" ;;
			    FLT-WGUI) _add_flatpak "Wine GUI" "io.github.aggalex.Wineglass" ;;
		  esac
        ;;
  esac
}

function _del_special() {
  local KEY=${1:1:3}
  local PKG=${1:1:15}
  
  _log-msg "Deleting Special - Key=${KEY}, Pkg=${PKG}"
  case ${KEY^^} in
     FLT) case ${PKG^^} in
           FLT-BRAVE) _del_flatpak "Brave Browser" "com.brave.Browser" ;;
          FLT-CHROME) _del_flatpak "Chromium Browser" "org.chromium.Chromium" ;;
          FLT-FALKON) _del_flatpak "Falkon Browser" "org.kde.falkon" ;;
         FLT-FIREFOX) _del_flatpak "Firefox Browser" "org.mozilla.firefox" ;;
          FLT-FLOORP) _del_flatpak "Floorp Browser" "one.ablaze.floorp" ;;
          FLT-GOOGLE) _del_flatpak "Google Browser" "com.google.Chrome" ;;
        FLT-UNGOOGLE) _del_flatpak "UnGoogled Chromium Browser" "io.github.ungoogled_software.ungoogled_chromium" ;;
         FLT-VIVALDI) _del_flatpak "Vivaldi Browser" "com.vivaldi.Vivaldi" ;;
           FLT-WATER) _del_flatpak "Waterfox Browser" "net.waterfox.waterfox" ;;
            FLT-WOLF) _del_flatpak "Librewolf Browser" "io.gitlab.librewolf-community" ;;

            FLT-BLUE) _del_flatpak "Bluemail Email Client" "net.blix.BlueMail" ;;
            FLT-MAIL) _del_flatpak "Mailspring" "com.getmailspring.Mailspring" ;;
            FLT-ONLY) _del_flatpak "Only Office" "org.onlyoffice.desktopeditors" ;;
             FLT-WPS) _del_flatpak "WPS Office" "com.wps.Office" ;;
         FLT-NOTEPAD) _del_flatpak "Notepadqq" "com.notepadqq.Notepadqq" ;;
            FLT-NEXT) _del_flatpak "Notepad Next" "com.github.dail8859.NotepadNext" ;;
           FLT-NOTES) _del_flatpak "Standard Notes" "org.standardnotes.standardnotes" ;;
          FLT-CLAMTK) _del_flatpak "ClamTK" "com.gitlab.davem.ClamTk" ;;
		 FLT-MONITOR) _add_flatpak "System Monitor" "io.github.hakandundar34coding.system-monitoring-center" ;;

            FLT-BOOK) _del_flatpak "Calibre" "com.calibre_ebook.calibre" ;;
           FLT-MUSIC) _del_flatpak "Strawberry Music Player" "org.strawberrymusicplayer.strawberry" ;;
            FLT-SPOT) _del_flatpak "Spotify" "com.spotify.Client" ;;
            FLT-TWIT) _del_flatpak "Choqok Twitter Client" "org.kde.choqok" ;;
            FLT-FACE) _del_flatpak "Caprine Facebook Client" "com.sindresorhus.Caprine" ;;
            FLT-TUBE) _del_flatpak "FreeTube" "io.freetubeapp.FreeTube" ;;
           FLT-SKYPE) _del_flatpak "Skype Conferencing" "com.skype.Client" ;;
           FLT-TEAMS) _del_flatpak "Teams Conferencing" "com.github.IsmaelMartinez.teams_for_linux" ;;
            FLT-WHAT) _del_flatpak "WhatsApp" "com.github.eneshecan.WhatsAppForLinux" ;;
            FLT-ZOOM) _del_flatpak "Zoom Meeting" "us.zoom.Zoom";;
            FLT-KODI) _del_flatpak "Kodi Media Center" "tv.kodi.Kodi" ;;
             FLT-MPV) _del_flatpak "MPV" "io.mpv.Mpv" ;;

            FLT-WARE) _del_flatpak "Warehouse" "io.github.flattool.Warehouse" ;;
           FLT-SWEEP) _del_flatpak "FlatSweep Flatpak Maintenance" "io.github.giantpinkrobots.flatsweep" ;;
         FLT-IMPRESS) _del_flatpak "Impression USB Writer" "io.github.adham3310.Impression" ;;
            FLT-PLAY) _del_flatpak "Play On Linux" "com.playonlinux.PlayOnLinux4" ;;
          FLT-BLEACH) _del_flatpak "BleachBit Utility" "org.bleachbit.BleachBit" ;;
            FLT-CODE) _del_flatpak "VSCodium" "com.vscodium.codium" ;;
          FLT-VSCODE) _del_flatpak "VSCodium" "com.visualstudio.code" ;;
           FLT-FLAME) _del_flatpak "Flameshot" "org.flameshot.Flameshot" ;;
            FLT-CLAM) _del_flatpak "ClamTK" "com.github.davem.Clamtk" ;;
            FLT-PIKA) _del_flatpak "Pika Backup" "org.gnome.World.PikaBackup" ;;
          FLT-BOTTLE) _del_flatpak "Bottles" "com.usebottles.bottles" ;;
            FLT-WGUI) _del_flatpak "Wine GUI" "io.github.aggalex.Wineglass" ;;			   
		   esac
           ;;
  esac
}

#========================================================
#    Processing Functions
#========================================================
function _parm_out {
    if [[ -f ${HDIR}/param.dat ]]; then rm -f ${HDIR}/param.dat; fi
    if [[ -z $DSK ]]; then
       case ${REALOS^^} in
          'LINUXMINT') DSK="CINNAMON" ;;
                    *) DSK="XFCE" ;;
       esac
    fi
    if [[ -z $LAY ]]; then
       case ${REALOS^^} in
          'LINUXMINT') LAY="BOTTOMYELLOW" ;;
                    *) LAY="TOPYELLOW" ;;
       esac
    fi
    echo "DESKTOP=${DSK}" > ${HDIR}/param.dat
    echo "LAYOUT=${LAY}" >> ${HDIR}/param.dat
    _run "chown $SUDO_USER:$SUDO_USER ${HDIR}/param.dat"
}

function _parm_in {
   if [[ -f ${HDIR}/param.dat ]]; then
      grep "${1}" ${HDIR}/param.dat | cut -d'=' -f2
   fi
}

function _setValue {
   local KEY="$1"
   local VALUE="$2"

   if [ ${VALUE:0:1} == "'" ]; then
      #_run "sudo -u ${SUDO_USER,,} DBUS_SESSION_BUS_ADDRESS=\"$ADDR\" dconf write ${KEY} \"${VALUE}\""
      _run "dconf write ${KEY} \"${VALUE}\""
   else
      #_run "sudo -u ${SUDO_USER,,} DBUS_SESSION_BUS_ADDRESS=\"$ADDR\" dconf write ${KEY} ${VALUE}"
      _run "dconf write ${KEY} ${VALUE}"
   fi
}

function _getValue {
   local KEY="$1"
   #local RET=$(sudo -u ${SUDO_USER,,} DBUS_SESSION_BUS_ADDRESS=\"$ADDR\" dconf read ${KEY})
   local RET=$(dconf read ${KEY})
   printf "${RET}"
}

function _valXExists() {
   local RET=0
   local VAL=""
   if [[ ! -z $1 ]]; then VAL=$(_getXValue $1 $2); fi
   if [[ ! -z $VAL ]]; then RET=1; fi
   printf "$RET"
}

function _getXValue() {
   local RET=""
   if [[ ! -z $1 ]]; then 
      if [[ ! -z $2 ]]; then RET=$(xfconf-query -c $1 -p "$2" >/dev/null 2>&1); fi
   fi
   printf "$RET"
}

function _setXValue() {
   if [[ ! -z $1 ]]; then 
      if [[ ! -z $2 ]]; then 
         if [[ ! -z $3 ]]; then
            if [[ $(_valXExists "$1" "$2") == "1" ]]; then
               if [[ ${3} == *" "* ]]; then
                  _run "xfconf-query -c $1 -p $2 -s '$3'"
               else
                  _run "xfconf-query -c $1 -p $2 -s $3"
               fi
            else
               TYP=$4
               if [[ -z $TYP ]]; then TYP="string"; fi
               if [[ ${3} == *" "* ]]; then
                  _run "xfconf-query -c $1 -p $2 -n -t ${TYP,,} -s '$3'"
               else
                  _run "xfconf-query -c $1 -p $2 -n -t ${TYP,,} -s $3"
               fi
            fi
         fi
      fi
   fi      
}

function _install_nerdfonts {
   if [ ! -f ${HDIR}/scripts/skipdir/.fonts ]; then
      if [ ! -d ${HDIR}/.local/share/fonts ]; then _run "mkdir -p ${HDIR}/.local/share/fonts"; fi
      if [ ! -d ${HDIR}/tmp ]; then _run "mkdir ${HDIR}/tmp"; fi
      _run "cd ${HDIR}/tmp"
	  #local FONTList=("CascadiaCode" "DejaVuSansMono" "FiraCode" "Go-Mono" "Hack" "Inconsolata" "Iosevka" "JetBrainsMono"
      #                "LiberationMono" "Mononoki" "Noto" "RobotoMono" "SourceCodePro" "Terminus" "UbuntuMono" )
	  local FONTList=("CascadiaCode" "Inconsolata" "JetBrainsMono" "Terminus" )
      RET=$(curl -sL https://api.github.com/repos/ryanoasis/nerd-fonts/releases/latest | jq -r ".tag_name")
      for font in ${FONTList[@]}
      do
         URL="https://github.com/ryanoasis/nerd-fonts/releases/download/${RET}/${font}.zip"
         _run "wget -q $URL"
         if [ -f $font.zip ]; then
		    _task-begin "Installing Font - $font"
            _run "unzip -o -q $font.zip -d ${HDIR}/.local/share/fonts/$font/"
	        _run "rm $font.zip"
			_task-end
         fi
     done
     _run "fc-cache"
     if [ -d ${HDIR}/tmp ]; then _run "rm -rf ${HDIR}/tmp"; fi
     _run "touch ${HDIR}/scripts/skipdir/.fonts"
   fi
}

function _get_setup_file {
   _task-begin "Download Customization File"
   if [ ! -d ${HDIR}/sys-setup ]; then
      _run "cd ${HDIR}"
      _run "mkdir ${HDIR}/sys-setup"
   fi

   #Download file
   if [ ! -f ${HDIR}/sys-setup/sys.zip ]; then
     _run "cd ${HDIR}/sys-setup"
     _run "wget -q https://tinyurl.com/sys-base4"
     if [ -f ${HDIR}/sys-setup/sys-base4 ]; then
       _run "mv -f sys-base4 sys.zip"
       _run "unzip -o -q sys.zip"
     else
       _log-msg "ERROR - ${HDIR}/sys-setup/sys-base4 NOT found"
     fi
     _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/sys-setup"
     _run "cd ${HDIR}"
   else 
      _log-msg "ERROR - ${HDIR}/sys-setup/sys.zip NOT found"
   fi
   _task-end
}

function _customize_icons {
   if [ ! -f ${HDIR}/scripts/skipdir/.icons ]; then
      if [ -f ${HDIR}/sys-setup/sys.zip ]; then
         _task-begin "Install Icons"
         local PList=()
         if [ ! -d /usr/share/icons ]; then _run "mkdir -p /usr/share/icons"; fi
         _log-msg "Parameters Desktop=$DSK, Layout=$LAY"
         case ${LAY^^} in
         'TOPYELLOW'|'BOTTOMYELLOW') 
               if [ ! -d /usr/share/icons/'Boston cardboard' ]; then
                  _run "mv -f ${HDIR}/sys-setup/icons/Boston-Cardboard.tar.xz /usr/share/icons/"
                  _run "cd /usr/share/icons/"
                  _run "tar -xf Boston-Cardboard.tar.xz"
                  _run "rm -f Boston-Cardboard.tar.xz"
                  _run "gtk-update-icon-cache /usr/share/icons/'Boston cardboard'"
               fi
               
               if [[ ${OS^^} == "ARCH" ]]; then 
                   PLIST=("gnome-colors-icon-theme-bin" "tango-icon-theme")
               else
                   PList=("gnome-dust-icon-theme" "tango-icon-theme")
               fi
               _task-end
               ;;
         'TOPBLUE'|'BOTTOMBLUE') 
               if [ ! -d /usr/share/icons/Flatery-Sky ]; then
                  _run "mv -f ${HDIR}/sys-setup/icons/Flatery-Sky.tar.gz /usr/share/icons"
                  _run "cd /usr/share/icons/"
                  _run "tar -xf Flatery-Sky.tar.gz"
                  _run "rm -f Flatery-Sky.tar.gz"
                  _run "gtk-update-icon-cache /usr/share/icons/Flatery-Sky"
                  _run "gtk-update-icon-cache /usr/share/icons/Flatery-Sky-Dark"
               fi

               if [[ ${OS^^} == "ARCH" ]]; then 
                   PLIST=("gnome-colors-icon-theme-bin" "tango-icon-theme")
               else
                   PList=("gnome-icon-theme" "tango-icon-theme")
               fi
               _task-end
               ;;
         esac
         _add_by_list ${PList[*]}
         _run "cd ${HDIR}"
      fi
      _run "touch ${HDIR}/scripts/skipdir/.icons"   
   fi
}

function _customize_themes {
   if [ ! -f ${HDIR}/scripts/skipdir/.themes ]; then
      if [ -f ${HDIR}/sys-setup/sys.zip ]; then
         _task-begin "Install Themes"
         if [ ! -d /usr/share/themes ]; then _run "mkdir -p /usr/share/themes"; fi
         _log-msg "Parameters Desktop=$DSK, Layout=$LAY"
         case ${LAY} in
         'TOPYELLOW'|'BOTTOMYELLOW') 
               if [ ! -d /usr/share/themes/Orchis-Yellow-Dark ]; then
                  _run "cd /usr/share/themes/"
                  _run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Yellow.tar.xz"
                  _run "tar -xf Orchis-Yellow.tar.xz"
                  _run "rm -f Orchis-Yellow.tar.xz"
                  _run "rm -rf Orchis-Yellow-Compact"
                  _run "rm -rf Orchis-Yellow-Dark-Compact"
                  _run "rm -rf Orchis-Yellow-Light*"
                  _run "rm -rf Orchis-Yellow"
               fi
               if [ ! -d /usr/share/themes/Orchis-Teal-Dark ]; then
                  _run "cd /usr/share/themes/"
                  _run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Teal.tar.xz"
                  _run "tar -xf Orchis-Teal.tar.xz"
                  _run "rm -f Orchis-Teal.tar.xz"
                  _run "rm -rf Orchis-Teal-Compact"
                  _run "rm -rf Orchis-Teal-Dark-Compact"
                  _run "rm -rf Orchis-Teal-Light*"
                  _run "rm -rf Orchis-Teal"
               fi
               if [ ! -d /usr/share/themes/Skeuos-Yellow-Dark ]; then
                  _run "cd /usr/share/themes"
                  _run "mv -f ${HDIR}/sys-setup/themes/Skeuos-Yellow.tar.xz /usr/share/themes"
                  _run "cd /usr/share/themes/"
                  _run "tar -xf Skeuos-Yellow.tar.xz"
                  _run "rm -f Skeuos-Yellow.tar.xz"
                  _run "rm -rf Skeuos-Yellow-Light*"
                  _run "rm -rf Skeuos-Yellow-Dark-*"
               fi
               ;;
         'TOPBLUE'|'BOTTOMBLUE') 
               if [ ! -d /usr/share/themes/Orchis-Dark ]; then
                  _run "cd /usr/share/themes/"
                  _run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis.tar.xz"
                  _run "tar -xf Orchis.tar.xz"
                  _run "rm -f Orchis.tar.xz"
                  _run "rm -rf Orchis-Compact"
                  _run "rm -rf Orchis-Dark-Compact"
                  _run "rm -rf Orchis-Light*"
                  _run "rm -rf Orchis"
               fi
               if [ ! -d /usr/share/themes/Skeuos-Blue-Dark ]; then
                  _run "cd /usr/share/themes"
                  _run "mv -f ${HDIR}/sys-setup/themes/Skeuos-Blue.tar.xz /usr/share/themes"
                  _run "cd /usr/share/themes/"
                  _run "tar -xf Skeuos-Blue.tar.xz"
                  _run "rm -f Skeuos-Blue.tar.xz"
                  _run "rm -rf Skeuos-Blue-Light*"
                  _run "rm -rf Skeuos-Blue-Dark-F*"
                  _run "rm -rf Skeuos-Blue-Dark-G*"
                  _run "rm -rf Skeuos-Blue-Dark-X*"
               fi
               if [ ! -d /usr/share/themes/Fluent-Dark ]; then
                  _run "cd /usr/share/themes"
                  _run "mv -f ${HDIR}/sys-setup/themes/Fluent-Dark.tar.xz /usr/share/themes"
                  _run "cd /usr/share/themes/"
                  _run "tar -xf Fluent-Dark.tar.xz"
                  _run "rm -f Fluent-Dark.tar.xz"
               fi
               if [ ! -d /usr/share/themes/Goldy-Dark-GTK ]; then
                  _run "cd /usr/share/themes"
                  _run "mv -f ${HDIR}/sys-setup/themes/Goldy-Dark-GTK.tar.gz /usr/share/themes"
                  _run "cd /usr/share/themes/"
                  _run "tar -xf Goldy-Dark-GTK.tar.gz"
                  _run "rm -f Goldy-Dark-GTK.tar.gz"
               fi
         ;;
         esac
         _run "cd ${HDIR}"
         _task-end
      fi
      _run "touch ${HDIR}/scripts/skipdir/.themes"
   fi
}

function _customize_lightdm {
   if [ -f ${HDIR}/sys-setup/sys.zip ]; then
      if [ ! -f ${HDIR}/scripts/skipdir/.lightdm ]; then
         _task-begin "Install LightDM Configuration"	  
         DSK=$(_parm_in "DESKTOP")
         LAY=$(_parm_in "LAYOUT")
         _log-msg "Parameters Desktop=$DSK, Layout=$LAY"

         _run "cd ${HDIR}/sys-setup/lightdm"
		 # === Setup the LIGHTDM.CONF File ===
         local _FILE=/etc/lightdm/lightdm.conf
         if [ -f ${_FILE} ]; then _run "mv -f ${_FILE} ${_FILE}.bak"; fi
         local PRT="[LightDM]\n#\n[Seat:*]\ngreeter-hide-users=false\n"
		   if [[ ${OS^^} == "VOID" ]]; then PRT="${PRT}session-wrapper=/etc/lightdm/Xsession\n"; fi
		   PRT="${PRT}#\n[XDMCPServer]\n#\n[VNCServer]\n#\n"
         printf "${PRT}" | tee ${_FILE} >/dev/null

		 # === Setup the LIGHTDM-GTK-GREETER.CONF File ===
         _FILE=/etc/lightdm/lightdm-gtk-greeter.conf
         if [ -f ${_FILE} ]; then _run "mv -f ${_FILE} ${_FILE}.bak"; fi
         PRT="[greeter]\n"
	      case ${LAY} in
            'TOPYELLOW'|'BOTTOMYELLOW') 
                 PRT="${PRT}background=/usr/share/backgrounds/iB38gbGjiAxVdT2h.jpg\n"
                 PRT="${PRT}theme-name=Orchis-Teal-Dark\n"
                 PRT="${PRT}icon-theme-name = Tango\n"
                 PRT="${PRT}postition=66%%,center 55%%,center\n"        
                 ;;
            'TOPBLUE'|'BOTTOMBLUE') 
                 PRT="${PRT}background=/usr/share/backgrounds/8pplzWJvxVoxqrCE.jpg\n"
                 PRT="${PRT}theme-name=Orchis-Dark\n"
                 PRT="${PRT}icon-theme-name=Tango\n"   
                 PRT="${PRT}postition=80%%,center 55%%,center\n"
 	              ;;
         esac
         PRT="${PRT}user-background=false\n"
         PRT="${PRT}show-clock=false\n"
         printf "${PRT}" | tee ${_FILE} >/dev/null
	      _run "touch ${HDIR}/scripts/skipdir/.lightdm"
	      _run "cd ${HDIR}"
         printf "${OVERWRITE}"
		   _task-end
      else
         _log-msg "LightDM already processed"
      fi
   else
      _log-msg "ERROR - ${HDIR}/sys-setup/sys.zip NOT found"
   fi
}

function _customize_grub {
   if [ ! -f ${HDIR}/scripts/skipdir/.grub ]; then
      if [ ! -d ${HDIR}/sys-setup ]; then _run "mkdir -p ${HDIR}/sys-setup"; fi
      case ${OS^^} in
       'ALPINE') ;;
              *) _task-begin "Install Grub Background"
                 _run "cd ${HDIR}/sys-setup/"
	             if [ -d ${HDIR}/sys-setup/grub2-themes ]; then _run "rm -rf ${HDIR}/sys-setup/grub2-themes"; fi
	             _run "git clone https://github.com/vinceliuice/grub2-themes"
	             if [ -d ${HDIR}/sys-setup/grub2-themes ]; then
                    _run "cd ${HDIR}/sys-setup/grub2-themes"
	                _run "${HDIR}/sys-setup/grub2-themes/install.sh -b -t vimix"
	                _run "touch ${HDIR}/scripts/skipdir/.grub"
                 fi
	             _run "cd ${HDIR}"
                 printf "$OVERWRITE"
                 _task-end
	             ;;
	  esac
   else
      _log-msg "Grub Menu already processed"
   fi
}

function _customize_lxterminal {
   if (( $(_Exists "lxterminal") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.lxterminal ]; then
	     _task-begin "Install LXTerminal Setup"
         if [ ! -d ${HDIR}/.config/lxterminal/ ]; then _run "mkdir -p ${HDIR}/.config/lxterminal"; fi
         _run "cd ${HDIR}/sys-setup/applications/lxterminal"
         _run "mv -f * ${HDIR}/.config/lxterminal/"
         _run "cd ${HDIR}"
         local VAL=$(grep 'geometry_columns=' ${HDIR}/.config/lxterminal/lxterminal.conf)
         sed -i "s/$VAL/geometry_columns=110/g" ${HDIR}/.config/lxterminal/lxterminal.conf 2>&1
         VAL=$(grep 'geometry_rows=' ${HDIR}/.config/lxterminal/lxterminal.conf)
         sed -i "s/$VAL/geometry_rows=30/g" ${HDIR}/.config/lxterminal/lxterminal.conf 2>&1
        _task-end
      else
         _log-msg "LXTerminal already processed"
      fi
      _run "touch ${HDIR}/scripts/skipdir/.lxterminal"
   else
      _log-msg "LXTerminal does not exist...Skipping"
   fi

}

function _customize_plank {
   if (( $(_Exists "plank") > 0 )); then
      if [ -d ${HDIR}/sys-setup/plank ]; then
         if [ ! -f ${HDIR}/scripts/skipdir/.plank ]; then
		     _task-begin "Install Plank Themes & Setup Files"
	        _run "mv -f ${HDIR}/sys-setup/plank/themes/* /usr/share/plank/themes"
	        if [ ! -d ${HDIR}/.config/plank/dock1/launchers/ ]; then _run "mkdir -p ${HDIR}/.config/plank/dock1/launchers"; fi
  	        _run "mv -f ${HDIR}/sys-setup/plank/dock1/launchers/* ${HDIR}/.config/plank/dock1/launchers/"
	        _run "cd ${HDIR}"
			_task-end
	     fi
      _run "touch ${HDIR}/scripts/skipdir/.plank"
      else
         _log-msg "ERROR - ${HDIR}/sys-setup/plank does NOT exist"
      fi
   else
      _log-msg "Plank does NOT exist"
   fi
}

function _customize_autostart {
   if [ ! -d ${HDIR}/.config/autostart/ ]; then _run "mkdir -p ${HDIR}/.config/autostart/"; fi
   if [ -d ${HDIR}/sys-setup/autostart ]; then
      if [ ! -f ${HDIR}/scripts/skipdir/.autostart ]; then
	     _task-begin "Setting Up Autostart Files"
         _run "cd ${HDIR}/sys-setup/autostart"
         if (( $(_Exists "numlockx") > 0 )); then _run "mv -f numlockx.desktop ${HDIR}/.config/autostart/"; fi
         if (( $(_Exists "plank") > 0 )); then _run "mv -f plank.desktop ${HDIR}/.config/autostart/"; fi
         if (( $(_Exists "flameshot") > 0 )); then _run "mv -f org.flameshot.Flameshot.desktop ${HDIR}/.config/autostart/"; fi
         if (( $(_Exists "ulauncher") > 0 )); then _run "mv -f ulauncher.desktop ${HDIR}/.config/autostart/"; fi
         if [[ ${SUDO_USER^^} == "MARTIN" ]]; then _run "mv -f automount.desktop ${HDIR}/.config/autostart/"; fi
         _run "cd ${HDIR}"
		 _task-end
      fi
      _run "touch ${HDIR}/scripts/skipdir/.autostart"
   else
      _log-msg "ERROR - ${HDIR}/sys-setup/autostart does NOT exist"
   fi
}

function _customize_fstab {
   if [ ! -f ${HDIR}/scripts/skipdir/.fstab ]; then
      if [[ ${SUDO_USER^^} == "MARTIN" ]]; then
         _task-begin "Setup Network Shares"
         RET=$( cat /etc/fstab | grep -c "10.10.10.25" )
         if [ ${RET} == "0" ]; then
            _run "echo ''  | tee -a /etc/fstab"
            _run "echo '//10.10.10.25/documents  /media/documents  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,_netdev,iocharset=utf8 0 0' | tee -a /etc/fstab"
            _run "echo '//10.10.10.25/utilities  /media/utilities  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,_netdev,iocharset=utf8 0 0' | tee -a /etc/fstab"
            _run "echo '//10.10.10.25/multimedia /media/multimedia cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,_netdev,iocharset=utf8 0 0' | tee -a /etc/fstab"
            _run "echo '//10.10.10.25/backups    /media/backups    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,_netdev,iocharset=utf8 0 0' | tee -a /etc/fstab"
            _run "echo '//10.10.10.25/private    /media/private    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,_netdev,iocharset=utf8 0 0' | tee -a /etc/fstab"
         fi
         _task-end
         
         # Setup Network Credentials
         printf "\n"
         _Ask "Enter Network Username"
         local UNAME=${REPLY}
         _AskPass "Enter Network Password"
         local PASS=${REPLY}
         printf "\n"

         _run "rm -f ${HDIR}/.smbcredentials"
         _run "touch ${HDIR}/.smbcredentials"
         _run "printf 'username=$UNAME\npassword=$PASS\n' | tee -a ${HDIR}/.smbcredentials"
         _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.smbcredentials"
         _run "chmod 600 ${HDIR}/.smbcredentials"
         printf "\n"
      fi
      _run "touch ${HDIR}/scripts/skipdir/.fstab"
   fi
}

function _customize_user_environment {
   #Backgrounds
   if [ -d ${HDIR}/sys-setup/backgrounds ]; then
      if [ ! -f ${HDIR}/scripts/skipdir/.background ]; then
         _task-begin "Install Desktop Backgrounds"
         _run "mv -f ${HDIR}/sys-setup/backgrounds/* /usr/share/backgrounds"
         _run "touch ${HDIR}/scripts/skipdir/.background"
         _task-end
      fi   
   else
       _log-msg "ERROR - ${HDIR}/sys-setup/backgrounds NOT found"
   fi

   #Start Icons
   if [ -d ${HDIR}/sys-setup/start ]; then
      if [ ! -d /usr/share/icons/start ]; then _run "mkdir -p /usr/share/icons/start"; fi
      if [ ! -f ${HDIR}/scripts/skipdir/.start ]; then
         _task-begin "Install Start Menu Icons"
         _run "mv -f ${HDIR}/sys-setup/start/* /usr/share/icons/start/"
         _run "touch ${HDIR}/scripts/skipdir/.start"
         _task-end
      fi   
   else
      _log-msg "ERROR - ${HDIR}/sys-setup/start NOT found"
   fi

   #User Files
   if [ ! -f ${HDIR}/scripts/skipdir/.bashrc ]; then
      _task-begin "Install Bash Setup Files"
      _run "mv -f ${HDIR}/sys-setup/.bashrc ${HDIR}"
      _run "mv -f ${HDIR}/sys-setup/.hushlogin ${HDIR}"
      if [ ${SUDO_USER^^} == "MARTIN" ]; then _run "mv -f ${HDIR}/sys-setup/bookmarks.html ${HDIR}"; fi
      _run "touch ${HDIR}/scripts/skipdir/.bashrc"
      _task-end
   else
      _log-msg "ERROR - ${HDIR}/sys-setup/.bashrc NOT found"
   fi
}

function _customize_xfce {
   if (( $(_Exists "xfce4") > 0 )); then
      if [ -d ${HDIR}/.config/xfce4 ]; then
         if [ ! -f ${HDIR}/scripts/skipdir/.xfce ]; then
		      if [ -d ${HDIR}/sys-setup/xfce4 ]; then
			      local STYLE=""
			      local TYPE=""
               local BACK=""
               local MENU=""
	            local PList=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin" "lxterminal"
                            "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman")
			      _add_by_list ${PList[*]}

			      _task-begin "Clear Existing XFCE Configuration"
               _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config/xfce4/"
	            _run "rm -rf ${HDIR}/.config/xfce4/*"
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
               _task-end

               case ${LAY^^} in
                  'TOPYELLOW')
                     STYLE="xfce_top_yellow.zip"
                     TYPE="Top"
                     ICON="Tango"
                     THEME="Skeuos-Yellow-Dark"
                     BACK="/usr/share/backgrounds/eGna2qBdawpRZpuq.jpg"
                     MENU="menu_13.png"
                     ;;
                  'TOPBLUE')
                     STYLE="xfce_top_blue.zip"
                     TYPE="Top"
                     ICON="Tango"
                     THEME="Goldy-Dark-GTK"
                     BACK="/usr/share/backgrounds/oC8iorz2BlyAeEQi.jpg"
                     MENU="menu_05.png"
                     ;;
                  'BOTTOMYELLOW')
                     STYLE="xfce_bottom_yellow.zip"
                     TYPE="Bottom"
                     ICON="Tango"
                     THEME="Skeuos-Yellow-Dark"
                     BACK="/usr/share/backgrounds/eGna2qBdawpRZpuq.jpg"
                     MENU="menu_13.png"
                     ;;
                  'BOTTOMBLUE')
                     STYLE="xfce_bottom_blue.zip"
                     TYPE="Bottom"
                     ICON="Tango"
                     THEME="Goldy-Dark-GTK"
                     BACK="/usr/share/backgrounds/oC8iorz2BlyAeEQi.jpg"
                     MENU="menu_05.png"
                     ;;
               esac

               # Install Custom Icons & Themes
	            _customize_icons
		         _customize_themes

			      _task-begin "Download XFCE ${TYPE} Default Configuration"
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi
	            if [ -d ${HDIR}/.config/xfce4/xfconf/ ]; then _run "rm -rf ${HDIR}/.config/xfce4/*"; fi

               _run "cd ${HDIR}/.config/xfce4/"
               _log-msg "Moving ${HDIR}/sys-setup/xfce4/${STYLE} to ${HDIR}/.config/xfce4/"
               _run "mv -f ${HDIR}/sys-setup/xfce4/${STYLE} ${HDIR}/.config/xfce4/"
               _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config/xfce4/"
			      _run "unzip -o -q ${STYLE}"
               _run "rm -f ${HDIR}/.config/xfce4/${STYLE}"
               _run "cd ${HDIR}"
			      _task-end

			      _task-begin "Set Location of Toolbar on Display"
               local Xaxis=$(xrandr --current | grep '*' | uniq | awk '{print $1}' | cut -d 'x' -f1)
               local Yaxis=$(xrandr --current | grep '*' | uniq | awk '{print $1}' | cut -d 'x' -f2)
			      #local Xpos=$(${Xaxis} * 0.94)
			      #local Ypos=$(${Yaxis} * 0.53)
			      _log-msg "Screen Resolution: ${Xaxis} x ${Yaxis}"
			      #_log-msg "Toolbar location: ${Xpos}, ${Ypos}"
			      #_setXValue "xfce4-panel" "/panels/panel-2/position" "p=0;x=${Xpos};y=${Ypos}"
			      _task-end

               _task-begin "Set Desktop Background"
               MON=("monitor0" "monitor1" "monitorVGA-1" "monitorLVDS1" "monitorLVDS-1"
                    "monitorHDMI1" "monitorHDMI2" "monitorHDMI-0" "monitorHDMI-1" "monitorHDMI-2"
                    "monitorDVI-I-1" "monitorDVI-D-0" "monitorDVI-D-1" "monitorDP-1"
                    "monitorVirtual-1" "monitorVirtual-2" "monitorVirtual1" "monitorVirtual2")
               WORK=("workspace0" "workspace1" "workspace2" "workspace3")
               for myMon in "${MON[@]}"
               do
                 for myWork in "${WORK[@]}"
                 do
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/color-style" "0" "int"
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/image-style" "5" "int"
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/image-path" ""
                    _setXValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/last-image" "$BACK"
                 done
               done
               _task-end

               # General Settings
               _task-begin "Set Default Fonts, Icons, and Themes"
               _setXValue "xsettings" "/Gtk/FontName" "Sans 14"
               _setXValue "xsettings" "/Gtk/MonospaceFontName" "Monospace 14"
               _setXValue "xsettings" "/Gtk/ToolbarIconSize" "3" "int"
               _setXValue "xsettings" "/Gtk/ToolbarStyle" "icons"
               _setXValue "xsettings" "/Net/IconThemeName" "$ICON"
               _setXValue "xsettings" "/Net/ThemeName" "$THEME"
               _task-end

               # Hide Suspend, Hibernate, and Hybrid Sleep from the logout dialog:
               _task-begin "Set Shutdown/Power Settings"
               _setXValue "xfce4-session" "/shutdown/ShowSuspend" "false" "bool"
               _setXValue "xfce4-session" "/shutdown/ShowHibernate" "false" "bool"
               _setXValue "xfce4-session" "/shutdown/ShowHybridSleep" "false" "bool"
               _task-end

               #Desktop Setup
               _task-begin "Set Desktop Settings"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-filesystem" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-home" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-removable" "false" "bool"
               _setXValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-trash" "true" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-filesystem" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-home" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-removable" "false" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/file-icons/show-trash" "true" "bool"
               _setXValue "xfce4-desktop" "/desktop-icons/primary" "true" "bool"
               _task-end

               _task-begin "Set Whiskermenu Icon"
               FILE="${HDIR}/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"
               _run "sed -i 's/menu_13.png/$MENU/g' $FILE"
               _run "cd ${HDIR}/.config/xfce4/"
               local SRCH=$(grep -rl 'button-icon' . | grep -v 'show-button') >/dev/null 2>&1
               _log-msg "Looking For: $SRCH"
			      for myFILE in ${SRCH}; do
                 _log-msg "Processing: ${myFILE}"
                 if [ -f ${myFILE} ]; then
                    _log-msg "Replacing menu_13.png with ${MENU} in ${myFILE}"
		              _run "sed -i 's#menu_13.png#${MENU}#g' ${myFILE}"
                    _log-msg "Replacing menu_05.png with ${MENU} in ${myFILE}"
		            _run "sed -i 's#menu_05.png#${MENU}#g' ${myFILE}"
                 fi
               done
               _task-end

               printf "\n"
               _run "cd ${HDIR}"
            else
               _log-msg "ERROR - ${HDIR}/sys-setup/xfce4 NOT found"
	         fi
         fi
         _run "touch ${HDIR}/scripts/skipdir/.xfce"
      else
         _log-msg "ERROR - ${HDIR}/.config/xfce4 does NOT exist"
      fi
   else
      _log-msg "XFCE not found" 
   fi
}

function _customize_budgie {
   if (( $(_Exists "budgie-desktop") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.budgie ]; then
         if [ -d ${HDIR}/sys-setup/budgie ]; then
			   local STYLE=""
            local BACK=""

			   # ====== Yellow Backgrounds ======
			   # vyYvUseebgNgzzGQ.jpg   # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg   # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg   # Yellow Toronto

            # ====== Blue Backgrounds ======
			   # 8pplzWJvxVoxqrCE.jpg   # Volcano Lake
		   	# oC8iorz2BlyAeEQi.jpg   # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg   # Blue Toronto            
            case ${LAY^^} in
              'TOPYELLOW') 
                 STYLE="top_yellow.conf"
                 BACK="eGna2qBdawpRZpuq.jpg"
                 ;;
              'TOPBLUE') 
                 STYLE="top_blue.conf" 
                 BACK="oC8iorz2BlyAeEQi.jpg"
                 ;;
              'BOTTOMYELLOW') 
                 STYLE="bottom_yellow.conf" 
                 BACK="eGna2qBdawpRZpuq.jpg"
                 ;;
              'BOTTOMBLUE') 
                 STYLE="bottom_blue.conf"                 
                 BACK="oC8iorz2BlyAeEQi.jpg"
                 ;;
            esac

            # Install Custom Icons & Themes
	         _customize_icons
		      _customize_themes

            _task-begin "Customize Budgie Desktop"
            _log-msg "Copying $STYLE to Documents"
            _run "cp -f ${HDIR}/sys-setup/budgie/${STYLE} ${HDIR}/Documents/dconf.conf"
            _task-end

            _task-begin "Set Desktop Background"
	         _run "rm /usr/share/backgrounds/budgie/default.jpg"
	         _run "cp -f /usr/share/backgrounds/${BACK} /usr/share/backgrounds/budgie/default.jpg"
            _task-end
            
            _run "touch ${HDIR}/scripts/skipdir/.budgie"
         fi
      fi
   fi
}

function _customize_cinnamon {
   if (( $(_Exists "cinnamon") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.cinnamon ]; then
         if [ -d ${HDIR}/sys-setup/cinnamon ]; then
			   # === Yellow Backgrounds ===
			   # vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg  # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			   # === Blue Backgrounds ===
			   # 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			   # oC8iorz2BlyAeEQi.jpg  # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto

            local MENU=""
            local STYLE=""
            local CDIR=""
            local DIR=""
            
            case ${LAY^^} in
              # ================= Yellow Theme ===================
               'BOTTOMYELLOW')
                     MENU="menu_13.png"
                     STYLE="bottom_yellow.conf"
                     ;;
              # ================= Blue Theme =====================                     
               'BOTTOMBLUE')
                     MENU="menu_05.png"
                     STYLE="bottom_blue.conf"
                     ;;
            esac

			 _customize_icons
		    _customize_themes

          # Base setup for Cinnamon Desktop
          _task-begin "Customize ${DSKTOPENV^^} Desktop"
          _log-msg "Copying $STYLE to Documents"
          _run "cp -f ${HDIR}/sys-setup/cinnamon/${STYLE} ${HDIR}/Documents/dconf.conf"
          _task-end

          _task-begin "Set Desktop Background Folders"
          DIR="${HDIR}/.config/cinnamon/backgrounds/"
          if [[ ! -d ${DIR} ]]; then _run "mkdir -p $DIR"; fi
			 if [[ -f ${DIR}/user-folders.lst ]]; then _run "rm -f ${DIR}/user-folders.lst"; fi
          _run "echo '/home/${SUDO_USER,,}/Pictures' > ${DIR}/user-folders.lst"
          _run "echo '/user/share/backgrounds' >> ${DIR}/user-folders.lst"
          _task-end

          _task-begin "Set Menu Icon"
			 CDIR="${HDIR}/.config/cinnamon/spices/menu@cinnamon.org"
			 local PASS1=$(jq '.["menu-custom"] |= (.value = true)' ${CDIR}/0.json)
          local PASS2=$(echo $PASS1 | jq '.["menu-icon"] |= (.value = "/usr/share/icons/start/==MENU==")')
          local PASS3=$(echo $PASS2 | jq '.["menu-label"] |= (.value = "")')
          if [[ ! -z $PASS3 ]]; then
			    if [[ -f $CDIR/0.json ]]; then _run "rm -f $CDIR/0.json"; fi
                printf "${PASS3/==MENU==/$MENU}" >${CDIR}/0.json
             fi
          fi
          _task-end
          _run "touch ${HDIR}/scripts/skipdir/.cinnamon"
      fi
   fi
}

function _customize_gnome {
   if (( $(_Exists "gnome") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.gnome ]; then
         if [ -d ${HDIR}/sys-setup/gnome ]; then
			   # === Yellow Backgrounds ===
			   # vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg  # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			   # === Blue Backgrounds ===
			   # 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			   # oC8iorz2BlyAeEQi.jpg  # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto

            local MENU=""
            local STYLE=""
            local CDIR=""
            local DIR=""
            
            case ${LAY^^} in
              # ================= Yellow Theme ===================
               'BOTTOMYELLOW')
                     MENU="menu_13.png"
                     STYLE="bottom_yellow.conf"
                     ;;
              # ================= Blue Theme =====================                     
               'BOTTOMBLUE')
                     MENU="menu_05.png"
                     STYLE="bottom_blue.conf"
                     ;;
            esac

			 _customize_icons
		    _customize_themes

          # Base setup for Gnome Desktop
          _task-begin "Customize ${DSKTOPENV^^} Desktop"
          _log-msg "Copying $STYLE to Documents"
          _run "cp -f ${HDIR}/sys-setup/gnome/${STYLE} ${HDIR}/Documents/dconf.conf"
          _task-end

          _task-begin "Set Desktop Background Folders"
          DIR="${HDIR}/.config/gnome/backgrounds/"
          if [[ ! -d ${DIR} ]]; then _run "mkdir -p $DIR"; fi
			 if [[ -f ${DIR}/user-folders.lst ]]; then _run "rm -f ${DIR}/user-folders.lst"; fi
          _run "echo '/home/${SUDO_USER,,}/Pictures' > ${DIR}/user-folders.lst"
          _run "echo '/user/share/backgrounds' >> ${DIR}/user-folders.lst"
          _task-end

         #  _task-begin "Set Menu Icon"
			#  CDIR="${HDIR}/.config/cinnamon/spices/menu@cinnamon.org"
			#  local PASS1=$(jq '.["menu-custom"] |= (.value = true)' ${CDIR}/0.json)
         #  local PASS2=$(echo $PASS1 | jq '.["menu-icon"] |= (.value = "/usr/share/icons/start/==MENU==")')
         #  local PASS3=$(echo $PASS2 | jq '.["menu-label"] |= (.value = "")')
         #  if [[ ! -z $PASS3 ]]; then
			#     if [[ -f $CDIR/0.json ]]; then _run "rm -f $CDIR/0.json"; fi
         #        printf "${PASS3/==MENU==/$MENU}" >${CDIR}/0.json
         #     fi
         #  fi
          _task-end
          _run "touch ${HDIR}/scripts/skipdir/.gnome"
      fi
   fi
}

function _customize_plasma {
   if (( $(_Exists "plasma") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.plasma ]; then
         if [ -d ${HDIR}/sys-setup/plasma ]; then
			   # === Yellow Backgrounds ===
			   # vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg  # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			   # === Blue Backgrounds ===
			   # 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			   # oC8iorz2BlyAeEQi.jpg  # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto

            local MENU=""
            local STYLE=""
            local CDIR=""
            local DIR=""
            
            case ${LAY^^} in
              # ================= Yellow Theme ===================
               'BOTTOMYELLOW')
                     MENU="menu_13.png"
                     STYLE="bottom_yellow.conf"
                     ;;
              # ================= Blue Theme =====================                     
               'BOTTOMBLUE')
                     MENU="menu_05.png"
                     STYLE="bottom_blue.conf"
                     ;;
            esac

			 _customize_icons
		    _customize_themes

          # Base setup for plasma Desktop
          _task-begin "Customize ${DSKTOPENV^^} Desktop"
          _log-msg "Copying $STYLE to Documents"
          _run "cp -f ${HDIR}/sys-setup/plasma/${STYLE} ${HDIR}/Documents/dconf.conf"
          _task-end

          _task-begin "Set Desktop Background Folders"
          DIR="${HDIR}/.config/plasma/backgrounds/"
          if [[ ! -d ${DIR} ]]; then _run "mkdir -p $DIR"; fi
			 if [[ -f ${DIR}/user-folders.lst ]]; then _run "rm -f ${DIR}/user-folders.lst"; fi
          _run "echo '/home/${SUDO_USER,,}/Pictures' > ${DIR}/user-folders.lst"
          _run "echo '/user/share/backgrounds' >> ${DIR}/user-folders.lst"
          _task-end

         #  _task-begin "Set Menu Icon"
			#  CDIR="${HDIR}/.config/cinnamon/spices/menu@cinnamon.org"
			#  local PASS1=$(jq '.["menu-custom"] |= (.value = true)' ${CDIR}/0.json)
         #  local PASS2=$(echo $PASS1 | jq '.["menu-icon"] |= (.value = "/usr/share/icons/start/==MENU==")')
         #  local PASS3=$(echo $PASS2 | jq '.["menu-label"] |= (.value = "")')
         #  if [[ ! -z $PASS3 ]]; then
			#     if [[ -f $CDIR/0.json ]]; then _run "rm -f $CDIR/0.json"; fi
         #        printf "${PASS3/==MENU==/$MENU}" >${CDIR}/0.json
         #     fi
         #  fi
          _task-end
          _run "touch ${HDIR}/scripts/skipdir/.plasma"
      fi
   fi
}

function _customize_lxqt {
   if (( $(_Exists "lxqt") > 0 )); then
      if [ ! -f ${HDIR}/scripts/skipdir/.lxqt ]; then
         if [ -d ${HDIR}/sys-setup/lxqt ]; then
			   # === Yellow Backgrounds ===
			   # vyYvUseebgNgzzGQ.jpg  # Yellow Misty Lake
			   # eGna2qBdawpRZpuq.jpg  # Yellow Tree
			   # auUagbqqV2gbGi8w.jpg  # Yellow Toronto
			   # === Blue Backgrounds ===
			   # 8pplzWJvxVoxqrCE.jpg  # Volcano Lake
			   # oC8iorz2BlyAeEQi.jpg  # Blue Dock
			   # Cv0ZEeqOw7vMz1ez.jpg  # Blue Toronto

            local MENU=""
            local STYLE=""
            local CDIR=""
            local DIR=""
            
            case ${LAY^^} in
              # ================= Yellow Theme ===================
               'BOTTOMYELLOW')
                     MENU="menu_13.png"
                     STYLE="bottom_yellow.conf"
                     ;;
              # ================= Blue Theme =====================                     
               'BOTTOMBLUE')
                     MENU="menu_05.png"
                     STYLE="bottom_blue.conf"
                     ;;
            esac

			 _customize_icons
		    _customize_themes

          # Base setup for lxqt Desktop
          _task-begin "Customize ${DSKTOPENV^^} Desktop"
          _log-msg "Copying $STYLE to Documents"
          _run "cp -f ${HDIR}/sys-setup/lxqt/${STYLE} ${HDIR}/Documents/dconf.conf"
          _task-end

          _task-begin "Set Desktop Background Folders"
          DIR="${HDIR}/.config/lxqt/backgrounds/"
          if [[ ! -d ${DIR} ]]; then _run "mkdir -p $DIR"; fi
			 if [[ -f ${DIR}/user-folders.lst ]]; then _run "rm -f ${DIR}/user-folders.lst"; fi
          _run "echo '/home/${SUDO_USER,,}/Pictures' > ${DIR}/user-folders.lst"
          _run "echo '/user/share/backgrounds' >> ${DIR}/user-folders.lst"
          _task-end

         #  _task-begin "Set Menu Icon"
			#  CDIR="${HDIR}/.config/cinnamon/spices/menu@cinnamon.org"
			#  local PASS1=$(jq '.["menu-custom"] |= (.value = true)' ${CDIR}/0.json)
         #  local PASS2=$(echo $PASS1 | jq '.["menu-icon"] |= (.value = "/usr/share/icons/start/==MENU==")')
         #  local PASS3=$(echo $PASS2 | jq '.["menu-label"] |= (.value = "")')
         #  if [[ ! -z $PASS3 ]]; then
			#     if [[ -f $CDIR/0.json ]]; then _run "rm -f $CDIR/0.json"; fi
         #        printf "${PASS3/==MENU==/$MENU}" >${CDIR}/0.json
         #     fi
         #  fi
          _task-end
          _run "touch ${HDIR}/scripts/skipdir/.lxqt"
      fi
   fi
}

#=======================================
# Title & Menu
#=======================================
function _title() {
   clear
   printf "\n${CYAN}
    ███████╗██╗   ██╗███████╗████████╗███████╗███╗   ███╗
    ██╔════╝╚██╗ ██╔╝██╔════╝╚══██╔══╝██╔════╝████╗ ████║
    ███████╗ ╚████╔╝ ███████╗   ██║   █████╗  ██╔████╔██║
    ╚════██║  ╚██╔╝  ╚════██║   ██║   ██╔══╝  ██║╚██╔╝██║
    ███████║   ██║   ███████║   ██║   ███████╗██║ ╚═╝ ██║
    ╚══════╝   ╚═╝   ╚══════╝   ╚═╝   ╚══════╝╚═╝     ╚═╝

        ███████╗███████╗████████╗██╗   ██╗██████╗
        ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗
        ███████╗█████╗     ██║   ██║   ██║██████╔╝
        ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝
        ███████║███████╗   ██║   ╚██████╔╝██║
        ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝
"
   printf "\n\t\t   ${YELLOW}${OS^^} System Setup      ${LPURPLE}Version: $VER\n${RESTORE}"
   printf "\t\t\t\t\t${YELLOW}by: ${LPURPLE}Martin Boni${RESTORE}\n"
   printf "\n\n   ${YELLOW}    Operating System: ${LPURPLE}${REALOS^^}\n${RESTORE}"
   printf "   ${YELLOW}Physical Device Type: ${LPURPLE}${DEVICE^^}\n${RESTORE}"
   if [ -z $DSKTOPENV ]; then
      printf "   ${YELLOW}Desktop Envioronment: ${LPURPLE}NONE\n${RESTORE}"
   else
      printf "   ${YELLOW}Desktop Envioronment: ${LPURPLE}${DSKTOPENV^^}\n${RESTORE}"
   fi
   printf "   ${YELLOW}     Physical Memory: ${LPURPLE}${MEMSIZE}Gb\n${RESTORE}\n"
}

function _main_menu() {
   local ValidOPT="1,2,3,99"
   printf "\n\n${LPURPLE}       ${OS^^} System Options\n"
   printf "  ${LGREEN}+-------------------------------------+\n"
   printf "  |                                     |\n"
   printf "  |   1) Install Destop Environment     |\n"
   printf "  |   2) Install Server  Environment    |\n"
   printf "  |   3) Update System Packages         |\n"
   printf "  |                                     |\n"
   printf "  |  ---------------------------------  |\n"
   printf "  |                                     |\n"
   printf "  |  99) QUIT Menu                      |\n"
   printf "  |                                     |\n"
   printf "  +-------------------------------------+${RESTORE}\n\n\n\n"
   while [[ ${ValidOPT} != *${STP}* ]]
   do
      _Ask "${OVERWRITE}Choose the step to run (1-3 or 99)" "1" && STP=$REPLY
   done
   printf "\n\n"
}

function _main_desktop() {
   local ValidOPT="1,2,3,4,5,99"

   # === Process Main Menu ===
   while [[ ${DTP^^} != "99" ]]
   do
      printf "\n\n${LPURPLE}       ${OS^^} Desktop Setup\n"
      printf "  ${LGREEN}+-------------------------------------+\n"
      printf "  |                                     |\n"
      printf "  |   1) Install Base System Packages   |\n"
      printf "  |   2) Install Desktop Environment    |\n"
      printf "  |   3) Install System Applications    |\n"
      printf "  |   4) Install Applications           |\n"
      printf "  |   5) Customize System & Desktop     |\n"
      printf "  |                                     |\n"
      printf "  |  ---------------------------------  |\n"
      printf "  |                                     |\n"
      printf "  |  99) Return to Previous Menu        |\n"
      printf "  |                                     |\n"
      printf "  +-------------------------------------+${RESTORE}\n\n\n\n"
      while [[ ${ValidOPT} != *${DTP}* ]]
      do
         _Ask "${OVERWRITE}Choose the step to run (1-5 or 99)" "1" && DTP=$REPLY
      done
      printf "\n\n"

      case ${DTP^^} in
          1) _process_step_1 ;;
          2) _process_step_2 ;;
          3) _process_step_3 ;;
          4) _process_step_4 ;;
          5) _process_step_5 ;;
         99) break ;;
      esac
      if [ ${DTP^^} != "99" ]; then DTP="777"; fi
   done 
}

function _main_server() {
   local ValidOPT="1,2,99"
   # === Process Main Menu ===
   while [[ ${OTP^^} != "99" ]]
   do   
      printf "\n\n${LPURPLE}       ${OS^^} Server Setup\n"
      printf "  ${LGREEN}+-------------------------------------+\n"
      printf "  |                                     |\n"
      printf "  |   1) Install Base System Packages   |\n"
      printf "  |   2) Install System Applications    |\n"
      printf "  |                                     |\n"
      printf "  |  ---------------------------------  |\n"
      printf "  |                                     |\n"
      printf "  |  99) Return to Previous Menu        |\n"
      printf "  |                                     |\n"
      printf "  +-------------------------------------+${RESTORE}\n\n\n\n"
      while [[ ${ValidOPT} != *${OTP}* ]]
      do
         _Ask "${OVERWRITE}Choose the step to run (1-2 or 99)" "1" && OTP=$REPLY
      done
      printf "\n\n"

      case ${OTP^^} in
          1) _process_step_1 ;;
          2) _process_step_3 ;;
         99) break ;;
      esac
      if [ ${OTP^^} != "99" ]; then OTP="777"; fi
   done    
}

function _desktop_menu {
   #=============================
   # Choose Desktop Environment
   #=============================
   local ctr=0
   local ValidDSK=""
   local dskTop=()
   
   case ${OS^^} in
     'ALPINE') dskTop=("XFCE" "CINNAMON" "LXQT" "GNOME" "PLASMA" ) ;;
       'VOID') dskTop=("XFCE" "CINNAMON" "LXQT" "GNOME" "PLASMA") ;;
     'DEBIAN') dskTop=("XFCE" "BUDGIE" "CINNAMON" "LXQT" "GNOME" "PLASMA") ;;
   esac
   
   printf "  ${LPURPLE}      DESKTOP ENVIRONMENT\n"
   printf "  ${LGREEN}+---------------------------------------+\n"
   printf "  |                                       |\n"
   if [ ${#dskTop[@]} -gt 0 ]; then
     ctr=0
     for mnu in "${dskTop[@]}"; do
       ctr=$((++ctr))
       printf "  |    %i) %-30s  |\n" $ctr "$mnu Desktop Environment"
       ValidDSK="$ValidDSK$ctr,"
     done
   fi
   printf "  |                                       |\n"
   printf "  |  -----------------------------------  |\n"
   printf "  |                                       |\n"
   printf "  |   99) Return to Previous Menu         |\n"
   printf "  |                                       |\n"
   printf "  +---------------------------------------+${RESTORE}\n\n\n"

   while [[ ${ValidDSK} != *${DSK}* ]]
   do
      _Ask " ${OVERWRITE}Choose the Desktop Environment (1-$ctr or 99)" "1" && DSK=$REPLY
   done
   
   if [[ ${REPLY} == 99 ]]; then
     DSK="QUIT"
   else
     DSK="${dskTop[$REPLY - 1]^^}"
   fi
   printf "\n\n"
 }

function _layout_menu {
   #=============================
   # Choose Desktop Layout
   #=============================
   local Layout=()
   local ValidLAY=""
   case ${DSK^^} in
        'XFCE') Layout=("TopYellow - Top Menu, Yellow Theme"
                        "TopBlue - Top Menu, Blue Theme"
                        "BottomYellow - Top Menu, Yellow Theme"
                        "BottomBlue - Top Menu, Blue Theme")
                ;;
      'BUDGIE') Layout=("TopYellow - Top Menu, Yellow Theme"
                        "TopBlue - Top Menu, Blue Theme"
                        "BottomYellow - Top Menu, Yellow Theme"
                        "BottomBlue - Top Menu, Blue Theme")
                ;;
    'CINNAMON') Layout=("BottomYellow - Top Menu, Yellow Theme"
                        "BottomBlue - Top Menu, Blue Theme")
                ;;
        'LXQT') ;;
        'LXDE') ;;
       'GNOME') ;;
      'PLASMA') ;;
   esac
   
   if [ ${#Layout[@]} -gt 0 ]; then
      printf "  ${LPURPLE}      DESKTOP LAYOUT\n"
      printf "  ${LGREEN}+-----------------------------------------------+\n"
      printf "  |                                               |\n"
      ctr=0
      for mnu in "${Layout[@]}"; do
        ctr=$((++ctr))
        printf "  |   %i) %-40s |\n" $ctr "$mnu"
        ValidLAY="$ValidLAY$ctr,"
      done
      printf "  |                                               |\n"
      printf "  +-----------------------------------------------+${RESTORE}\n\n\n"
   
      while [[ ${ValidLAY} != *${LAY}* ]]
      do
         _Ask " ${OVERWRITE}Choose the Desktop Layout (1-$ctr)" "1" && LAY=${REPLY}
      done
   
      if [[ ${REPLY} == 99 ]]; then
        LAY="QUIT"
      else
        LAY=$(echo "${Layout[$REPLY - 1]^^}" | cut -d ' ' -f1)
      fi
   fi
   _parm_out
   printf "\n\n"
}

function _process_step_1 {
   printf "\n  ${YELLOW}Step 1 - Install Base System Packages${RESTORE}\n"
   if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

   #===============================
   # Install required system files
   #===============================
   if [ ! -f $HDIR/scripts/skipdir/.system ]; then
      printf "\n${LPURPLE}=== Install Required System Files ===${RESTORE}\n\n"
      _add_by_list ${SYSList[*]}
      _run "touch $HDIR/scripts/skipdir/.system"
   fi
   printf "\n${LPURPLE}=== End of Step 1 ===${RESTORE}\n\n"
}

function _process_step_2 {
   printf "\n  ${YELLOW}Step 2 - Install Desktop Environment${RESTORE}\n\n"
   if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

   #=============================
   # Install Desktop Environment
   #=============================
   _desktop_menu
   if [[ ${DSK^^} != "QUIT" ]]; then 
       _layout_menu

       #===============================
       # Install required system files
       #===============================
       printf "\n${LPURPLE}=== Install Required Desktop Files ===${RESTORE}\n\n"
       _add_by_list ${DESKList[*]}
       _install_Desktop

       #==================================
       # Starting Services
       #==================================
       printf "\n\n${LPURPLE}=== Starting Services ===${RESTORE}\n" 
       _start_services
  
       #==================================
       # Remove non required applications
       #==================================
       printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
       _del_by_list ${DELList[*]}
       DELList=()

       #==================================
       # Restarting System
       #==================================
       printf "\n\n${LPURPLE}=== Restarting System - End of Step 2 ===${RESTORE}\n"
       _AskYN "OK to Reboot Now (y/n)" "Y"
       if [ ${REPLY^^} = "Y" ]; then reboot; fi
   fi
}

function _process_step_3 {
  printf "\n  ${YELLOW}Step 3 - Update System Configuration${RESTORE}\n\n"
  if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
  _run "touch ${LOG}"
  _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
  
  # === Get Desktop Parameters ===
  _task-begin "Get Desktop Parameter File"
  DSK=$(_parm_in "DESKTOP")
  LAY=$(_parm_in "LAYOUT")
  _task-end
  
  #===============================
  # Create Network Mount Points
  #===============================
  printf "\n${LPURPLE}=== Setup System Files ===${RESTORE}\n"
  if [ ! -f $HDIR/scripts/skipdir/.network ]; then
     if [[ ${SUDO_USER^^} == "MARTIN" ]]; then  
         _task-begin "Create Network Mount Points"
         if [ ! -d /media/documents ]; then _run "mkdir -p /media/documents"; fi
         if [ ! -d /media/utilities ]; then _run "mkdir -p /media/utilities"; fi
         if [ ! -d /media/multimedia ]; then _run "mkdir -p /media/multimedia"; fi
         if [ ! -d /media/backups ]; then _run "mkdir -p /media/backups"; fi
         if [ ! -d /media/private ]; then _run "mkdir -p /media/private"; fi
         _run "touch /$HDIR/scripts/skipdir/.network"
         _task-end
     fi
  fi

  #===============================
  # Create User Directories
  #===============================
  if [ ! -f $HDIR/scripts/skipdir/.directories ]; then
      _task-begin "Create User Directories"
      if [ ! -d ${HDIR}/Documents ]; then _run "mkdir -p ${HDIR}/Documents"; fi
      if [ ! -d ${HDIR}/Downloads ]; then _run "mkdir -p ${HDIR}/Downloads"; fi
      if [ ! -d ${HDIR}/Pictures ]; then _run "mkdir -p ${HDIR}/Pictures"; fi
      _run "touch /$HDIR/scripts/skipdir/.directories"
      _task-end
   fi

  #==================================
  # Remove Language Files
  #==================================
  printf "\n\n${LPURPLE}=== Removing Language Packs ===${RESTORE}\n"
  _del_language

  #==================================
  # Setup OS Environment
  #==================================
  printf "\n\n${LPURPLE}=== Setup Environment ===${RESTORE}\n"
  _setup_environment
  
  #==================================
  # Update & Add Aliases
  #==================================
  printf "\n\n${LPURPLE}=== Setting Aliases ===${RESTORE}\n" 
  _set_aliases

  #==================================
  # Install Nerd Fonts
  #==================================
  printf "\n\n${LPURPLE}=== Installing Nerd Fonts ===${RESTORE}\n"
  _install_nerdfonts

  #==================================
  # Starting Services
  #==================================
  if [[ -z ${DSKTOPENV^^} ]]; then 
     printf "\n\n${LPURPLE}=== Starting Services ===${RESTORE}\n" 
     _start_services
  fi 
  
  printf "\n\n${LPURPLE}=== End of Step 3 ===${RESTORE}\n\n"
}

function _process_step_4 {
   printf "\n  ${YELLOW}Step 4 - Install Desktop Applications${RESTORE}\n\n"
   # === Get Desktop Parameters ===
   _task-begin "Get Desktop Parameter File"
   DSK=$(_parm_in "DESKTOP")
   LAY=$(_parm_in "LAYOUT")
   _task-end
   
   if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
   printf "\n\n"   
   
   #==========================================
   # Install flatpak if not already installed
   #==========================================
   if (( $(_Exists "flatpak") == 0 )); then
      _add_pkg "flatpak"
      _run "flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo"
      _task-end
   fi

   #==================================
   # Choose Packages to Install
   #==================================
   DELList=()
   _AskYN "Install Default Apps Only:" "Y"
   printf "\n"
   if [ ${REPLY^^} == "Y" ]; then
      _default_apps
   else
      printf "\n\n"
      _chooser
   fi

   #==================================
   # Install required applications
   #==================================
   printf "\n\n${LPURPLE}=== Installing Required Desktop Packages on ${OS^^} ===${RESTORE}\n\n"
   _add_by_list ${ADDList[*]}
   
  #==================================
  # Remove non required applications
  #==================================
  printf "\n${LPURPLE}=== Remove Unrequired Desktop Packages ===${RESTORE}\n"
  _del_by_list ${DELList[*]}

  printf "\n\n${LPURPLE}=== End of Step 4 ===${RESTORE}\n\n"
}

function _process_step_5 {
   printf "\n  ${YELLOW}Step 5 - Install Desktop Customizations${RESTORE}\n\n"
   # === Delete any pervious logs and setup new one ===
   if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
   _run "touch ${LOG}"
   _run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"
  
   # === Get Desktop Parameters ===
   _task-begin "Get Desktop Parameter File"
   DSK=$(_parm_in "DESKTOP")
   LAY=$(_parm_in "LAYOUT")
   _log-msg "Parameters After Read - Desktop=$DSK, Layout=$LAY"
   _task-end

   # === Get Setup File ===
   _get_setup_file
   
   # === Seup User ===
   _customize_user_environment
      
   # === Customize Desktop Environment ===
   printf "\n${LPURPLE}=== Customize Desktop Environment ===${RESTORE}\n\n"
   case ${DSK^^} in
         'XFCE') _customize_xfce ;;
       'BUDGIE') _customize_budgie ;;
     'CINNAMON') _customize_cinnamon ;;
         'LXQT') _customize_lxqt ;;
        'GNOME') _customize_gnome ;;
       'PLASMA') _customize_plasma ;;        
   esac

   # === Customize LIGHTDM settings ===
   if (( $(_Exists "lightdm") > 0 )); then _customize_lightdm; fi

   # === Customize LXTerminal Setup ===
   _customize_lxterminal

   # === Setup Autostart Files ===
   _customize_autostart

   #  === Setup GRUB Menu ===
   if [[ ! ${OS^^} == "ALPINE" ]]; then _customize_grub; fi

   #  === Setup FSTAB File ===
   _customize_fstab

   # === Set Permissions on Directories ===
   _task-begin "Setting Up Directory Permissions"
   _run "cd ${HDIR}"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/backgrounds"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/icons"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/themes"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.local"
   _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config"
   _task-end
   
   # === Cleanup ===
   _task-begin "Remove Temporary Files"
   if [[ -d ${HDIR}/sys-setup ]]; then _run "rm -rf ${HDIR}/sys-setup"; fi
   if [[ -f ${HDIR}/param.dat ]]; then _run "rm -f ${HDIR}/param.dat"; fi
   printf "$OVERWRITE"
   _task-end
   
   # === Restarting System ===
   printf "\n\n${LPURPLE}=== Restarting System - End of Step 5 ===${RESTORE}\n"
   _AskYN "OK to Reboot Now (y/n)" "Y"
   if [ ${REPLY^^} = "Y" ]; then _run "touch ${HDIR}/scripts/skipdir/.reboot"; exit 0; fi
   _run "touch ${HDIR}/scripts/skipdir/.cinnamon"
}
