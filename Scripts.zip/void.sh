#!/bin/bash

SYSList=("7zip" "avahi" "avahi-utils" "bash" "bash-completion" 
         "cifs-utils" "git" "gvfs" "gvfs-mtp" "gvfs-smb" 
         "gzip" "nano" "netcat" "preload" "sed" "sv-netmount" "ufw"
         "unzip" "xrandr" "xz" "zramen" "zstd")

DESKList=("alsa-utils" "alsa-pipewire" "bluez" "brother-brlaser" "blueman" "cups" "cups-pk-helper"
          "cups-filters" "dconf" "dejavu-fonts-ttf" "dbus-x11" "foomatic-db" "foomatic-db-engine"
          "gufw" "libspa-bluetooth" "NetworkManager" "pipewire" "polkit" "powertop" 
          "terminus-font" "tlp" "tlp-rdw" "wireplumber" "xarchiver" "xrandr")

DELList=("firefox" "orca")

APPList+=("=== Choose Browser(s) ===||"
          "Chromium Browser|chromium|N" 
		    "Firefox Browser|firefox|N"
          "Floorp Browser|@FLT-FLOORP|N"
          "Google Chrome Browser|@FLT-GOOGLE|N"
		    "Thorium Browser|@XDB-THORIUM|Y"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|Y"
          "Waterfox Browser|@FLT-WATER|N"
          "=== Choose Office Tools ===||"
		    "Abiword Word Processor|abiword|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		    "Gnome Calculator|gnome-calculator|Y"
		    "gNumeric Spreadsheet|gnumeric|N"
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
		    "Mousepad Notepad|mousepad|Y"
		    "NotepadQQ Editor|notepadqq|N"
		    "Notepad Next Editor|@FLT-NEXT|N"
		    "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|Y"
		    "Standard Notes|@FLT-NOTES|N"
		    "Thunderbird Email Client|thunderbird|Y"
		    "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|choqok|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|Y"
          "=== Choose Development Tools ===||"
		    "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|vscode|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|bleachbit|Y"
		    "Balena Etcher|@XDB-ETCHER|Y"
          "Clam Anti Virus|clamav|Y"
          "Clam Anti Virus GUI|@FLT-CLAMTK|Y"
          "Disk Utility|gnome-disk-utility|Y"
		    "Fastfetch|fastfetch|Y"
		    "Flameshot Screenshot Utility|flameshot|Y"
		    "Gnome Software Manager|gnome-software|Y"
		    "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		    "Neofetch|neofetch|N"
          "Numlockx|numlockx|N"
          "Pika Backup|@FLT-PIKA|Y"
		    "Putty SSH Utility|putty|N"
		    "Stacer|@XDB-STACER|Y"
		    "System Monitor|@FLT-MONITOR|N"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Image Writer|imagewriter|N"
          "Impress USB Writer|@FLT-IMPRESS|N"
          "=== Choose Emulation Tools ===||"
		    "Bottles Windows Emulation|@FLT-BOTTLE|N"
          "Play On Linux|@FLT-PLAY|N"
		    "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine Tricks|winetricks|N"
          "=== Choose Virtualization Tools ===||"
		    "Docker|docker|N"
		    "Gnome Boxes|gnome-boxes|N"
		    "Podman|podman|N"
		    "Virtualization Manager|virt-manager|N"
		    "Virtualization Manager Tools|virt-manager-tools|N"
          "=== Choose Optional Applications ===||"
		    "Calibre eBook Manager|calibre|N"
		    "Cheese Camera Utility|cheese|N"
		    "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|@FLT-KODI|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		    "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
		    "VLC Media Player|vlc|Y")

function _setup_environment {
   if [[ ! -f ${HDIR}/scripts/skipdir/.environment ]]; then
      # Disable Root Login
      _task-begin "Disable Root Login"
      RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
      if [ ${RET} == 0 ]; then
         _run "sed -i s'#root:/bin/sh#root:/sbin/nologin#' /etc/passwd"
      fi
      _task-end

      # Update Terminal Profile
      _task-begin "Update $OS Terminal Profile"
      RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
      if [ ${RET} == 0 ]; then
         printf "PS1='${PS1}'\nexport PS1\n" >> /etc/profile
      fi
      printf "${OVERWRITE}${OVERWRITE}${OVERWRITE}"
      _task-end

      # Remove MOTD
      _task-begin "Removing MOTD"
      if [ -f /etc/motd ]; then _run "rm /etc/motd"; fi
      _task-end

      # Change Shell to Bash
      if [[ $(grep -c '/bin/ash' /etc/passwd) == 0 ]]; then
         _task-begin "Change Shell to BASH"
         _run "sed -i 's#/bin/sh#/bin/bash#' /etc/passwd"
         _task-end
      fi
                     
      # Install Pipewire
      if (( $(_Exists "pipewire") == 0 )); then
         printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
         _task-begin "Set Pipewire User Groups"
         _run "usermod -g audio ${SUDO_USER}"
         _run "usermod -g video ${SUDO_USER}"
         _task-end
      fi
      _run "usermod -g plugdev ${SUDO_USER}"
      _run "touch ${HDIR}/scripts/skipdir/.environment"
   fi
}

function _del_language {
   _task-begin "Deleting Language Files"
   _task-end
}

function _start_services {
   if [[ ! -f ${HDIR}/scripts/skipdir/.services ]]; then
      _task-begin "Starting ${OS} Services"
      _run "ln -sv /etc/sv/avahi-daemon /var/service/"
      _run "ln -sv /etc/sv/cupsd /var/service/"
      _run "ln -sv /etc/sv/dbus /var/service/"
      _run "ln -sv /etc/sv/NetworkManager /var/service/"
      _run "ln -sv /etc/sv/netmount /var/service/"
      _run "ln -sv /etc/sv/preload /var/service/"
      _run "ln -sv /etc/sv/bluetoothd /var/service/"

      if [[ ${DEVTYPE^^} == "LAPTOP" ]]; then _run "ln -sv /etc/sv/tlp /var/service"; fi
      if [[ ${MEMSIZE} -gt 5 ]]; then _run "ln -sv /etc/sv/zramen /var/service"; fi

      _run "ufw enable"
      _run "ln -sv /etc/sv/ufw /var/service/ufw"
      _task-end

      # Remove unrequired services
      _task-begin "Removing Unrequired Services"
      _run "rm -f /var/service/dhcpcd"
      if [[ ! -z ${DSKTOPENV^^} ]]; then _run "rm -f /var/service/sshd"; fi
      _task-end

      task-begin "Install Desktop Manager"
      case ${DSK^^} in
           'XFCE') _run "ln -sv /etc/sv/lightdm /var/service" ;;
         'BUDGIE') _run "ln -sv /etc/sv/elogind /var/service"
                   _run "ln -sv /etc/sv/lightdm /var/service" ;;
       'CINNAMON') _run "ln -sv /etc/sv/lightdm /var/service" ;;
          'GNOME') _run "ln -sv /etc/sv/gdm /var/service" ;;
         'PLASMA') _run "ln -sv /etc/sv/sddm /var/service" ;;
	        'LXQT') _run "ln -sv /etc/sv/lxdm /var/service" ;;
	        'LXDE') _run "ln -sv /etc/sv/lxdm /var/service" ;;         
      esac
      _task-end
      _run "touch ${HDIR}/scripts/skipdir/.services"
   fi
}

function _set_aliases {
   if [[ ! -f ${HDIR}/scripts/skipdir/.aliases ]]; then
      _task-begin "Updating Aliases"
      _run "touch $HDIR/.bash_aliases"

      printf "# LS aliases\n" >> $HDIR/.bash_aliases
      printf "alias ls='ls --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias ll='ls -la '\n" >> $HDIR/.bash_aliases

      printf "\n# System tool aliases\n" >> $HDIR/.bash_aliases
      printf "alias wget='wget -c'\n" >> $HDIR/.bash_aliases
      printf "alias df='df -H'\n" >> $HDIR/.bash_aliases
      printf "alias du='du -ch'\n" >> $HDIR/.bash_aliases
      
      printf "\n# CD aliases\n" >> $HDIR/.bash_aliases
      printf "alias cd..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias ..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias .3='cd ../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .4='cd ../../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .5='cd ../../../../..'\n" >> $HDIR/.bash_aliases

      printf "\n# Colorize the grep command output\n" >> $HDIR/.bash_aliases
      printf "alias grep='grep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias egrep='egrep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias fgrep='fgrep --color=auto'\n" >> $HDIR/.bash_aliases

      printf "\n# Date & Time aliases\n" >> $HDIR/.bash_aliases
      printf "alias now='date +%%T'\n" >> $HDIR/.bash_aliases

      printf "\n# Networking aliases\n" >> $HDIR/.bash_aliases
      printf "alias ping='ping -c 5'\n" >> $HDIR/.bash_aliases
      printf "alias fping='ping -c 100 -s.2'\n" >> $HDIR/.bash_aliases
      printf "alias ports='netstat -tulanp'\n" >> $HDIR/.bash_aliases

      printf "\n# do not delete / or prompt if deleting more than 3 files at a time #\n" >> $HDIR/.bash_aliases
      printf "alias rm='rm -I --preserve-root'\n" >> $HDIR/.bash_aliases
      
      printf "\n# confirmation #\n" >> $HDIR/.bash_aliases
      printf "alias mv='mv -i'\n" >> $HDIR/.bash_aliases
      printf "alias cp='cp -i'\n" >> $HDIR/.bash_aliases
      printf "alias ln='ln -i'\n" >> $HDIR/.bash_aliases
      
      printf "\n# Parenting changing perms on / #\n" >> $HDIR/.bash_aliases
      printf "alias chown='chown --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chmod='chmod --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chgrp='chgrp --preserve-root'\n" >> $HDIR/.bash_aliases

      printf "\n# reboot / halt / poweroff\n" >> $HDIR/.bash_aliases
      printf "alias reboot='sudo /sbin/reboot'\n" >> $HDIR/.bash_aliases
      printf "alias poweroff='sudo /sbin/poweroff'\n" >> $HDIR/.bash_aliases
      printf "alias shutdown='sudo /sbin/shutdown'\n" >> $HDIR/.bash_aliases

      printf "\n# System memory, cpu usage, and gpu memory info\n" >> $HDIR/.bash_aliases
      printf "## Get server cpu info ##\n" >> $HDIR/.bash_aliases
      printf "alias cpuinfo='lscpu'\n" >> $HDIR/.bash_aliases
      printf "alias meminfo='free -m -l -t'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating memory\n" >> $HDIR/.bash_aliases
      printf "alias psmem='ps auxf | sort -nr -k 4'\n" >> $HDIR/.bash_aliases
      printf "alias psmem10='ps auxf | sort -nr -k 4 | head -10'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating cpu ##\n" >> $HDIR/.bash_aliases
      printf "alias pscpu='ps auxf | sort -nr -k 3'\n" >> $HDIR/.bash_aliases
      printf "alias pscpu10='ps auxf | sort -nr -k 3 | head -10'\n" >> $HDIR/.bash_aliases

      printf "\n# Package Manager Aliases\n" >> $HDIR/.bash_aliases
      printf "alias update='sudo xbps-install -Syu && sudo flatpak update -y'\n" >> $HDIR/.bash_aliases
      printf "alias install='sudo xbps-install -y '\n" >> $HDIR/.bash_aliases
      printf "alias remove='sudo xbps-remove -foOy '\n" >> $HDIR/.bash_aliases

	   _run "touch ${HDIR}/scripts/skipdir/.aliases"
      _task-end
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment on $OS  ===${RESTORE}\n\n"
  if [ ! -f /$HDIR/scripts/skipdir/.desktop ]; then
     case ${DSK^^} in
           'XFCE') PROG=("xorg" "xfce4" "xfce4-clipman-plugin" "xfce4-whiskermenu-plugin"
                         "xfce4-alsa-plugin" "xfce4-netload-plugin" "xfce4-cpugraph-plugin"
                         "xfce4-weather-plugin" "xfce4-mailwatch-plugin"
                         "lightdm" "lightdm-gtk-greeter" "gnome-control-center" "thunar" 
                         "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman") ;;
         'BUDGIE') PROG=("xorg" "budgie-desktop" "plank" "lightdm" "lightdm-gtk-greeter" "gnome-control-center") ;;
       'CINNAMON') PROG=("xorg" "cinnamon-all" "plank" "lightdm" "lightdm-gtk-greeter" ) ;;
	       'GNOME') PROG=("xorg" "gnome" "gnome-apps" "pulseaudio" "gdm") ;;  
	      'PLASMA') PROG=("xorg" "kde-plasma" "kde-baseapps" "sddm") ;;                    
	        'LXQT') PROG=("xorg" "lxde" "lxdm") ;;
	        'LXDE') PROG=("xorg" "lxqt" "lxdm") ;;           
     esac
     PROG+=("lxterminal" "network-manager-applet" "wpa_supplicant" "volumeicon-alsa")

     # Install Desktop files
     _add_by_list ${PROG[*]}
     _start_services
     _run "touch /$HDIR/scripts/skipdir/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _process_update() {
  printf "\n${LPURPLE}=== Perform System Update ===${RESTORE}\n"
  _task-begin "Updating System Packages"
  _run "xbps-install -Suy"
  _task-end

  _task-begin "Updating Flatpak Packages"
  _run "flatpak update -y"
  _task-end

  _task-begin "Updating DEB/XDEB Packages"

  _task-end
}

function _prereqs {
   local PLIST=()
   if [[ ! -f /$HDIR/scripts/skipdir/.prereq ]]; then
      _task-begin "Updating Linux System"
      # Update system 
      _run "xbps-install -Suy"
      _run "xbps-install -Sy void-repo-nonfree"
      _run "xbps-install -Suy"
      _run "xbps-pkgdb -u"

      # Add system files
      _run "xbps-install -y linux-firmware-intel intel-video-accel "
      _run "xbps-install -y binutils curl dmidecode git jq nano tar unzip wget xbps xz"

      # Trim SSD and setup weekly trim
      _run "fstrim /"
      _run "mkdir /etc/cron.weekly/"
      _run "touch /etc/cron.weekly/fstrim"
      _run "printf '#!/bin/bash\nfstrim /\n' | tee /etc/cron.weekly/fstrim"
      _run "chmod u+x /etc/cron.weekly/fstrim"
      _task-end

      _task-begin "Installing Flatpak"
      _run "xbps-install -y flatpak"
      _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
      _task-end
	  
      _task-begin "Installing XDeb"
      local REL=$(curl -sL https://api.github.com/repos/xdeb-org/xdeb/releases/latest | jq -r ".tag_name")	  
      _run "curl -LO https://github.com/xdeb-org/xdeb/releases/download/${REL}/xdeb"
      _run "chmod 0744 xdeb"
	   _run "mv xdeb /usr/local/bin/"
	   _run "mkdir ${HDIR}/.config/xdeb"
	   _run "echo \"XDEB_PKGROOT=${HDIR}/.config/xdeb\" | tee /etc/environment"
	   _run "export XDEB_PKGROOT=${HDIR}/.config/xdeb"
      _task-end
	   touch /$HDIR/scripts/skipdir/.prereq
   fi
}