#!/bin/bash

SYSList=("7zip" "acpi" "acpid" "alsa-utils" "avahi-utils" "bash" "bash-completion" "bluez"
         "blueman" "cifs-utils" "cups" "dconf" "dbus-x11" "fuse" "fuse3" "git" "gvfs" "gvfs-mtp" "gvfs-smb"
		 "pipewire" "wireplumber" "alsa-pipewire" "libspa-bluetooth" "preload" "sed" "udisks2" "xarchiver")

DELList=()
APPList+=("=== Choose Browser(s) ===||"
          "Chromium Browser|chromium|N" 
		  "Firefox Browser|firefox|N"
          "Floorp Browser|@FLT-FLOORP|Y"
          "Google Chrome Browser|@FLT-GOOGLE|N"
		  "Thorium Browser|@DEB-THORIUM|Y"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|Y"
          "Waterfox Browser|@FLT-WATER|N"
          "=== Choose Office Tools ===||"
		  "Abiword Word Processor|abiword|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		  "Gnome Calculator|gnome-calculator|Y"
		  "gNumeric Spreadsheet|gnumeric|N"
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
		  "Mousepad Notepad|mousepad|Y"
		  "NotepadQQ Editor|notepadqq|Y"
		  "Notepad Next Editor|@FLT-NEXT|N"
		  "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|Y"
		  "Standard Notes|@FLT-NOTES|N"
		  "Thunderbird Email Client|thunderbird|Y"
		  "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|choqok|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|N"
          "=== Choose Development Tools ===||"
		  "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|vscode|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|bleachbit|Y"
		  "Balena Etcher|@DEB-ETCHER|Y"
          "Clam Anti Virus|clamav|N"
          "Clam Anti Virus GUI|@FLT-CLAMTK|N"
          "Disk Utility|gnome-disk-utility|Y"
		  "Fastfetch|fastfetch|Y"
		  "Flameshot Screenshot Utility|flameshot|Y"
		  "Gnome Software Manager|gnome-software|Y"
		  "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		  "Neofetch|neofetch|N"
          "Numlockx|numlockx|N"
          "Pika Backup|@FLT-PIKA|Y"
		  "Putty SSH Utility|putty|Y"
		  "Stacer|@DEB-STACER|Y"
		  "System Monitor|@FLT-MONITOR|N"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|N"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Image Writer|imagewriter|Y"
          "Impress USB Writer|@FLT-IMPRESS|Y"
          "=== Choose Emulation Tools ===||"
		  "Bottles Windows Emulation|@FLT-BOTTLE|N"
          "Play On Linux|@FLT-PLAY|N"
		  "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine Tricks|winetricks|N"
          "=== Choose Virtualization Tools ===||"
		  "Docker|docker|N"
		  "Gnome Boxes|gnome-boxes|Y"
		  "Podman|podman|N"
		  "Virtualization Manager|virt-manager|N"
		  "Virtualization Manager Tools|virt-manager-tools|N"
          "=== Choose Optional Applications ===||"
		  "Calibre eBook Manager|calibre|N"
		  "Cheese Camera Utility|cheese|N"
		  "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|@FLT-KODI|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		  "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
		  "VLC Media Player|vlc|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  # Disable Root Login
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
    _run "sed -i s'#root:/bin/sh#root:/sbin/nologin#' /etc/passwd"
  fi
  _task-end

  # Update Terminal Profile
  _task-begin "Update $OS Terminal Profile"
  RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
  if [ ${RET} == 0 ]; then
     _run "printf \"PS1='${PS1}'\nexport PS1\" | tee -a /etc/profile"
  fi
  printf "${OVERWRITE}${OVERWRITE}${OVERWRITE}"
  _task-end

  # Remove MOTD
  _task-begin "Removing MOTD"
  if [ -f /etc/motd ]; then _run "rm /etc/motd"; fi
  _task-end

  #================ Change Shell to Bash ===========
  if [[ $(grep -c '/bin/ash' /etc/passwd) == 0 ]]; then
     _task-begin "Change Shell to BASH"
     _run "sed 's#/bin/sh#/bin/bash#' /etc/passwd"
     _task-end
  fi
               
  # Install Pipewire
  if (( $(_Exists "pipewire") == 0 )); then
     printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
     _task-begin "Set Pipewire User Groups"
     _run "addgroup ${SUDO_USER} audio"
     _run "addgroup ${SUDO_USER} video"
     _task-end
  fi
  _run "addgroup ${SUDO_USER} plugdev"         
}

function _del_language {
  _task-begin "Deleting Language Files"
  _task-end
}

function _start_services {
  _task-begin "Starting Services"
  _task-end
}

function _set_aliases {
   if [[ -f $HDIR/.bash_aliases ]]; then
     if [[ ! $HDIR/.aliases ]]; then
        echo "alias update='sudo xbps-install -Syu'" | tee $HDIR/.bash_aliases
        echo "alias install='sudo xbps-install -y '" | tee $HDIR/.bash_aliases
        echo "alias remove='sudo xbps-remove '" | tee $HDIR/.bash_aliases
	    touch $HDIR/.aliases
	 fi
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment on $OS  ===${RESTORE}\n\n"
  if [ ! -f /usr/share/.desktop ]; then
     PROG=("NetworkManager" "network-manager-applet" "gvfs-mtp" "gvfs-smb" "udisks2" "lxterminal"
	       "Thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman" "volumeicon")

     case ${DSK^^} in
        'XFCE') PROG+=("xfce4-clipman-plugin" "xfce4-whiskermenu-plugin") ;;
      'BUDGIE') PROG+=("budgie-desktop" "budgie-control-center" "magpie") ;;
    'CINNAMON') PROG+=("cinnamon" "gnome-keyring" "colord" "gnome-terminal") ;;
	    'LXQT') PROG+=("lxqt" "qupzilla") ;;
     esac

     _add_by_list ${PROG[*]}
     _run "touch /usr/share/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"
   local PLIST=()

   if [[ ! -f ${HDIR}/.prereq ]]; then
      printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n"
      _task-begin "Updating Linux System"
      _run "xbps-install -Suy"
	  _run "xbps-install -Sy void-repo-nonfree"
	  _run "xbps-install -Suy"
	  _run "xbps-install -y linux-firmware-intel intel-video-accel curl wget unzip nano binutils git tar jq xbps xz"
	  _run "fstrim /"
	  _run "mkdir /etc/cron.weekly/"
	  _run "touch /etc/cron.weekly/fstrim"
	  _run "printf '#!/bin/bash\nfstrim /' | tee /etc/cron.weekly/fstrim"
	  _run "chmod u+x /etc/cron.weekly/fstrim"
	  _task-end

      _task-begin "Installing Flatpak"
      _run "xbps-install -y flatpak"
      _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
      _task-end
	  
      _task-begin "Installing XDeb"
      local REL=$(curl -sL https://api.github.com/repos/xdeb-org/xdeb/releases/latest | jq -r ".tag_name")	  
      _run "curl -LO https://github.com/xdeb-org/xdeb/releases/download/${REL}/xdeb"
      _run "chmod 0744 xdeb"
	  _run "mv xdeb /usr/local/bin/"
	  _run "mkdir ${HDIR}/.config/xdeb"
	  _run "echo \"XDEB_PKGROOT=${HDIR}/.config/xdeb\" | tee /etc/environment"
	  _run "export XDEB_PKGROOT=${HDIR}/.config/xdeb"
      _task-end
	  touch ${HDIR}/.prereq
   fi
}