#!/bin/bash

SYSList=("7zip" "avahi" "avahi-utils" "bash" "bash-completion" "binutils"
         "cifs-utils" "cmake" "gcc" "git" "gvfs" "gvfs-mtp" "gvfs-smb" 
         "gzip" "linux-firmware-intel" "linux-headers" "linux-lts-headers"
         "linux-tools" "make" "nano" "netcat" "preload" "rsync" "sed"
         "sv-netmount" "ufw" "unzip" "xz" "zramen" "zstd")


DESKList=("alsa-utils" "alsa-plugins-ffmpeg" "alsa-pipewire" "bluez" "blueman" "cups" 
          "cups-pk-helper" "cups-filters" "dconf" "dejavu-fonts-ttf" "dbus-elogind"
          "elogind" "foomatic-db" "foomatic-db-engine" "gufw" "libspa-bluetooth"
          "NetworkManager" "pipewire" "powertop" "terminus-font" "tlp" "tlp-rdw" "xarchiver")

DELList=("firefox" "orca")

APPList+=("=== Choose Browser(s) ===||"
          "Chromium Browser|chromium|N" 
	       "Firefox Browser|firefox|N"
          "Floorp Browser|@FLT-FLOORP|N"
          "Google Chrome Browser|@FLT-GOOGLE|N"
	       "Thorium Browser|@XDB-THORIUM|Y"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|Y"
          "Waterfox Browser|@FLT-WATER|N"
          "=== Choose Office Tools ===||"
	       "Abiword Word Processor|abiword|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|Y"
	       "Gnome Calculator|gnome-calculator|Y"
	       "gNumeric Spreadsheet|gnumeric|N"
	       "Leafpad Notepad|leafpad|N"          
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
	       "Mousepad Notepad|mousepad|Y"
	       "NotepadQQ Editor|notepadqq|N"
	       "Notepad Next Editor|@FLT-NEXT|N"
	       "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|N"
	       "Standard Notes|@FLT-NOTES|N"
	       "Thunderbird Email Client|thunderbird|N"
	       "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|choqok|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|N"
          "=== Choose Development Tools ===||"
	       "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|vscode|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|bleachbit|Y"
	       "Balena Etcher|@XDB-ETCHER|Y"
          "Clam Anti Virus|clamav|Y"
          "Clam Anti Virus GUI|@FLT-CLAMTK|Y"
          "Disk Utility|gnome-disk-utility|Y"
	       "Fastfetch|fastfetch|Y"
	       "Flameshot Screenshot Utility|flameshot|Y"
	       "Gnome Software Manager|gnome-software|Y"
	       "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
	       "Neofetch|neofetch|N"
          "Numlockx|numlockx|N"
          "Pika Backup|@FLT-PIKA|Y"
	       "Putty SSH Utility|putty|N"
	       "Stacer|@XDB-STACER|Y"
	       "System Monitor|@FLT-MONITOR|N"
          "Timeshift System Snapshot|timeshift|Y"
          "uLauncher|ulauncher|Y"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Image Writer|imagewriter|N"
          "Impress USB Writer|@FLT-IMPRESS|N"
          "=== Choose Emulation Tools ===||"
	       "Bottles Windows Emulation|@FLT-BOTTLE|N"
          "Play On Linux|@FLT-PLAY|N"
	       "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine Tricks|winetricks|N"
	       "WinBoat|@DEB-BOAT|N"
          "=== Choose Virtualization Tools ===||"
	       "Docker|docker|N"
	       "Gnome Boxes|gnome-boxes|Y"
	       "Podman|podman|N"
	       "Virtualization Manager|virt-manager|N"
	       "Virtualization Manager Tools|virt-manager-tools|N"
          "=== Choose Optional Applications ===||"
	       "Calibre eBook Manager|calibre|N"
	       "Cheese Camera Utility|cheese|N"
	       "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|@FLT-KODI|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
	       "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
	       "VLC Media Player|vlc|Y")

function _setup_environment {
   local PREVFN="${FN}" && FN="_setup_environment()"

   if [[ ! -f ${HDIR}/scripts/skipdir/.environment ]]; then
      # Disable Root Login
      _task-begin "Disable Root Login"
      RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
      if [ ${RET} == 0 ]; then _run "sed -i s'#root:/bin/sh#root:/sbin/nologin#' /etc/passwd"; fi
      _task-end

      # Update Terminal Profile
      _task-begin "Update $OS Terminal Profile"
      RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
      if [ ${RET} == 0 ]; then printf "PS1='${PS1}'\nexport PS1\n" >> /etc/profile; fi
      printf "${OVERWRITE}${OVERWRITE}${OVERWRITE}"
      _task-end

      # Change Shell to Bash
      if [[ $(grep -c '/bin/ash' /etc/passwd) == 0 ]]; then
         _task-begin "Change Shell to BASH"
         _run "sed -i 's#/bin/sh#/bin/bash#' /etc/passwd"
         _task-end
      fi

      # Remove Default Themes
      _task-begin "Remove Default XFCE themes"
      for dir in /usr/share/themes/*; do
          [ "$dir" = "Default" ] && continue
          [ "$dir" = "Gtk" ] && continue
          [ "$dir" = "Xfce" ] && continue
          _run "rm -rf $dir"
      done
      
      _task-end

      # Install Pipewire
      if (( $(_Exists "pipewire") == 0 )); then
         printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
         _task-begin "Set Pipewire User Groups"
         _run "usermod -aG audio ${SUDO_USER}"
         _run "usermod -aG video ${SUDO_USER}"
	      _run "usermod -aG input ${SUDO_USER}"
         _task-end
      fi
      _run "usermod -aG plugdev ${SUDO_USER}"
      _run "touch ${HDIR}/scripts/skipdir/.environment"
   fi
   FN="${PREVFN}"
}

function _del_language {
   _task-begin "Deleting Language Files"
   _task-end
}

function _start_services {
   local PREVFN="${FN}" && FN="_start_services()"

   if [[ ! -f ${HDIR}/scripts/skipdir/.services ]]; then
      _task-begin "Starting ${OS} Services"
      _run "ln -sv /etc/sv/avahi-daemon /var/service/"
      _run "ln -sv /etc/sv/cupsd /var/service/"
      _run "ln -sv /etc/sv/dbus /var/service/"
      _run "ln -sv /etc/sv/NetworkManager /var/service/"
      _run "ln -sv /etc/sv/netmount /var/service/"
      _run "ln -sv /etc/sv/preload /var/service/"
      _run "ln -sv /etc/sv/bluetoothd /var/service/"
      _run "ln -sv /etc/sv/clamd /var/service/"

      if [[ ${DEVTYPE^^} == "LAPTOP" ]]; then _run "ln -sv /etc/sv/tlp /var/service"; fi
      if [[ ${MEMSIZE} -gt 5 ]]; then _run "ln -sv /etc/sv/zramen /var/service"; fi
      if [[ ${DEV^^} == "DESKTOP" ]]; then
          if [[ $(rc-status --list | grep -c "sshd") > 0 ]]; then _run "rc-update del sshd"
      fi
      
      #_run "ufw enable"
      #_run "ln -sv /etc/sv/ufw /var/service/ufw"
      _task-end

      # Remove unrequired services
      _task-begin "Removing Unrequired Services"
      _run "rm -f /var/service/dhcpcd"
      if [[ ! -z ${DSKTOPENV^^} ]]; then _run "rm -f /var/service/sshd"; fi
      _task-end

      task-begin "Install Desktop Manager"
      case ${DSK^^} in
           'XFCE') _run "ln -sv /etc/sv/lightdm /var/service" ;;
      esac
      _task-end
      _run "touch ${HDIR}/scripts/skipdir/.services"
   fi
   FN="${PREVFN}"
}

function _set_aliases {
   local PREVFN="${FN}" && FN="_set_aliases()"

   if [[ ! -f ${HDIR}/scripts/skipdir/.aliases ]]; then
      _task-begin "Updating Aliases"
      _run "touch $HDIR/.bash_aliases"

      printf "# LS aliases\n" >> $HDIR/.bash_aliases
      printf "alias ls='ls --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias ll='ls -la '\n" >> $HDIR/.bash_aliases

      printf "\n# System tool aliases\n" >> $HDIR/.bash_aliases
      printf "alias wget='wget -c'\n" >> $HDIR/.bash_aliases
      printf "alias df='df -H'\n" >> $HDIR/.bash_aliases
      printf "alias du='du -ch'\n" >> $HDIR/.bash_aliases
      
      printf "\n# CD aliases\n" >> $HDIR/.bash_aliases
      printf "alias cd..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias ..='cd ..'\n" >> $HDIR/.bash_aliases
      printf "alias .3='cd ../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .4='cd ../../../../'\n" >> $HDIR/.bash_aliases
      printf "alias .5='cd ../../../../..'\n" >> $HDIR/.bash_aliases

      printf "\n# Colorize the grep command output\n" >> $HDIR/.bash_aliases
      printf "alias grep='grep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias egrep='egrep --color=auto'\n" >> $HDIR/.bash_aliases
      printf "alias fgrep='fgrep --color=auto'\n" >> $HDIR/.bash_aliases

      printf "\n# Date & Time aliases\n" >> $HDIR/.bash_aliases
      printf "alias now='date +%%T'\n" >> $HDIR/.bash_aliases

      printf "\n# Networking aliases\n" >> $HDIR/.bash_aliases
      printf "alias ping='ping -c 5'\n" >> $HDIR/.bash_aliases
      printf "alias fping='ping -c 100 -s.2'\n" >> $HDIR/.bash_aliases
      printf "alias ports='netstat -tulanp'\n" >> $HDIR/.bash_aliases

      printf "\n# do not delete / or prompt if deleting more than 3 files at a time #\n" >> $HDIR/.bash_aliases
      printf "alias rm='rm -I --preserve-root'\n" >> $HDIR/.bash_aliases
      
      printf "\n# confirmation #\n" >> $HDIR/.bash_aliases
      printf "alias mv='mv -i'\n" >> $HDIR/.bash_aliases
      printf "alias cp='cp -i'\n" >> $HDIR/.bash_aliases
      printf "alias ln='ln -i'\n" >> $HDIR/.bash_aliases
      
      printf "\n# Parenting changing perms on / #\n" >> $HDIR/.bash_aliases
      printf "alias chown='chown --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chmod='chmod --preserve-root'\n" >> $HDIR/.bash_aliases
      printf "alias chgrp='chgrp --preserve-root'\n" >> $HDIR/.bash_aliases

      printf "\n# reboot / halt / poweroff\n" >> $HDIR/.bash_aliases
      printf "alias reboot='sudo /sbin/reboot'\n" >> $HDIR/.bash_aliases
      printf "alias poweroff='sudo /sbin/poweroff'\n" >> $HDIR/.bash_aliases
      printf "alias shutdown='sudo /sbin/shutdown'\n" >> $HDIR/.bash_aliases

      printf "\n# System memory, cpu usage, and gpu memory info\n" >> $HDIR/.bash_aliases
      printf "## Get server cpu info ##\n" >> $HDIR/.bash_aliases
      printf "alias cpuinfo='lscpu'\n" >> $HDIR/.bash_aliases
      printf "alias meminfo='free -m -l -t'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating memory\n" >> $HDIR/.bash_aliases
      printf "alias psmem='ps auxf | sort -nr -k 4'\n" >> $HDIR/.bash_aliases
      printf "alias psmem10='ps auxf | sort -nr -k 4 | head -10'\n" >> $HDIR/.bash_aliases
      printf "## get top process eating cpu ##\n" >> $HDIR/.bash_aliases
      printf "alias pscpu='ps auxf | sort -nr -k 3'\n" >> $HDIR/.bash_aliases
      printf "alias pscpu10='ps auxf | sort -nr -k 3 | head -10'\n" >> $HDIR/.bash_aliases

      printf "\n# Package Manager Aliases\n" >> $HDIR/.bash_aliases
      printf "alias update='sudo xbps-install -y xbps && sudo xbps-install -Syu && sudo flatpak update -y && freshclam'\n" >> $HDIR/.bash_aliases
      printf "alias install='sudo xbps-install -y '\n" >> $HDIR/.bash_aliases
      printf "alias remove='sudo xbps-remove -foOy '\n" >> $HDIR/.bash_aliases

      _run "touch ${HDIR}/scripts/skipdir/.aliases"
      _task-end
   fi
   FN="${PREVFN}"
}

function _installDesktop {
  local PROG=()
  local PREVFN="${FN}" && FN="_install_Desktop()"

  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment on $OS  ===${RESTORE}\n\n"
  if [ ! -f /$HDIR/scripts/skipdir/.desktop ]; then
     case ${DSK^^} in
	   'XFCE') PROG=("xinit" "xorg" "xtools" "xdotool" "xfce4" "xfce4-clipman-plugin"
                    "xfce4-whiskermenu-plugin" "xfce4-alsa-plugin" "xfce4-netload-plugin"
                    "xfce4-cpugraph-plugin" "xfce4-battery-plugin" "xfce4-genmon-plugin"
                    "xfce4-screenshooter" "xfce4-weather-plugin" "xfce4-mailwatch-plugin"
                    "lightdm" "gnome-control-center" "thunar-archive-plugin" "thunar-media-tags-plugin") ;;
       'CINNAMON') PROG=("xorg" "cinnamon-all" "plank" "lightdm" "lightdm-gtk-greeter") ;;
           'LXQT') PROG=("xorg" "lxqt" "lightdm" "lightdm-gtk-greeter") ;;
	       'GNOME') PROG=("xorg" "gnome" "gnome-apps" "pulseaudio" "gdm") ;;  
	      'PLASMA') PROG=("xorg" "kde-plasma" "kde-baseapps" "sddm") ;;                    
     esac
     PROG+=("lxterminal" "network-manager-applet" "tango-icon-theme"
            "intel-video-accel" "xf86-video-intel" "mesa-intel-dri")

     # Install Desktop files
     _add_by_list ${PROG[*]}

     _task-begin "Installing Flatpak"
     _run "xbps-install -y flatpak"
     _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
     _task-end	 
     _run "touch /$HDIR/scripts/skipdir/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
  FN="${PREVFN}"
}

function _process_update() {
  local PREVFN="${FN}" && FN="_process_update()"

  printf "\n${LPURPLE}=== Perform System Update ===${RESTORE}\n"
  _task-begin "Updating System Packages"
  _run "xbps-install -Suy"
  _task-end

  _task-begin "Updating Flatpak Packages"
  _run "flatpak update -y"
  _task-end

  _task-begin "Updating DEB/XDEB Packages"
  _task-end
  FN="${PREVFN}"
}

function _prereqs {
   local PLIST=()
   local PREVFN="${FN}" && FN="_prereqs()"

   if [[ ! -f /$HDIR/scripts/skipdir/.prereq ]]; then
      _task-begin "Updating Linux System"
      # Update system 
      _run "xbps-install -uy xbps"
      _run "xbps-install -Suy"
      _run "xbps-install -Sy void-repo-nonfree"
      _run "xbps-install -Suy"
      _run "xbps-pkgdb -u"

      # Trim SSD and setup weekly trim
      _run "fstrim /"
      _run "mkdir -p /etc/cron.weekly/"
      _run "touch /etc/cron.weekly/fstrim"
      printf '#!/bin/bash\nfstrim /\n' | tee /etc/cron.weekly/fstrim 2>&1>/dev/null
      _run "chmod u+x /etc/cron.weekly/fstrim"
      _task-end

      # Add system files
      PLIST=("curl" "jq" "nano" "tar" "unzip" "wget" "xz" "dmidecode" "zstd")
      _add_by_list ${PLIST[*]}
	  
      _task-begin "Installing XDeb"
      local REL=$(curl -sL https://api.github.com/repos/xdeb-org/xdeb/releases/latest | jq -r ".tag_name")	  
      _run "curl -LO https://github.com/xdeb-org/xdeb/releases/download/${REL}/xdeb"
      _run "chmod 0744 xdeb"
      _run "mv xdeb /usr/local/bin/"
      _run "mkdir -p ${HDIR}/.config/xdeb"
      echo "XDEB_PKGROOT=${HDIR}/.config/xdeb" | tee /etc/environment 2>&1>/dev/null
      _run "export XDEB_PKGROOT=${HDIR}/.config/xdeb"
      _task-end

      if [[ ! -d ${HDIR}/scripts/skipdir/ ]]; then _run "mkdir -p $HDIR/scripts/skipdir/"; fi
      touch $HDIR/scripts/skipdir/.prereq >/dev/null
   fi
   FN="${PREVFN}"
}