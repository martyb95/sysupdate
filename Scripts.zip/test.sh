#!/bin/bash

function exists() {
   local RET=0
   local VAL=""
   if [[ ! -z $1 ]]; then VAL=$(getValue $1 $2); fi
   if [[ ! -z $VAL ]]; then RET=1; fi
   printf "$RET"
}

function getValue() {
   local RET=""
   if [[ ! -z $1 ]]; then 
      if [[ ! -z $2 ]]; then RET=$(xfconf-query -c $1 -p "$2" >/dev/null); fi
   fi
   printf "$RET"
}

function setValue() {
   if [[ ! -z $1 ]]; then 
      if [[ ! -z $2 ]]; then 
         if [[ ! -z $3 ]]; then
            if [[ $(exists "$1" "$2") == "1" ]]; then
               if [[ ${3} == *" "* ]]; then
                  xfconf-query -c $1 -p $2 -s "$3"
               else
                  xfconf-query -c $1 -p $2 -s $3
               fi
            else
               TYP=$4
               if [[ -z $TYP ]]; then TYP="string"; fi
               if [[ ${3} == *" "* ]]; then
                  xfconf-query -c $1 -p $2 -n -t ${TYP,,} -s "$3"
               else
                  xfconf-query -c $1 -p $2 -n -t ${TYP,,} -s $3
               fi
            fi
         fi
      fi
   fi      
}

function delItem() {
   if [[ ! -z $1 ]]; then 
      if [[ ! -z $2 ]]; then xfconf-query -c $1 -p $2 -r -R; fi
   fi   
}

function findPlugin() {
  local RET=""
  if [[ ! -z $1 ]]; then RET=$(xfce4-panel -p /plugin -lv |grep "$1" |cut -d"   " -f1); fi
  printf "$RET"
}

function setBackground() {
   if [[ ! -z $1 ]]; then 
      xfconf-query -c xfce4-desktop -l \
      | grep "/last-image" \
      | xargs -n 1 -I '{}' xfconf-query -c xfce4-desktop -p {} -s $1
   fi
}


# Hide Suspend, Hibernate, and Hybrid Sleep from the logout dialog:
setValue "xfce4-session" "/shutdown/ShowSuspend" "false" "bool"
setValue "xfce4-session" "/shutdown/ShowHibernate" "false" "bool"
setValue "xfce4-session" "/shutdown/ShowHybridSleep" "false" "bool"

# General Settings 
setValue "xsettings" "/Gtk/FontName" "Sans 10"
setValue "xsettings" "/Gtk/MonospaceFontName" "Monospace 10"
setValue "xsettings" "/Gtk/ToolbarIconSize" "3" "int"
setValue "xsettings" "/Gtk/ToolbarStyle" "icons"
setValue "xsettings" "/Net/IconThemeName" "gnome-dust"
setValue "xsettings" "/Net/ThemeName" "Skeuos-Yellow-Dark"
setValue "xsettings" "/Xfce/SyncThemes" "true" "bool"

#Desktop Setup
setValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-filesystem" "false" "bool"
setValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-home" "false" "bool"
setValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-removable" "false" "bool"
setValue "xfce4-desktop" "/backdrop/desktop-icons/file-icons/show-trash" "true" "bool"
setValue "xfce4-desktop" "/desktop-icons/file-icons/show-filesystem" "false" "bool"
setValue "xfce4-desktop" "/desktop-icons/file-icons/show-home" "false" "bool"
setValue "xfce4-desktop" "/desktop-icons/file-icons/show-removable" "false" "bool"
setValue "xfce4-desktop" "/desktop-icons/file-icons/show-trash" "true" "bool"
setValue "xfce4-desktop" "/desktop-icons/primary" "true" "bool"
setValue "xfce4-desktop" "/desktop-icons/style" "1" "int"

MON=("monitor0" "monitor1" "monitorHDMI-1" "monitorDVI-D-1/monitorVGA-1" "monitorVGA-1" "monitorVirtual-1")
WORK=("workspace0" "workspace1" "workspace3")
BACK="/usr/share/backgrounds/eGna2qBdawpRZpuq.jpg"
for myMon in "${MON[@]}"
do
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/color-style" "1" "int"
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/image-path" "$BACK"
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/image-show" "true" "bool"
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/image-style" "5" "int"
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/last-image" "$BACK"
  setValue "xfce4-desktop" "/backdrop/screen0/$myMon/last-single-image" "$BACK"
  for myWork in "${WORK[@]}"
  do
     setValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/color-style" "1" "int"
     setValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/image-style" "5" "int"
     setValue "xfce4-desktop" "/backdrop/screen0/$myMon/$myWork/last-image" "$BACK"
  done
done


# Top Menu Panel Setup
setValue "xfce4-panel" "/panels/panel-1/icon-size" "28" "int"
setValue "xfce4-panel" "/panels/panel-1/length" "100" "uint"
setValue "xfce4-panel" "/panels/panel-1/position" "p=6;x=0;y=0"
setValue "xfce4-panel" "/panels/panel-1/position-locked" "true" "bool"
setValue "xfce4-panel" "/panels/panel-1/icon-size" "24" "uint"
setValue "xfce4-panel" "/panels/panel-1/size" "32" "uint"
setValue "xfce4-panel" "/panels/panel-1/mode" "0" "uint"

setValue "xfce4-panel" "/panels/panel-2/autohide-behavior" "1" "uint"
setValue "xfce4-panel" "/panels/panel-2/background-style" "1" "uint"
setValue "xfce4-panel" "/panels/panel-2/length" "1" "uint"
setValue "xfce4-panel" "/panels/panel-2/position" "p=12;x=629;y=765"
setValue "xfce4-panel" "/panels/panel-2/position-locked" "true" "bool"
setValue "xfce4-panel" "/panels/panel-2/size" "48" "uint"
setValue "xfce4-panel" "/panels/panel-2/mode" "0" "uint"

delItem "xfce4-panel" "/panels/panel-3"

setValue "xfce4-panel" "/plugins/clipman/tweaks/never-confirm-history-clear" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-1" "xfce4-clipman-plugin"
setValue "xfce4-panel" "/plugins/plugin-2" "tasklist"
setValue "xfce4-panel" "/plugins/plugin-2/grouping" "false" "bool"
setValue "xfce4-panel" "/plugins/plugin-2/show-handle" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-2/show-labels" "false" "bool"
setValue "xfce4-panel" "/plugins/plugin-3" "separator"
setValue "xfce4-panel" "/plugins/plugin-3/expand" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-3/style" "0" "uint"
setValue "xfce4-panel" "/plugins/plugin-4" "pager"
setValue "xfce4-panel" "/plugins/plugin-4/miniature-view" "false" "bool"
setValue "xfce4-panel" "/plugins/plugin-4/rows" "1" "uint"
setValue "xfce4-panel" "/plugins/plugin-4/workspace-scrolling" "false" "bool"
setValue "xfce4-panel" "/plugins/plugin-5" "separator"
setValue "xfce4-panel" "/plugins/plugin-5/style" "1" "uint"
setValue "xfce4-panel" "/plugins/plugin-6" "systray"
setValue "xfce4-panel" "/plugins/plugin-6/square-icons" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-7" "whiskermenu"
setValue "xfce4-panel" "/plugins/plugin-8" "pulseaudio"
setValue "xfce4-panel" "/plugins/plugin-8/enable-keyboard-shortcuts" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-8/mpris-players" "chromium.instance12148;chromium.instance123801;chromium.instance128775;chromium.instance140873;chromium.instance168203"
setValue "xfce4-panel" "/plugins/plugin-8/show-notifications" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-9" "power-manager-plugin"
setValue "xfce4-panel" "/plugins/plugin-10" "notification-plugin"
setValue "xfce4-panel" "/plugins/plugin-11" "separator"
setValue "xfce4-panel" "/plugins/plugin-11/style" "0" "uint"
setValue "xfce4-panel" "/plugins/plugin-12" "clock"
setValue "xfce4-panel" "/plugins/plugin-12/digital-layout" "3" "uint"
setValue "xfce4-panel" "/plugins/plugin-12/digital-time-font" "Nimbus Sans Bold 12"
setValue "xfce4-panel" "/plugins/plugin-12/digital-time-format" "%a %h %d,%l:%M %p"
setValue "xfce4-panel" "/plugins/plugin-13" "separator"
setValue "xfce4-panel" "/plugins/plugin-13/style" "0" "uint"
setValue "xfce4-panel" "/plugins/plugin-14" "actions"
setValue "xfce4-panel" "/plugins/plugin-14/button-title" "3" "uint"
setValue "xfce4-panel" "/plugins/plugin-14/custom-title" "Exit"
setValue "xfce4-panel" "/plugins/plugin-15" "launcher"
setValue "xfce4-panel" "/plugins/plugin-16" "separator"
setValue "xfce4-panel" "/plugins/plugin-17" "launcher"
setValue "xfce4-panel" "/plugins/plugin-18" "launcher"
setValue "xfce4-panel" "/plugins/plugin-19" "launcher"
setValue "xfce4-panel" "/plugins/plugin-20" "launcher"
setValue "xfce4-panel" "/plugins/plugin-21" "separator"
setValue "xfce4-panel" "/plugins/plugin-22" "thunar-tpa"
setValue "xfce4-panel" "/plugins/plugin-23" "separator"
setValue "xfce4-panel" "/plugins/plugin-23/expand" "true" "bool"
setValue "xfce4-panel" "/plugins/plugin-23/style" "0" "uint"
setValue "xfce4-panel" "/plugins/plugin-24" "launcher"
setValue "xfce4-panel" "/plugins/plugin-25" "launcher"
setValue "xfce4-panel" "/plugins/plugin-26" "launcher"
setValue "xfce4-panel" "/plugins/plugin-27" "launcher"
setValue "xfce4-panel" "/plugins/plugin-28" "launcher"
setValue "xfce4-panel" "/plugins/plugin-29" "launcher"
setValue "xfce4-panel" "/plugins/plugin-30" "separator"
setValue "xfce4-panel" "/plugins/plugin-31" "launcher"
setValue "xfce4-panel" "/plugins/plugin-33" "launcher"