#!/bin/bash

function getName() {
   local MAX=16
   local CTR=0
   local PTR=0
   local OUT=""
   local STR="ABCDEFGHI@#*?!JKLMNOPQRSTUVWXYZ@!~+?#*012345789abcdefghijklmnopqrstuvwxyz"

   if [ ! -z $1 ]; then MAX=$1; fi
   while [ $CTR -lt $MAX ]; do
      PTR=$((RANDOM % ${#STR}))
      OUT="$OUT${STR:$PTR-1:1}"
      CTR=$(( CTR + 1 ))
   done
   printf "$OUT"
}

DIR="$1"
if [ -z $DIR ]; then DIR="."; fi
for FIL in $( ls $DIR/*.{jpg,bmp,gif,png,jpeg} ); do
  NEW=$( getName )
  NEW="$( dirname $FIL )/$NEW.${FIL##*.}"
  mv -f $FIL $NEW
done
