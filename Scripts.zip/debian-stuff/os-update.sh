#! /usr/bin/bash
LOG="/home/martin/Documents/Scripts/os-update.log"
printf "\n========================================================================\n\n" > ${LOG}
printf "      OS Update                        $(date)\n\n" >> ${LOG}
printf "========================================================================\n\n" >> ${LOG}
echo "Mylock2003" | sudo -S apt-get update &>> ${LOG}
sudo apt-get upgrade -y &>> ${LOG}
sudo apt-get autoremove -y &>> ${LOG}
