#!/bin/bash

# script must be run as root
if [[ $(id -u) == 0 ]] ; then
   printf "\n\n*************** Must NOT be run as root ***************\n\n\n"
   exit 1
fi

#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'
LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'
OVERWRITE='\e[1A\e[K'

LAY="777"
HDIR="/home/$USER"
LOG="${HDIR}/xfce.log"
ValidOS="DEBIAN ELEMENTARY UBUNTU SPARKY LINUXMINT"

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release >>$LOG 2>&1
   OS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   OS=$( uname )
fi

# Operating system must be one of the valid ones
if [[ ${ValidOS^^} != *${OS^^}* ]]; then
   printf "\n\n********** [${OS^^}] Is An Invalid OS.  Should be a Debian or Ubuntu Distro *******\n\n\n";
   exit 1
fi

#========================================================
#    Task Functions
#========================================================
function _run() {
    local _cmd="$1 >>$LOG 2>&1"
    printf "\n==== $1 ====\n\n" >> $LOG
    eval ${_cmd}
}

function _task-begin() {
   TASK=$1
   printf "\n\n============================= Start of $TASK =============================\n\n" >> ${LOG}
   printf "${LCYAN} [ ]  ${TASK} \n${LRED}"
}

function _task-end() {
   printf "\n\n============================= End of $TASK =============================\n\n" >> ${LOG}
   printf "${OVERWRITE}${LGREEN} [✓]  ${LGREEN}${TASK}${RESTORE}\n"
   TASK=""
}

function _log-msg() {
   printf "     ${1}\n" >> ${LOG}
}


#========================================================
#    Input Functions
#========================================================
function _Ask(){
  if  [[ ${2} != "" ]]; then
    printf "${LGREEN}${1} ${YELLOW}[${2}]: ${RESTORE}"
    read REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="${2}" ; fi
  else
    printf "${LGREEN}${1}: ${RESTORE}"
    read REPLY
  fi
  REPLY=${REPLY^^}
}

function _AskYN(){
  local __flg="N"
  while [[ ${__flg} == "N" ]]
  do
    printf "${LGREEN}${1}? ${YELLOW}[${2}]: ${RESTORE}"
    read -n 1 REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="$2" ; else echo " "; fi

    case ${REPLY^^} in
      [Y]* ) __flg="Y";;
      [N]* ) __flg="Y";;
      [R]* ) __flg="Y";;
      * ) printf "${RED}ERROR - Invalid Option Entered [Y/N]${RESTORE}\n\n"; __flg="N";;
    esac
  done
  REPLY=${REPLY^^}
}


#========================================================
#    Main Functions
#========================================================
function Exists() {
   local RET=$(xfconf-query -c ${1} -p ${2} 2>@1 | grep -c "does not exist")
   printf "%u" ${RET}
}

function Set() {
   local CAT="$1"
   local PAR="$2"
   local UPD="$3"
   
   if (( $(Exists $CAT $PAR) == 0 )); then
      _task-begin "Updating ${PAR}"
      _run "xfconf-query -c ${CAT} -p ${PAR} -s ${UPD}"
      _task-end
   fi
}

function Setup_XFCE() {
   # === Yellow Backgrounds ===
   #vyYvUseebgNgzzGQ.jpg"   # Yellow Misty Lake
   #eGna2qBdawpRZpuq.jpg"   # Yellow Tree
   #auUagbqqV2gbGi8w.jpg"   # Yellow Toronto

   # === Blue Backgrounds ===
   #8pplzWJvxVoxqrCE.jpg"   # Volcano Lake
   #oC8iorz2BlyAeEQi.jpg"   # Blue Dock
   #Cv0ZEeqOw7vMz1ez.jpg"   # Blue Toronto

   local _COLOR="YELLOW"
   local _IMAGE="8pplzWJvxVoxqrCE.jpg"
   local _THEME="Skeous-Yellow-Dark"
   local _ICON="gnome-dust"
   local _TYPE="Top"
   local _PNL1=""
   local _PNL3=""
   local _MENU=""
   local CAT=""
   local BACK=""
   local PARAM=""
   local TMP=""
   
   case ${LAY^^} in
      # Top Menu - Yellow Theme
      1) _COLOR="YELLOW"
	     _IMAGE="eGna2qBdawpRZpuq.jpg"
		 _THEME="Skeuos-Yellow-Dark"
		 _ICON="gnome-dust"
         _TYPE="Top"
         _MENU="menu_13.png"
         _PNL1="-t double -s 0 -t double -s 0 -t double -s 0 -t double -s 0"
         _PNL3=""
	     ;;
      # Top Menu - Blue Theme
      2) _COLOR="BLUE"
		 _IMAGE="oC8iorz2BlyAeEQi.jpg"
		 _THEME="Orchis-Dark"
		 _ICON="Boston"
         _TYPE="$Top"
         _MENU="menu_05.png"
         _PNL1="-t double -s 0.022667 -t double -s 0.210541 -t double -s 0.453333 -t double -s 0.647651"
         _PNL3=""
	     ;;
      # Bottom Menu - Yellow Theme
      3) _COLOR="YELLOW"
	     _IMAGE="eGna2qBdawpRZpuq.jpg"
      	 _THEME="Skeuos-Yellow-Dark"
		 _ICON="gnome-dust"
         _TYPE="Bottom"
         _MENU="menu_13.png"
         _PNL1="-t double -s 0 -t double -s 0 -t double -s 0 -t double -s 0"
         _PNL3="-t double -s 0 -t double -s 0 -t double -s 0 -t double -s 0"
	     ;;
      # Bottom Menu - Blue Theme
      4) _COLOR="BLUE"
	     _IMAGE="oC8iorz2BlyAeEQi.jpg"
		 _THEME="Orchis-Dark"
    	 _ICON="Boston"
         _TYPE="Bottom"
         _MENU="menu_05.png"
         _PNL1="-t double -s 0.022667 -t double -s 0.210541 -t double -s 0.453333 -t double -s 0.647651"
         _PNL3="-t double -s 0 -t double -s 0 -t double -s 0 -t double -s 0"
	     ;;
   esac

   # Set the Icons & Themes for XFCE
   Set "xsettings" "/Net/ThemeName" "${_THEME}"
   Set "xsettings" "/Net/IconThemeName" "${_ICON}"
               
   # Set Numlock off
   Set "keyboards" "/Default/Numlock" "false"
               
   # Set Panel Background
   Set "xfce4-panel" "/panels/panel-1/background-style" "1"
   Set "xfce4-panel" "/panels/panel-1/background-rgba" "${_PNL1}"
   if [ ! -z ${_PNL3} ]; then
      Set "xfce4-panel" "xfce4-panel" "/panels/panel-3/background-style" "1"
      Set "xfce4-panel" "/panels/panel-3/background-rgba" "${_PNL3}"
   fi

   # Set Background Image
   CAT="xfce4-desktop"
   BACK="/usr/share/backgrounds/${_IMAGE}"

   # MONITOR 0
   PARAM="/backdrop/screen0/monitor0/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor0/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor0/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor0/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"

   # MONITOR 1
   PARAM="/backdrop/screen0/monitor1/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor1/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor1/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitor1/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"

   # MONITORdHDMI-0
   PARAM="/backdrop/screen0/monitorHDMI-0/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-0/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-0/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-0/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"

   # MONITORHDMI-1
   PARAM="/backdrop/screen0/monitorHDMI-1/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-1/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-1/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorHDMI-1/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"

   # MONITORVIRTUAL-0
   PARAM="/backdrop/screen0/monitorVirtual-0/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-0/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-0/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-0/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"

   # MONITORVIRTUAL-1
   PARAM="/backdrop/screen0/monitorVirtual-1/image-path"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-1/workspace0/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-1/workspace1/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   PARAM="/backdrop/screen0/monitorVirtual-1/workspace2/last-image"
   Set "${CAT}" "${PARAM}" "${BACK}"
   
   # Change the Menu Icon
   _task-begin "Change Whiskermenu Icon"
   _run "cd ${HDIR}/.config/xfce4/"
   CAT=$(grep -rl 'button-icon=' | grep -v 'show-button') >/dev/null 2>&1
   for file in ${CAT}; do
      if [ -f "$file" ]; then
         PARAM=$(grep -h 'button-icon=' ${file} | grep -v 'show-button' | cut -d'=' -f2) >/dev/null 2>&1
         TMP="sed -i 's#${PARAM}#/usr/share/icons/start/${_MENU}#g' ${file}"
         _log-msg "Running ${TMP}"
         _run "${TMP}"
      fi
   done
   _task-end
}

function _main_menu {
   #=============================
   # Choose Desktop Layout
   #=============================
   printf "\n\n  ${LPURPLE}      DESKTOP LAYOUT\n"
   printf "  ${LGREEN}+----------------------------------------+\n"
   printf "  |                                        |\n"
   printf "  |   1) Top Menu Bar - Yellow Theme       |\n"
   printf "  |   2) Top Menu Bar - Blue Theme         |\n"
   printf "  |   3) Bottom Menu Bar - Yellow Theme    |\n"
   printf "  |   4) Bottom Menu Bar - Blue Theme      |\n"
   printf "  |  ------------------------------------  |\n"
   printf "  |  99) Quit                              |\n"
   printf "  |                                        |\n"
   printf "  +----------------------------------------+${RESTORE}\n\n\n"
   while [[ "123499" != *${LAY}* ]]
   do
      _Ask " ${OVERWRITE}Choose the Desktop Layout (1-4,99)" "1" && LAY=${REPLY}
   done
}



if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
_run "touch ${LOG}"
clear
while [[ ${LAY^^} != "99" ]]
do
   _main_menu
   case ${LAY^^} in
      1|2|3|4) Setup_XFCE ;;
      99) break ;;
   esac
   LAY="777"
done