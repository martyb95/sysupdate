#!/bin/sh

# Making sure you have unarchiver

sudo apt install unzip wget 

# Retrieve printer tar.gz file 
cd ~/Downloads/
wget "https://download.brother.com/welcome/dlf006893/linux-brprinter-installer-2.2.3-1.gz"
gunzip linux-brprinter-installer-*.*.*-*.gz
sudo bash linux-brprinter-installer-2.2.3-1 dcpl2550dw

# Brother DCPL 2550dw
# printer - https://download.brother.com/welcome/dlf103577/dcpl2550dwpdrv-4.0.0-1.i386.deb
# scanner -https://download.brother.com/welcome/dlf105200/brscan4-0.4.11-1.amd64.deb
# Linux Printer Driver - https://download.brother.com/welcome/dlf006893/linux-brprinter-installer-2.2.3-1.gz