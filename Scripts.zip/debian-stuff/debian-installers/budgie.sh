#!/bin/bash
# Copyright 2023 
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


# Default packages are for the configuration and corresponding .config folders
# Install packages after installing base Debian with no GUI

echo
echo "****************************************************"
echo "****  RECOMMENDATION TO ONLY USE IF YOU ARE ON  ****"
echo "****      DEBIAN BOOKWORM MINIMAL INSTALL       ****"
echo
echo "This script is intended for Debian Bookworm Minimal Install"
read -p "Do you want to proceed? (yes/no) " yn

case $yn in 
	yes ) echo ok, we will proceed;;
	no ) echo exiting...;
		exit;;
	* ) echo invalid response;
		exit 1;;
esac

ScriptDir=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

echo
echo
echo "***************************************************"
echo "****  Adding Debian unstable/sid to apt list   ****"
echo
echo
sudo echo 'deb http://deb.debian.org/debian/ unstable main non-free contrib' | sudo tee -a /etc/apt/sources.list
echo
echo "********************************************"
echo "****   Adding Preferences to Apt List   ****"
echo
echo

echo "***********************************************"
echo "****  Add Latest Kernel from Debian Trixie ****"
echo
sudo apt update -yy && sudo apt upgrade -yy
echo
echo
echo "***************************************"
echo "****   Remove Old Debian Kernel    ****"
echo
sudo apt autoremove -yy
echo
echo
echo "********************************************************"
echo "****  Installing Required packages from Debian Stable   ****"
echo
sudo apt install -yy neofetch htop jq curl wget
echo
echo
echo "************************************************"
echo "****  Installing Tools from Debian Stable   ****"
echo
sudo apt install dialog mtools dosfstools acpi acpid timeshift -yy
sudo systemctl enable acpid
echo
echo
echo "******************************************************"
echo "**** Installing GVFS-Backends from Debian stable  ****"
echo
sudo apt install avahi-daemon gvfs-backends -yy
sudo systemctl enable avahi-daemon
sudo apt autoremove -yy
echo
echo
echo "******************************************************"
echo "**** Installing Sound Drivers from Debian stable  ****"
echo
sudo apt install -y alsa-utils volumeicon-alsa
echo
echo
echo "********************************************"
echo "****  Installing CUPS from Debian Sid   ****"
echo
sudo apt install cups simple-scan bluez blueman -yy
sudo systemctl enable cups
sudo systemctl enable bluetooth
echo
echo
# Create folders in user directory (eg. Documents,Downloads,etc.)
xdg-user-dirs-update
echo
echo
echo "************************************************************************"
echo "****  Installing Compression, Gedit and OpenVPN Tools from Debian   ****"
echo
# Packages needed after installation
sudo apt install unzip file-roller gedit -yy
echo
echo
echo "************************************************"
echo "****  Installing Fonts from Debian Stable   ****"
echo
# Install fonts
sudo apt install fonts-font-awesome fonts-recommended fonts-ubuntu fonts-liberation2 fonts-liberation fonts-terminus -yy
echo
echo "****  Installing Nerdfonts from Github   ****"
echo
# Install Nerd Fonts
source ${ScriptDir}/nerdfonts.sh
echo
echo
echo "*******************************************"
echo "****     Installing Google Chrome      ****"
echo
# Browser Installation (eg. chromium)
sudo apt install google-chrome-stable -yy
echo
echo
echo "******************************************************"
echo "****  Installing Budgie Desktop from Debian Sid   ****"
echo
sudo apt install budgie-desktop budgie-indicator-applet lightdm gnome-control-center -yy
echo
echo
echo "********************************"
echo "****   Autoremove command   ****"
sudo apt autoremove -yy
echo
printf "\e[1;32mDone! you can now reboot.\e[0m\n"


