#! /bin/bash

#========================================================
#
#  How to run this script
#
#  sudo ./setup_gdm_themes.sh <THEME NAME>
#
#  THEME NAMES = [tela|vimix|stylish|whitesur]
#
#========================================================

#========================================================
#   Pre-start Application Checks
#========================================================
# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then printf "\n\n${LRED}*************** Please run as root ***************${RESTORE}\n\n\n\n"; exit 1; fi


# Install SLIM if not already installed
if [ $(dpkg-query -W -f='ok installed' slim 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
  apt install -y slim
fi

git clone https://github.com/adi1090x/slim_themes
# copy themes to /usr/share/slim/themes
# edit and set current_theme line in /etc/slim.conf to current_theme greeny or workspace