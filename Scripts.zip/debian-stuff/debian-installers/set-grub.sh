#! /bin/bash

#========================================================
#
#  How to run this script
#
#  sudo ./set-grub.sh <THEME NAME>
#
#  THEME NAMES = [tela|vimix|stylish|whitesur]
#
#========================================================

#========================================================
#   Pre-start Application Checks
#========================================================
# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then printf "\n\n${LRED}*************** Please run as root ***************${RESTORE}\n\n\n\n"; exit 1; fi

_THEME=${1}
if [[ -z ${_THEME} ]]; then _THEME="vimix"

# Download and Install GRUB Themes 
git clone https://github.com/vinceliuice/grub2-themes
cd grub2-themes
./install.sh -b -t ${_THEME}
rm -rf ./grub2-themes

