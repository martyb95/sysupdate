#! /bin/bash

#========================================================
#
#  How to run this script
#
#  sudo ./snapper.sh 
#
#========================================================

#========================================================
#   Pre-start Application Checks
#========================================================
# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then printf "\n\n${LRED}*************** Please run as root ***************${RESTORE}\n\n\n\n"; exit 1; fi


apt install -y snapper inotify-tools git make
if [[ ${?} == 0 ]]; then
  umount /.snapshots
  rm -rf /.snapshots
  if [[ ${?} == 0 ]]; then
    snapper -c root create-config /
    if [[ ${?} == 0 ]]; then
	  mount -av
	  if [[ ${?} == 0 ]]; then
	    systemctl snapper-boot.timer
        snapper -c root set-config 'ALLOW_GROUPS=sudo'
        snapper -c root set-config 'SYNC_ACL=yes'
		snapper -c root set-config 'TIMELINE_CREATE=no'
		snapper -c root set-config 'TIMELINE_LIMIT_HOURLY=5'
		snapper -c root set-config 'TIMELINE_LIMIT_DAILY=7'
		snapper -c root set-config 'TIMELINE_LIMIT_WEEKLY=0'
		snapper -c root set-config 'TIMELINE_LIMIT_MONTHLY=0'
		snapper -c root set-config 'TIMELINE_LIMIT_YEARLY=0'
		
		snapper -c root create --read-write --description "1st Snapshot"
	  fi
	fi
  fi
  
  #Configure GRUB-BTRFS
  git clone https://github.com/Antynea/grub-btrfs.git
  cd grub-btrfs
  make install
  if [[ ${?} == 0 ]]; then
    systemctl start grub-btrfsd
	systemctl enable grub-btrfsd
	
	cd ..
	rm -rf grub-btrfs
  fi
fi



