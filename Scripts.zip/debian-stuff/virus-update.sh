#! /usr/bin/bash

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then printf "\n\n*************** Please run as root ***************\n\n\n"; exit 1; fi

#apt-get update
#apt upgrade -y

printf "OutDIR=${OutDIR}\nOutFILE=${OutFILE}\n\n"

if [ ! -d $OutDIR ]; then 
  mkdir $OutDIR
  touch $OutFILE
  chmod 777 $OutFILE
fi

systemctl stop clamav-freshclam
freshclam
systemctl start clamav-freshclam
