#!/bin/bash
SELECT=""
ESC="\033"
CSI="${ESC}["
SCRN_TOP=1

#=========================================================
#      Color Codes
#=========================================================
BRIGHT=60
FG_BLACK=30
FG_RED=31
FG_GREEN=32
FG_YELLOW=33
FG_BLUE=34
FG_MAGENTA=35
FG_CYAN=36
FG_WHITE=37

BG_BLACK=40
BG_RED=41
BG_GREEN=42
BG_YELLOW=43
BG_BLUE=44
BG_MAGENTA=45
BG_CYAN=46
BG_WHITE=47

SGL_TL="\u250C"
SGL_TR="\u2510"
SGL_BL="\u2514"
SGL_BR="\u2518"
SGL_HOR="\u2500"
SGL_VER="\u2502"
SGL_TITL="\u2524"
SGL_TITR="\u251C"

DBL_TL="\u2554"
DBL_TR="\u2557"
DBL_BL="\u255A"
DBL_BR="\u255D"
DBL_HOR="\u2550"
DBL_VER="\u2551"
DBL_TITL="\u2561"
DBL_TITR="\u255E"

TOP_LEFT="$SGL_TL"
TOP_RIGHT="$SGL_TR"
BOTTOM_LEFT="$SGL_BL"
BOTTOM_RIGHT="$SGL_BR"
HORIZONTAL="$SGL_HOR"
VERTICAL="$SGL_VER"
TITLE_LEFT="$SGL_TITL"
TITLE_RIGHT="$SGL_TITR"

KEY_DWN="033[B"
KEY_UP="033[A"
KEY_ENT="ENTER"
KEY_RIGHT="033[C"
KEY_LEFT="033[D"
KEY_HOME="033[H"
KEY_END="033[F"
KEY_F1="033OP"
KEY_F2="033OQ"
KEY_F3="033OR"
KEY_F4="033OS"
KEY_F5="033[15"
KEY_F6="033[17"
KEY_F7="033[18"
KEY_F8="033[19"
KEY_F9="033[20"

function ctrl_z {
  tput cnorm   # normal cursor
  POS="14;1"
  goto
  exit 1
}

#========================================================
#    Color Functions
#========================================================
function setColor {
  local CLR="$1"
  local FG=$(printf "$CLR" | cut -d';' -f1)
  local BG=$(printf "$CLR" | cut -d';' -f2)
  printf "${CSI}${FG};${BG}m"
}

function resetColor {
  printf "${CSI}0m"
}

#========================================================
#    Keyboard Functions
#========================================================
function keyPress {
   local KEY=""
   local VAL=""
   local BRK=2
   local kp=
   
   while read -d '' -sn1 kp
   do
     KEY="$KEY$kp"
     if [[ ${#KEY} == 0 ]]; then BRK=-1; VAL="ENTER"; break; fi
     if [[ ${KEY:1} == "[1" ]]; then BRK=3; fi
     if [[ ${KEY:1} == "[2" ]]; then BRK=3; fi
     if [[ ${#KEY} -gt $BRK ]]; then VAL=$(printf "$KEY" | od -c); break; fi
   done
   
   if [[ "$VAL" != "ENTER" ]]; then
     VAL=${VAL:8}
     VAL=${VAL::-8}
     VAL=$(printf "$VAL" | sed 's/   //g')
     read -t 0.05 -n 10 discard
   fi
   printf "$VAL"
}
 
#========================================================
#    Cursor Positioning Functions
#========================================================
function cur_up {
  if [[ ${1} != "" ]]; then
     printf "${CSI}${1}A"
  else
    printf "${CSI}1A"
  fi
}

function cur_right {
  if [[ ${1} != "" ]]; then
     printf "${CSI}${1}C"
  else
    printf "${CSI}1C"
  fi
}

function cur_left {
  if [[ ${1} != "" ]]; then
     printf "${CSI}${1}D"
  else
    printf "${CSI}1D"
  fi
}

function line_up {
  if [[ ${1} != "" ]]; then
     printf "${CSI}${1}F"
  else
    printf "${CSI}1F"
  fi
}

function line_down {
  if [[ ${1} != "" ]]; then
     printf "${CSI}${1}E"
  else
    printf "${CSI}1E"
  fi
}
  
function goto {
  local ROW="$1"
  local COL="$2"
  if [[ -z ${ROW} ]]; then ROW="1"; fi
  if [[ -z ${COL} ]]; then COL="1"; fi
  printf "${CSI}${ROW};${COL}H"
}

#========================================================
#   Screen Functions
#========================================================
function clr_screen {
  # Clear Screen Types
  # 0/Empty = Clear from cursor to end of screen
  # 1 = Clear from cursor to beginning of the screen
  # 2 = Clear entire screen (and moves cursor to upper left)
  local TYP=${1}
  if [[ -z ${1} ]]; then TYP="0"; fi
  printf "${CSI}${TYP}J"
}

function clr_line {
  # Clear Screen Types
  # 0/Empty = Clear from cursor to the end of the line
  # 1 = Clear from cursor to beginning of the line
  # 2 = Clear entire line. Cursor position does not change.
  local TYP=${1}
  if [[ ${1} == "" ]]; then TYP="2"; fi
  printf "${CSI}${TYP}K"
}

#========================================================
#    Box Drawing Functions
#========================================================
function setBoxStyle {
  case $1 in
      $WIN_TYPE_NONE)  TOP_LEFT=" "
                       TOP_RIGHT=" "
                       BOTTOM_LEFT=" "
                       BOTTOM_RIGHT=" "
                       HORIZONTAL=" "
                       VERTICAL=" "
                       TITLE_LEFT=" "
                       TITLE_RIGHT=" "
                       ;;
    $WIN_TYPE_SINGLE)  TOP_LEFT="$SGL_TL"
                       TOP_RIGHT="$SGL_TR"
                       BOTTOM_LEFT="$SGL_BL"
                       BOTTOM_RIGHT="$SGL_BR"
                       HORIZONTAL="$SGL_HOR"
                       VERTICAL="$SGL_VER"
                       TITLE_LEFT="$SGL_TITL"
                       TITLE_RIGHT="$SGL_TITR" 
	               ;;
    $WIN_TYPE_DOUBLE)  TOP_LEFT="$DBL_TL"
                       TOP_RIGHT="$DBL_TR"
                       BOTTOM_LEFT="$DBL_BL"
                       BOTTOM_RIGHT="$DBL_BR"
                       HORIZONTAL="$DBL_HOR"
                       VERTICAL="$DBL_VER"
                       TITLE_LEFT="$DBL_TITL"
                       TITLE_RIGHT="$DBL_TITR"
	               ;;
  esac
}

function box_top {
  declare -n box="$1"

  setColor "${box[color]}"  # set the color for the box
  printf "${TOP_LEFT}"
  if [[ ! -z "${box[title]}" ]]; then
     printf "${HORIZONTAL}${TITLE_LEFT} %-s ${TITLE_RIGHT}" "${box[title]}"
     printf "${HORIZONTAL}%.0s" $(seq 1 $((${box[width]}-(${#box[title]}+7))))
  else
     printf "${HORIZONTAL}%.0s" $(seq 1 $((${box[width]}-2)))
  fi
  printf "${TOP_RIGHT}"
  resetColor        # restore color
}

function box_mid {
  local WID="$1"
  setColor "$2"
  printf "${VERTICAL}"
  printf " %.0s" $(seq 1 $WID)
  printf "${VERTICAL}"
  resetColor
}

function box_bot {
  local WID="$1"
  setColor "$2"
  printf "${BOTTOM_LEFT}"
  printf "${HORIZONTAL}%.0s" $(seq 1 $WID)
  printf "${BOTTOM_RIGHT}"
  resetColor
}


#========================================================
#    Button Functions
#========================================================
function newButton {
  declare -A but
  but[row]=0
  but[column]=0
  but[height]=0
  but[width]=0
  but[color]="$FG_WHITE;$BG_BLACK"
  but[hilite]="$FG_BLACK;$BG_WHITE"
  but[label]="LABEL"
  but[style]=$WIN_TYPE_SINGLE
  but[shadow]=false
  but[pressed]=false
  echo "${but[@]@K}"  # Expand associative array as string.
}

function drawButton {
  declare -n but1="$1"
  declare -A wind="($(newWin))"

  #calculate the height and width
  if [[ ${#but1[label]} == 0 ]]; then
     but1[width]=$((${#but1[label]}+9))
  else
     but1[width]=$((${#but1[label]}+4))
  fi
  but1[height]=3

  # Copy values from menu to window
  for key in "${!wind[@]}"; do
    wind[$key]=${but1[$key]}
  done
  
  # Draw the Window
  drawWindow wind
  
  # Display Label
  goto "$((${but1[row]}+1))" "$((${but1[column]}+2))"
  setColor "${but1[color]}"
  printf "${but1[label]}"
  resetColor
  unset wind
}

function processButton {
  declare -n btn="$1"

  IFS="~"
  local KEY=""
  local TMEN="${btn[menu]}"
  local VAL=${TMEN//[^~]}
  local MAX=$((${#VAL}+1))
  unset IFS
  VAL=""
  tput civis  # invisible cursor
  while [[ $KEY != $KEY_F5 ]]; do
    KEY=$(keyPress)
    case $KEY in
	   $KEY_ENT) goto "5" "50"
				 printf "Pressed ENTER - Option: ${btn[index]}, "
				 printf "$(printf "${btn[index]}" | cut -d';' -f3)            "
				 VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
				 case $(printf "$VAL" | cut -d';' -f2) in
				    "QUIT") KEY=$KEY_F5 ;;
					"BACK") ;;
					"FUNC") VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
					        eval "$(printf "$VAL" | cut -d';' -f3)" 
							;;
				 esac
				 ;;
        $KEY_UP) if [[ ${btn[index]} -gt 1 ]]; then
				    setColor "${btn[color]}"
                    goto "$((${btn[row]}+${btn[index]}+1))" "$((${btn[column]}+3))"
	                VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
				    printf "$(printf "$VAL" | cut -d';' -f1)"
				    btn[index]=$((${btn[index]}-1))
				    setColor "${btn[hilite]}"
                    goto "$((${btn[row]}+${btn[index]}+1))" "$((${btn[column]}+3))"
	                VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
				    printf "$(printf "$VAL" | cut -d';' -f1)"
                    resetColor
                 fi
                 ;;
       $KEY_DWN) if [[ ${btn[index]} -lt $MAX ]]; then
				    setColor "${btn[color]}"
                    goto "$((${btn[row]}+${btn[index]}+1))" "$((${btn[column]}+3))"
	                VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
				    printf "$(printf "$VAL" | cut -d';' -f1)"
				    btn[index]=$((${btn[index]}+1))
					setColor "${btn[hilite]}"
					goto "$((${btn[row]}+${btn[index]}+1))" "$((${btn[column]}+3))"
	                VAL=$(printf "$TMEN" | cut -d'~' -f${btn[index]})
				    printf "$(printf "$VAL" | cut -d';' -f1)"	                
                    resetColor
                 fi
	  ;;
    esac
  done
  tput cnorm   # normal cursor
  resetColor
}

#========================================================
#    Menu Functions
#========================================================
function newMenu {
  declare -A men
  men[row]=0
  men[column]=0
  men[height]=0
  men[width]=0
  men[color]="$FG_WHITE;$BG_BLACK"
  men[hilite]="$FG_BLACK;$BG_WHITE"
  men[title]="TITLE"
  men[style]=$WIN_TYPE_SINGLE
  men[menu]=""
  men[shadow]=false
  men[index]=0
  echo "${men[@]@K}"  # Expand associative array as string.
}

function drawMenu {
  declare -n men1="$1"
  declare -A wind="($(newWin))"

  #calculate the height and width
  local WID=0
  local HT=0
  local VAL=""
  
  IFS="~"
  for item in ${men1[menu]}; do
    VAL="$(printf "$item" | cut -d';' -f1)"
    if [[ ${#VAL} -gt $WID ]]; then WID=${#VAL}; fi
	let "HT++"
  done
  unset IFS
  if [[ $(($WID+6)) -gt ${men1[width]} ]]; then men1[width]=$(($WID+6)); fi
  if [[ $(($HT+4)) -gt ${men1[height]} ]]; then men1[height]=$(($HT+4)); fi

  
  # Copy values from menu to window
  for key in "${!wind[@]}"; do
    wind[$key]=${men1[$key]}
  done
  
  # Draw the Window
  drawWindow wind
  
  # Display Menu
  IFS="~"
  men1[index]=0
  for item in ${men1[menu]}
  do
  	if [[ ${men1[index]} == 0 ]]; then 
	   setColor "${men1[hilite]}"
	else
	   setColor "${men1[color]}"
	fi
    goto "$((${men1[row]}+${men1[index]}+2))" "$((${men1[column]}+3))"
	
    printf "$(printf "$item" | cut -d';' -f1)"
	men1[index]=$((${men1[index]}+1))
  done
  men1[index]=1
  unset IFS
  resetColor
  unset wind
  tput civis  # invisible cursor
}

function processMenu {
  declare -n mnu="$1"
  #local mnu="$1"

  IFS="~"
  local KEY=""
  local TMEN="${mnu[menu]}"
  local VAL=${TMEN//[^~]}
  local MAX=$((${#VAL}+1))
  unset IFS
  VAL=""
  tput civis  # invisible cursor

  while [[ $KEY != $KEY_F5 ]]; do
    KEY=$(keyPress)
    case $KEY in
	     $KEY_ENT)
               #printf "Debug 03\n  mnu=($mnu)\n  TMEN=($TMEN)\n  MAX=$MAX\n  Index=${mnu[index]}\n"
				       VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
               #printf "Debug 04\n"
				       case $(printf "$VAL" | cut -d';' -f2) in
				           "QUIT") goto "$(($SCRN_TOP+$MAX+4))" "1"
                           KEY=$KEY_F5 
                           ;;
					         "BACK") ;;
					         "FUNC") VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
					                 SELECT="$(printf "$VAL" | cut -d';' -f1)"
                           goto "$(($SCRN_TOP+$MAX+4))" "1"
                           eval "$(printf "$VAL" | cut -d';' -f3)" 
							             ;;
				       esac
				       ;;
        $KEY_UP) if [[ ${mnu[index]} -gt 1 ]]; then
				            setColor "${mnu[color]}"
                    goto "$((${mnu[row]}+${mnu[index]}+1))" "$((${mnu[column]}+3))"
	                  VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
				            printf "$(printf "$VAL" | cut -d';' -f1)"
				            mnu[index]=$((${mnu[index]}-1))
				            setColor "${mnu[hilite]}"
                    goto "$((${mnu[row]}+${mnu[index]}+1))" "$((${mnu[column]}+3))"
	                  VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
				            printf "$(printf "$VAL" | cut -d';' -f1)"
                    resetColor
                 fi
                 ;;
       $KEY_DWN) if [[ ${mnu[index]} -lt $MAX ]]; then
				            setColor "${mnu[color]}"
                    goto "$((${mnu[row]}+${mnu[index]}+1))" "$((${mnu[column]}+3))"
	                  VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
				            printf "$(printf "$VAL" | cut -d';' -f1)"
				            mnu[index]=$((${mnu[index]}+1))
					          setColor "${mnu[hilite]}"
					          goto "$((${mnu[row]}+${mnu[index]}+1))" "$((${mnu[column]}+3))"
	                  VAL=$(printf "$TMEN" | cut -d'~' -f${mnu[index]})
				            printf "$(printf "$VAL" | cut -d';' -f1)"	                
                    resetColor
                 fi
	               ;;
    esac
  done
  tput cnorm   # normal cursor
  resetColor
}


#========================================================
#    Window Functions
#========================================================
WIN_TYPE_NONE=0
WIN_TYPE_SINGLE=1
WIN_TYPE_DOUBLE=2

function newWin {
  declare -A win
  win[row]=0
  win[column]=0
  win[height]=0
  win[width]=0
  win[color]="$FG_WHITE;$BG_BLACK"
  win[title]=""
  win[style]=$WIN_TYPE_SINGLE
  win[shadow]=false
  echo "${win[@]@K}"  # Expand associative array as string.
}

function drawWindow {
  declare -n winobj="$1"
  
  if [[ ${winobj[width]} -lt $((${#winobj[title]}+8)) ]]; then 
     winobj[width]=$((${#winobj[title]}+8));
  fi
  
  setBoxStyle "${wind[style]}"
  goto "${winobj[row]}" "${winobj[column]}"
  box_top winobj
  local IDX=1
  local SHD1="\u2588"
  local SHD2="\u2580"
  while [[ ${IDX} -lt $((${winobj[height]}-1)) ]]; do
    goto "$((${winobj[row]}+$IDX))" "${winobj[column]}"
	box_mid "$((${winobj[width]}- 2))" "${winobj[color]}"
	if [[ ${winobj[shadow]} == true ]]; then
	   setColor "90;40"
	   printf "$SHD1"
	   setColor "${winobj[color]}"
    fi
	let "IDX++"
  done
  goto "$((${winobj[row]}+${winobj[height]}-1))" "${winobj[column]}"  
  box_bot "$((${winobj[width]}- 2))" "${winobj[color]}"
  if [[ ${winobj[shadow]} == true ]]; then
     setColor "90;40"
     printf "$SHD1"
     goto "$((${winobj[row]}+${winobj[height]}))" "$((${winobj[column]}+1))"
     printf "$SHD2%.0s" $(seq 1 ${winobj[width]})
     setColor "${winobj[color]}"
  fi
}
