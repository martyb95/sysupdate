#=========================================================
#      Global Variables
#=========================================================
ADDList=("")        # Package add list
DELList=("")        # Package del list
APPList=("")        # Prompts for package install
FONTList=("")       # Fonts to add list
FLTAList=("")       # Flatpak add list
FLTDList=("")       # Flatpak del list

#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'

LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'

BOLD='\033[1m'
DIM='\033[2m'
UNDERLINE='\033[4m'
BLINK='\033[5m'
OVERWRITE='\e[1A\e[K'

#=========================================================
#      Functions
#=========================================================
function _exists {
  local VAL=0
  
  if [ ${__OS^^} == "ALPINE" ]; then
     VAL=$(apk list ${1} 2>/dev/null | grep -c "${1}")
  else
     VAL=$(dpkg -s ${1} 2>/dev/null | grep -c "${1}")
  fi
  printf "%u" ${VAL}
}

function _init_lists {
   FLTAList+=("")
   FLTDList+=("")   #need to supply flatpak package id

   ADDList+=("fileroller" "gnome-software-plugin-flatpak" "htop" "neofetch" "numlockx"
             "p7zip-rar" "p7zip-full" "simple-scan" "volumeicon-alsa")
			 
   if [ ${__OS^^} == "ELEMENTARY" ]; then
      ADDList+=("software-properties-common")
	  APPList=("=== ELEMENTARY Specific Tools ===||" "Pantheon System Tweaks|pantheon-tweaks|Y")
   fi

   FONTList=("CascadiaCode" "DejaVuSansMono" "FiraCode" "Go-Mono" "Hack" "Inconsolata" "Iosevka" "JetBrainsMono" 
             "LiberationMono" "Mononoki" "Noto" "RobotoMono" "SourceCodePro" "Terminus" "UbuntuMono" )

   DELList=("advert-block-antix" "aisleriot" "appcenter" "aspell" "asunder" "bash-config" "calamares" "catfish" 
            "celluloid" "cheese" "clementine" "conky*" "drawing" "evolution-data-server" "exaile" "featherpad" 
			"firefox*" "five-or-more" "foliate" "four-in-a-row" "gmtp" "gnome-2048" "gnome-chess" "gnome-contacts"
			"gnome-games" "gnome-klotski" "gnome-mahjongg" "gnome-mines" "gnome-music" "gnome-nibbles" "gnome-robots" 
			"gnome-sound-recorder" "gnome-software-plug-snap" "gnome-sudoku" "gnome-taquin" "gnome-tetravex" 
			"gnome-text-editor" "gnome-video-effects" "gnome-weather" "gsmartcontrol" "hexchat" "hexedit" "hitori" 
			"hp-fab" "hypnotix" "imagemagick*" "info" "io.elementary.code" "io.elementary.feedback" "io.elementary.mail" 
			"io.elementary.music" "io.elementary.onboarding" "io.elementary.screenshot" "io.elementary.tasks" 
			"io.elementary.videos" "lbreakout2" "libreoffice*" "liferea" "lightsoff" "luckybackup*" "magnus" "maya-calendar" 
			"mc" "mc-data" "mousepad" "mx-conky" "mx-conky-data" "mx-docs" "mx-faq" "mx-manual" "mx-remaster" "mx-remastercc" 
			"mx-tour" "mx-viewer" "mx-welcome" "mx-welcome-data" "onboard*" "openvpn" "pantheon-photos" "parcellite" 
			"pdfarranger" "peg-e" "pidgin" "pix" "redshift" "rhythmbox*" "riseup-vpn" "radiostation" "ristretto" "qpdfview*" 
			"quadrapassel" "shotwell" "snapd" "sparky-aptus-upgrade-*" "sparky-about" "sparky-welcome*" "stawberry" 
			"swell-foop" "switchboard-plug-parental-controls" "tali" "thunderbird*" "transmission*" "uget" "vokoscreen-ng" 
			"warpinator" "xfce4-notes" "xterm" "yad" "zutty")

   APPList+=("=== Choose System Tools ===||"
            "Clam Anti Virus|clamav|N"
            "Disk Utility|gnome-disk-utility|Y" 
            "Etcher|__ETCH|Y" 
			"Flameshot Screenshot Utility|flameshot|Y"
			"Gnome Software Manager|gnome-software|Y"
			"gParted Disk Partioning|gparted|Y"
			"Lucky Backup|luckybackup|N"
			"LX Terminal|lxterminal|Y"
			"Neofetch|neofetch|Y"
			"Penguins Eggs|__EGGS|N"
			"Putty SSH Utility|putty|N"
			"Stacer|stacer|Y"
			"Synaptic Package Manager|synaptic|N"
			"Timeshift System Snapshot|timeshift|Y"
			"uLauncher|__ULAUN|Y"
			"WINE|winehq-stable|N"
			"Wine Tricks|winetricks|N"
			"=== Choose Virtualization Tools ===||"
			"DistroBox|distrobox|N"
			"Gnome Boxes|gnome-boxes|Y"
			"Vir-Manager|virt-manager|N"
			"=== Choose Browser(s) ===||"
			"Chromium|chromium|Y"
			"FireFox|firefox|N"
			"Google Chrome|__GOOG|N"
			"Thorium|__THOR|N"
			"=== Choose Office Tools ===||"
			"Abiword Word Processor|abiword|Y"
			"Geary Email Client|geary|N"
			"Gnome Calendar|gnome-calendar|Y"
			"Gnome Calculator|gnome-calculator|Y"
			"gNumeric Spreadsheet|gnumeric|Y"
			"Libre Office|libreoffice|N"
			"Mailspring Email Client|__MAIL|N"
			"=== Choose Applications ===||"
			"Calibre eBook Manager|calibre|N"
			"Cheese Camera Utility|cheese|N"
			"gThumb Image Viewer|gthumb|Y"
			"Kodi Media Center|kodi|N"
			"Notepad Utility|notepadqq|Y"
			"Spotify Client|spotify-client|N"
			"VLC Media Player|vlc browser-plugin-vlc|Y")

   if [ ${__OS^^} == "ALPINE" ]; then
      ADDList+=("gnome-software-plugin-apk" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin")
	  
      FONTList=("font-cascadia-code-nerd" "font-dejavu-sans-mono-nerd" "font-fira-code-nerd" "font-go-mono-nerd"
                "font-hack-nerd" "font-inconsolata-nerd" "font-iosevka" "font-jetbrains-mono-nerd" 
                "font-liberation-mono-nerd" "font-mononoki-nerd" "font-noto" "font-roboto-mono" 
			    "font-source-code-pro-nerd" "font-terminus-nerd" "font-ubuntu-mono-nerd" )
				
      APPList+=("=== Choose System Tools ===||"
                "Clam Anti Virus|clamav|N"
                "Disk Utility|gnome-disk-utility|Y" 
                "Gnome Software Manager|gnome-software|Y"
				"gParted Disk Partioning|gparted|Y"
				"LX Terminal|lxterminal|Y"
				"Neofetch|neofetch|Y"
				"Putty SSH Utility|putty|N"
				"WINE|wine|N"
				"=== Choose Virtualization Tools ===||"
				"DistroBox|distrobox|N"
				"Gnome Boxes|gnome-boxes|Y"
				"Vir-Manager|virt-manager|N"
				"=== Choose Browser(s) ===||"
				"Chromium|chromium|Y"
				"FireFox|firefox|N"
				"=== Choose Office Tools ===||"
				"Abiword Word Processor|abiword|Y"
				"Geary Email Client|geary|N"
				"Gnome Calendar|gnome-calendar|Y"
				"Gnome Calculator|gnome-calculator|Y"
				"gNumeric Spreadsheet|gnumeric|Y"
				"Libre Office|libreoffice|N"
				"=== Choose Applications ===||"
				"Cheese Camera Utility|cheese|N"
				"gThumb Image Viewer|gthumb|Y"
				"Kodi Media Center|kodi|N"
				"Mousepad Notepad Utility|mousepad|Y"
				"Spotify Client|spotify-qt|N"
				"VLC Media Player|vlc|Y")				
   fi
}

function _chooser {
   if [ ${#APPList[@]} -gt 0 ]; then
     for i in {0..999}; do
        if (( i == ${#APPList[@]} )); then break; fi
        IFS='|' read -ra arr <<< "${APPList[i]}"
        if [ ${#arr[@]} -gt 0 ]; then
          FLG="I"
          if [[ "${arr[0]}" =~ ^"===" ]]; then FLG="H"; fi
          if [[ "${arr[1]}" =~ ^"__" ]]; then FLG="D"; fi

          case ${FLG^^} in
            [I]*)
	       if (( $(_exists "${arr[1]}") == 0 )); then
                  _AskYN "Install ${arr[0]}${LGREEN} (y/n/r)" ${arr[2]^^}
	       else
                  _AskYN "Install $LRED${arr[0]}$RESTORE (y/n/r)" ${arr[2]^^}
               fi
               _PKG_List ${REPLY^^} ${arr[1]}
               ;;
            [D]*)
	       if (( $(_exists "${arr[1]}") == 0 )); then
                  _AskYN "Install ${arr[0]}${LGREEN} (y/n/r)" ${arr[2]^^}
               else
                  _AskYN "Install $LRED${arr[0]}$RESTORE (y/n/r)" ${arr[2]^^}
               fi
               if [ ${arr[1]^^} = "__THOR" ]; then __THOR=${REPLY}; fi
               if [ ${arr[1]^^} = "__GOOG" ]; then __GOOG=${REPLY}; fi
               if [ ${arr[1]^^} = "__ETCH" ]; then __ETCH=${REPLY}; fi
               if [ ${arr[1]^^} = "__ULAUN" ]; then __ULAUN=${REPLY}; fi
               if [ ${arr[1]^^} = "__MAIL" ]; then __MAIL=${REPLY}; fi
               if [ ${arr[1]^^} = "__EGGS" ]; then __EGGS=${REPLY}; fi
               ;;
            [H]*)
               printf "\n${LPURPLE}${arr[0]}${RESTORE}\n"
               ;;
          esac
        fi
     done
  fi
}

function _update_os {
   _task-begin "Update ${__OS^^} System"
   if [ ${__OS^^} == "ALPINE" ]; then
      _run "$APT $UPD"
      _run "$APT $UPG"
   else
      _run "$APT $UPD"
      _run "$APT $UPG"
      _run "$APT $DIST"
      _run "$APT $FULL"
      _run "$APT $REM"   
   fi
   _run "flatpak update -y"
   _task-end
}

function _add_os_dep {
  printf "\n${LPURPLE}=== Update System Dependencies ===${RESTORE}\n"
  local PList=("")
  if [ ${__OS^^} == "ALPINE" ]; then
     PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi" "bash" "bash-completion" "bluez"  
            "blueman" "cifs-utils" "cups" "curl" "dconf" "dbus-x11" "flatpak" "git" "gvfs" 
			"gvfs-fuse" "gvfs-smb" "gvfs-mtp" "gvfs-nfs" "jq" "nano" "sed" "sudo"
			"udisks2" "unzip" "wget")
  else
     PList=("7zip" "acpi" "acpid" "alsa-utils" "avahi-utils" "bash" "bash-completion" "bluez"  
            "blueman" "cifs-utils" "cups" "curl" "dconf-cli" "dbus-x11" "flatpak" "git" "gvfs" 
			"gvfs-backends" "jq" "nano" "preload" "sed" "sudo" "udisks2" "unzip" "wget" "zram-tools")
   fi
  _add_by_list ${PList[*]}
}

function _install_nerdfonts {
   if [ ! -f ${HDIR}/.local/share/fonts/.setup ]; then
      if [ ! -d ${HDIR}/.local/share/fonts ]; then _run "mkdir -p ${HDIR}/.local/share/fonts"; fi
      if [ ! -d ${HDIR}/tmp ]; then _run "mkdir ${HDIR}/tmp"; fi
      _run "cd ${HDIR}/tmp"
      RET=$(curl -sL https://api.github.com/repos/ryanoasis/nerd-fonts/releases/latest | jq -r ".tag_name")
      for font in ${FONTList[@]}
      do
         URL="https://github.com/ryanoasis/nerd-fonts/releases/download/${RET}/${font}.zip"
         _run "wget -q $URL"
         if [ -f $font.zip ]; then
		    _task-begin "Installing Nerd Font - $font"
            _run "unzip -o -q $font.zip -d ${HDIR}/.local/share/fonts/$font/"
	        _run "rm $font.zip"
			_task-end
         fi
     done
     _run "fc-cache"
     if [ -d ${HDIR}/tmp ]; then _run "rm -rf ${HDIR}/tmp"; fi
     _run "touch ${HDIR}/.local/share/fonts/.setup"
   fi
   _task-end
}

function _add_os_repos {
  printf "\n${LPURPLE}=== Install New Repositories ===${RESTORE}\n"
  if [[ "ELEMENTARY UBUNTU" == *${__OS^^}* ]]; then
     local RList=("ppa:philip.scott/pantheon-tweaks" "ppa:linrunner/tlp")
     _add_repo_by_list ${RList[*]}
	 _run "$APT $UPD"
     _run "$APT $UPG"
  fi
  
  #==================================
  # Add Flatpak
  #==================================
  _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"  
}

function _add_chrome_repo {
  _task-begin "Adding Google Chrome Repository"
  _run "curl -fSsL https://dl.google.com/linux/linux_signing_key.pub | sudo gpg --dearmor | sudo tee /usr/share/keyrings/google-chrome.gpg"
  _run "echo deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main | sudo tee /etc/apt/sources.list.d/google-chrome.list"
  _task-end
}

function _del_language {
  local PList=("hunspell-de-de-frami" "hunspell-de-at-frami" "hunspell-de-ch-frami"
               "hunspell-en-au" "hunspell-en-gb" "hunspell-en-za" "hunspell-es" "hunspell-fr-classical"
               "hunspell-fr" "hunspell-it" "hunspell-pt-br" "hunspell-pt-pt" "hunspell-ru" "hunspell-en-au")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused OS Language Packs ======================
  PList=("language-pack-bg" "language-pack-ca" "language-pack-cs" "language-pack-da"
         "language-pack-de" "language-pack-es" "language-pack-fr" "language-pack-hu"
         "anguage-pack-id" "language-pack-it" "language-pack-ja" "language-pack-ko"
         "language-pack-nb" "language-pack-nl" "language-pack-pl" "language-pack-pt"
         "language-pack-ru" "language-pack-sv" "language-pack-th" "language-pack-tr"
         "language-pack-uk" "language-pack-vi" "language-pack-zh-hans" "language-pack-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused GNOME Language Packs ======================
  PList=("language-pack-gnome-bg" "language-pack-gnome-ca" "language-pack-gnome-cs" "language-pack-gnome-da"
         "language-pack-gnome-de" "language-pack-gnome-es" "language-pack-gnome-fr" "language-pack-gnome-hu"
         "language-pack-gnome-id" "language-pack-gnome-it" "language-pack-gnome-ja" "language-pack-gnome-ko"
         "language-pack-gnome-nb" "language-pack-gnome-nl" "language-pack-gnome-pl" "language-pack-gnome-pt"
         "language-pack-gnome-ru" "language-pack-gnome-sv" "language-pack-gnome-th" "language-pack-gnome-tr"
         "language-pack-gnome-uk" "language-pack-gnome-vi" "language-pack-gnome-zh-hans" "language-pack-gnome-zh-hant")
  _del_by_list ${PList[*]}

  #=========== REMOVE Unused Language Packs ======================
  PList=("wbrazilian" "wbritish" "wbulgarian" "wcatalan" "wdanish" "wdutch" "wfrench" "wngerman" "wnorwegian" 
         "wogerman" "wpolish" "wportuguese" "wspanish" "wswedish" "wswiss" "wukrainian")
  _del_by_list ${PList[*]}
}

function _clean_os_build_tools {
  #================================ REMOVE Development Tools =========================================
  local PList=("cpp" "gcc" "g++" "make")
  _del_by_list ${PList[*]}
}

function _set_swappiness {
  #============================ Update Swap File Swappiness ===========================================
  _task-begin "Update Swap File Swappiness"
  _SWP=$(cat /etc/sysctl.conf | grep 'vm.swappiness' | cut -d "=" -f2)
  if [ -z ${_SWP} ]; then
    _run "echo 'vm.swappiness=10' | tee -a /etc/sysctl.conf"
  else
    if [ ! ${_SWP} == "10" ]; then
      _run "sed -i 's/vm.swappiness=${_SWP}/vm.swappiness=10/g'"
    fi
  fi
  _task-end
}

function _create_shortcuts {
  #============================ Create Desktop Shortcuts ===========================================
  _task-begin "Create Desktop Keyboard Shortcuts"
  _run "touch shortcut.dconf"
  printf "[custom0]\nbinding='<Primary><Alt>s'\ncommand='flameshot gui'\nname='flameshot gui'\n\n" > shortcut.dconf
  printf "[custom1]\nbinding='<Primary><Alt>b'\ncommand='balena-etcher'\nname='balena-etcher'\n\n" >> shortcut.dconf
  printf "[custom2]\nbinding='<Primary><Alt>m'\ncommand='google-maps'\nname='google-maps'\n\n" >> shortcut.dconf
  printf "[custom3]\ncommand=''\nname=''\n\n" >> shortcut.dconf
  printf "[custom4]\ncommand=''\nname=''\n\n" >> shortcut.dconf
  printf "[custom5]\ncommand=''\nname=''\n\n" >> shortcut.dconf
  printf "[custom6]\ncommand=''\nname=''\n\n" >> shortcut.dconf
  _run "dconf load /org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/ < shortcut.dconf"
  _run "rm shortcut.dconf"
  _task-end
}

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  _task-begin "Update ZRAM Swap Configuration"
  _run "echo -e 'ALGO=zstd' | tee -a /etc/default/zramswap"
  _run "echo -e 'PERCENT=35' | tee -a /etc/default/zramswap"
  _task-end
  _set_swappiness
  
}

function _clean_os {
  printf "\n\n${LPURPLE}=== Removing Language Packs ===${RESTORE}\n"
  _del_language
  
  printf "\n\n${LPURPLE}=== Removing Unrequired Development Tools ===${RESTORE}\n"
  _clean_os_build_tools
}

function _install_budgie {
  #============================ Install Budgie Desktop ============================================
  if [ ${__OS^^} != "ALPINE" ]; then
     printf "\n\n${LPURPLE}=== Install Budgie Desktop  ===${RESTORE}\n"
     local PList=("xorg" "budgie-desktop" "budgie-indicator-applet" "gnome-control-center" 
                  "lightdm" "lightdm-gtk-greeter-settings" "plank" "dialog" "lxterminal" 
		          "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
     _add_by_list ${PList[*]}
     _run "systemctl enable lightdm"
  fi
}

function _install_cinnamon {
  #============================ Install Cinnamon Desktop ============================================
  printf "\n\n${LPURPLE}=== Install Cinnamon Desktop  ===${RESTORE}\n"
  local PList=("")
  if [ ${__OS^^} == "ALPINE" ]; then
     PList=("xorg-server" "cinnamon-desktop" "gnome-control-center" "lightdm" "lightdm-gtk-greeter")
     _add_by_list ${PList[*]}
     _run "rc-system enable lightdm"
  else
     PList=("xorg" "task-cinnamon-desktop" "gnome-control-center" 
	 "lightdm" "lightdm-gtk-greeter-settings")
     _add_by_list ${PList[*]}
     _run "systemctl enable lightdm"
  fi
}

function _install_xfce {
  #============================ Install XFCE Desktop ============================================
  printf "\n\n${LPURPLE}=== Install XFCE Desktop  ===${RESTORE}\n"
  local PList=("")
  if [ ${__OS^^} == "ALPINE" ]; then
     PList=("xorg-server" "xfce4" "xfce4-screensaver" "xfce4-whiskermenu-plugin" "lightdm"
            "lightdm-gtk-greeter" "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" 
			"thunar-volman-plugin")
     _add_by_list ${PList[*]}  
     _run "rc-system enable lightdm"
  else
     PList=("xorg" "xfce4" "xfce4-clipman" "xfce4-clipman-plugin" "xfce4-wavelan-plugin" 
	        "xfce4-whiskermenu-plugin" "lightdm" "lightdm-gtk-greeter-settings" "thunar" 
			"thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
     _add_by_list ${PList[*]}  
     _run "systemctl enable lightdm"
  fi
}

function _install_gnome {
  #============================ Install Gnome Desktop ============================================
  printf "\n\n${LPURPLE}=== Install Gnome Desktop  ===${RESTORE}\n"
  localPList=("")
  if [ ${__OS^^} == "ALPINE" ]; then
     PLIST=("xorg-server" "xfce4" "gnome-desktop" "lightdm" "lightdm-gtk-greeter" 
	        "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman-plugin")
     _add_by_list ${PList[*]}  
     _run "rc-system enable lightdm"
  fi
}

function _process_step_1 {
  printf "\n  ${YELLOW}Step 1 - Install System Tools${RESTORE}\n\n"
  printf "\n${LPURPLE}=== Configure System Settings ===${RESTORE}\n"
  rm -f ${LOG} > /dev/null 2>&1

  #=============================
  # Upgrade Linux Packages
  #=============================
  _update_os
  
  #===============================
  # Install required system files
  #===============================
  _add_os_dep

  #===============================
  # Install required system repos
  #===============================
  _add_os_repos

  #===============================
  # Create Network Mount Points
  #===============================
  _task-begin "Create Network Mount Points"
  if [ ! -d /media/documents ]; then _run "mkdir /media/documents"; fi
  if [ ! -d /media/utilities ]; then _run "mkdir /media/utilities"; fi
  if [ ! -d /media/multimedia ]; then _run "mkdir /media/multimedia"; fi
  if [ ! -d /media/backups ]; then _run "mkdir /media/backups"; fi
  if [ ! -d /media/private ]; then _run "mkdir /media/private"; fi
  _task-end
   

  #=============================
  # Change SSH Config File
  #=============================
  _task-begin "Updating SSH Configuration"
  if [ -f /etc/ssh/sshd_config ]; then
	 sed -i "s/#Port 22/Port 9922/" /etc/ssh/sshd_config >/dev/null 2>&1
  fi
  _task-end

  #===============================
  # Create User Directories
  #===============================
  _task-begin "Create User Directories"
  if [ ! -d ${HDIR}/Documents ]; then _run "mkdir ${HDIR}/Documents"; fi
  if [ ! -d ${HDIR}/Downloads ]; then _run "mkdir ${HDIR}/Downloads"; fi
  if [ ! -d ${HDIR}/Pictures ]; then _run "mkdir ${HDIR}/Pictures"; fi
  _task-end

  #==================================
  # Remove non required applications
  #==================================
  printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
  _del_by_list ${DELList[*]}

  #==================================
  # Remove Language Files
  #==================================
  _clean_os
  
  #==================================
  # Setup OS Environment
  #==================================
  _setup_environment  
  
  #==================================
  # Starting Services
  #==================================
  printf "\n${LPURPLE}=== Starting Services ===${RESTORE}\n"
  _task-begin "Starting Services"
  _run "systemctl enable acpid"
  _run "systemctl enable avahi-daemon"
  _run "systemctl enable cups"
  _run "systemctl enable bluetooth"
  _task-end
}

function _process_step_2 {
   printf "\n  ${YELLOW}Step 2 - Install Desktop${RESTORE}\n\n"
   #=============================
   # Choose Desktop Environment
   #=============================
   printf "  ${LPURPLE}      DESKTOP ENVIRONMENT\n"
   printf "  ${LGREEN}+-------------------------------+\n"
   printf "  |                               |\n"
   printf "  |   1) XFCE Desktop             |\n"
   printf "  |   2) Cinnamon Desktop         |\n"
   if [ ${__OS^^} == "ALPINE" ]; then 
      printf "  |   3) Gnome Desktop            |\n"
   else
      printf "  |   3) Budgie Desktop           |\n"
   fi
   printf "  |                               |\n"
   printf "  |  99) NO Desktop               |\n"
   printf "  |                               |\n"
   printf "  +-------------------------------+${RESTORE}\n\n\n"
   while [[ "12399" != *${_DSK}* ]]
   do
      _Ask "${OVERWRITE}Choose the Desktop Environment (1-3 or 99)" "1" && _DSK=$REPLY
   done
   printf "\n\n"

   case ${_DSK^^} in
      1) _install_xfce ;;
      2) _install_cinnamon ;;
      3) if [ ${__OS^^} == "ALPINE" ]; then
	        _install_gnome
	     else
		    _install_budgie
         fi	
		 ;;
   esac

   printf "\n\n"  
   _AskYN "Install Fonts (y/n)" "Y"
   if [ $REPLY == "Y" ]; then
      #============================ Install Compression and Fonts =================================
      printf "\n${LPURPLE}=== Install Fonts ===${RESTORE}\n"
      _add_by_list ${FONTList[*]}
   fi
  
   #==================================
   # Remove non required applications
   #==================================
   printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
   _del_by_list ${DELList[*]}

   #==================================
   # Restarting System
   #==================================
   printf "\n\n${LPURPLE}=== Restarting System - Step 2 ===${RESTORE}\n"
   _AskYN "OK to Reboot Now (y/n)" "Y"
   if [ ${REPLY^^} = "Y" ]; then reboot; fi
}

function _process_step_3 {
   printf "\n  ${YELLOW}Step 3 - Install Desktop Applications${RESTORE}\n\n"
   #==================================
   # Choose Packages to Install
   #==================================
   _chooser

   #==================================
   # Install required applications
   #==================================
   printf "\n${LPURPLE}=== Installing Required Packages ===${RESTORE}\n"
   _add_by_list ${ADDList[*]}
   if [ ${__OS^^} != "ALPINE" ]; then
      if [ ${__THOR^^} = "Y" ]; then _add_thorium; fi
      if [ ${__GOOG^^} = "Y" ]; then _add_chrome; fi
      if [ ${__ETCH^^} = "Y" ]; then _add_etcher; fi
      if [ ${__ULAUN^^} = "Y" ]; then _add_ulauncher; fi
      if [ ${__MAIL^^} = "Y" ]; then _add_mailspring; fi
      if [ ${__EGGS^^} = "Y" ]; then _add_eggs; fi
   fi
   
   #==================================
   # Remove non required applications
   #==================================
   printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
   DELList+=("xfce4-terminal")
   _del_by_list ${DELList[*]}
}

function _process_step_4 {
   local file=""
   printf "\n  ${YELLOW}Step 4 - Install Desktop Customizations${RESTORE}\n\n"
   #===============================
   # Get Themes & Icons
   #===============================
   _task-begin "Get Themes and Icons"
   if [ ! -d ${HDIR}/sys-setup ]; then
      _run "cd ${HDIR}"
      _run "mkdir ${HDIR}/sys-setup"
   fi

   #Download file
   if [ ! -f ${HDIR}/sys-setup/sys.zip ]; then
     _run "cd ${HDIR}/sys-setup"
     _run "wget -q https://tinyurl.com/base-lin"
     if [ -f ${HDIR}/sys-setup/base-lin ]; then
       _run "mv -f base-lin sys.zip"
       _run "unzip -o -q sys.zip"
     fi
     _run "cd ${HDIR}"	 
   fi

   #Backgrounds
   if [ ! -f /usr/share/backgrounds/.setup ]; then
      _run "mv -f ${HDIR}/sys-setup/backgrounds/* /usr/share/backgrounds"
      _run "touch /usr/share/backgrounds/.setup"
   fi

   #Start Icons
   if [ ! -d /usr/share/icons/start ]; then _run "mkdir -p /usr/share/icons/start"; fi
   if [ ! -f /usr/share/icons/start/.setup ]; then
      _run "mv -f ${HDIR}/sys-setup/start/* /usr/share/icons/start/"
      _run "touch /usr/share/icons/start/.setup"
   fi

   #User Files
   if [ ! -f ${HDIR}/.hushlogin ]; then
      _run "mv -f ${HDIR}/sys-setup/.bashrc ${HDIR}"
      _run "mv -f ${HDIR}/sys-setup/.bash_aliases ${HDIR}"
      _run "mv -f ${HDIR}/sys-setup/.hushlogin ${HDIR}"
   fi
   _task-end

   #===============================
   # Install Icons
   #===============================
   _task-begin "Install Icons"
   if [ -f ${HDIR}/sys-setup/sys.zip ]; then
      if [ ! -d /usr/share/icons/kora-yellow ]; then
         _run "cp -fr ${HDIR}/sys-setup/icons/kora* /usr/share/icons"
         _run "cd /usr/share/icons"
		 # Loop through files in the target directory
         for file in /usr/share/icons/kora*.tar.xz; do
          if [ -f "$file" ]; then
             _run "tar -xf $file"
	         _run "rm $file"
			 if [ -d /usr/share/icons/kora_green ]; then
			    _run "mv -f /usr/share/icons/kora_green/* /usr/share/icons"
				_run "rm -rf /usr/share/icons/kora_green"
			 fi
			 if [ -d /usr/share/icons/kora_yellow ]; then
			    _run "mv -f /usr/share/icons/kora_yellow/* /usr/share/icons"
				_run "rm -rf /usr/share/icons/kora_yellow"
			 fi
          fi
         done	  
      fi
   fi
   _task-end

   #===============================
   # Install Themes
   #===============================
   _task-begin "Install Themes"
   if [ -f ${HDIR}/sys-setup/sys.zip ]; then
     if [ ! -d /usr/share/themes/Orchis-Green ]; then
        _run "cd /usr/share/themes"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Teal.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Yellow.tar.xz"
		_run "wget -q https://github.com/vinceliuice/Orchis-theme/raw/master/release/Orchis-Green.tar.xz"
		# Loop through files in the target directory
        for file in /usr/share/themes/Orchis*.tar.xz; do
          if [ -f "$file" ]; then
             _run "tar -xf $file"
	         _run "rm $file"
          fi
        done
	    _run "cd ${HDIR}"
     fi
   fi
   _task-end

   #===============================
   # Update Budgie Configuration
   #===============================
   if [ ! -f /usr/share/backgrounds/budgie/.setup ]; then
      _task-begin "Install Budgie Configuration"
      if [ -d ${HDIR}/sys-setup/budgie ]; then
         _run "sudo -u $SUDO_USER dconf load / < ${HDIR}/sys-setup/budgie/full-backup"
	     _run "rm /usr/share/backgrounds/budgie/default.jpg"
	     _run "cp -f /usr/share/backgrounds/auUagbqqV2gbGi8w.jpg /usr/share/backgrounds/budgie/default.jpg"
         _run "touch /usr/share/backgrounds/budgie/.setup"
      fi
      _task-end
   fi

   #===============================
   # Update XFCE4 Configuration
   #===============================
   if [ -d ${HDIR}/.config/xfce4 ]; then
      _task-begin "Install XFCE4 Configuration"
      if [ ! -f ${HDIR}/.config/xfce4/.setup ]; then
         if [ -d ${HDIR}/sys-setup/xfce4 ]; then
	        local PList=("xfce4-clipman" "xfce4-clipman-plugin" "xfce4-wavelan-plugin" "xfce4-whiskermenu-plugin")
			_add_by_list ${PList[*]}
	        _run "rm -rf ${HDIR}/.config/xfce4/*"
	        if [ ${__OS^^} == "ALPINE" ]; then
			   _run "mv -f ${HDIR}/sys-setup/xfce4/alpine/* ${HDIR}/.config/xfce4/"
			else
			   _run "mv -f ${HDIR}/sys-setup/xfce4/debian/* ${HDIR}/.config/xfce4/"
			fi
            _run "touch ${HDIR}/.config/xfce4/.setup"
	     fi
     fi
	 printf "$OVERWRITE"
     _task-end
   fi

    #===============================
    # Install LightDM Configuration
    #===============================
    _task-begin "Install LightDM Configuration"
    if [ -f ${HDIR}/sys-setup/sys.zip ]; then
       if [ ! -f /etc/lightdm/.setup ]; then
          _run "cd ${HDIR}/sys-setup/lightdm"
	      if [ -f /etc/lightdm/lightdm.conf ]; then _run "rm -f /etc/lightdm/lightdm.conf"; fi
	      _run "mv -f lightdm.conf /etc/lightdm"
	      if [ -f /etc/lightdm/lightdm-gtk-greeter.conf ]; then _run "rm -f /etc/lightdm/lightdm-gtk-greeter.conf"; fi
	      _run "mv -f lightdm-gtk-greeter.conf /etc/lightdm"
	      _run "touch /etc/lightdm/.setup"
		  _run "cd ${HDIR}"
       fi
    fi
    _task-end

    #===============================
    # Install GRUB Background
    #===============================
    _task-begin "Install Grub Background"
    if [ ! -f /boot/grub/.setup ]; then
       if [ ! -d ${HDIR}/sys-setup ]; then _run "mkdir -p ${HDIR}/sys-setup"; fi
       _run "cd ${HDIR}/sys-setup/"
	   if [ -d ${HDIR}/sys-setup/grub2-themes ]; then _run "rm -rf ${HDIR}/sys-setup/grub2-themes"; fi
	   _run "git clone https://github.com/vinceliuice/grub2-themes"
	   if [ -d ${HDIR}/sys-setup/grub2-themes ]; then
          _run "cd ${HDIR}/sys-setup/grub2-themes"
	      _run "${HDIR}/sys-setup/grub2-themes/install.sh -b -t vimix"
	      _run "touch /boot/grub/.setup"
       fi
	   _run "cd ${HDIR}"
    fi
    _task-end

    #===============================
    # Install LXTerminal Setup
    #===============================
    _task-begin "Install LXTerminal Setup"
    if [ $(_exists "lxterminal") > 0 ]; then
       if [ ! -f ${HDIR}/.config/lxterminal/.setup ]; then
          if [ ! -d ${HDIR}/.config/lxterminal/ ]; then _run "mkdir -p ${HDIR}/.config/lxterminal"; fi
	      if [ ! -f ${HDIR}/config/lxterminal/.setup ]; then
	         _run "cd ${HDIR}/sys-setup/applications/lxterminal"
	         _run "mv -f * ${HDIR}/.config/lxterminal/"
	         _run "touch ${HDIR}/.config/lxterminal/.setup"
			 _run "cd ${HDIR}"
          fi
       fi
    fi
    _task-end

    #====================================
    # Install Plank Themes & Setup Files
    #====================================
    _task-begin "Install Plank Themes & Setup Files"
    if [ $(_exists "plank") > 0 ]; then
       if [ -d ${HDIR}/sys-setup/plank ]; then
          if [ ! -f /usr/share/plank/themes/.setup ]; then
	         _run "cd ${HDIR}/sys-setup/plank/themes"
	         _run "mv -f * /usr/share/plank/themes"
	         if [ ! -d ${HDIR}/.config/plank/dock1/launchers/ ]; then _run "mkdir -p ${HDIR}/.config/plank/dock1/launchers"; fi
	         _run "cd ${HDIR}/sys-setup/plank/dock1/launchers/"
	         _run "mv -f * ${HDIR}/.config/plank/dock1/launchers/"
	         _run "sudo -u $SUDO_USER dconf load /net/launchpad/plank/docks/ < ${HDIR}/sys-setup/plank/docks.ini"
	         _run "touch /usr/share/plank/themes/.setup"
			 _run "cd ${HDIR}"
	      fi
       fi
    fi
    _task-end

    #===============================
    # Setup Autostart Files
    #===============================
	if [ ${__OS^^} != "ALPINE" ]; then
       _task-begin "Setting Up Autostart Files"
       if [ ! -d ${HDIR}/.config/autostart/ ]; then _run "mkdir -p ${HDIR}/.config/autostart/"; fi
       if [ -d ${HDIR}/sys-setup/autostart ]; then
          if [ ! -f ${HDIR}/.config/autostart/.setup ]; then
             _run "cd ${HDIR}/sys-setup/autostart"
             _run "mv -f * ${HDIR}/.config/autostart/"
             _run "touch ${HDIR}/.config/autostart/.setup"
			 _run "cd ${HDIR}"
          fi
       fi
      _task-end
    fi
	
    #===============================
    # Setup Keyboard Shortcuts
    #===============================
	if [ ${__OS^^} != "ALPINE" ]; then _create_shortcuts; fi
	
	
	#=============================
    #  Setup FSTAB file
    #=============================
	printf "\n"
	_AskYN "    Do you wish to setup network shares to MB-NAS (y/n)" "Y"
    if [ ${REPLY^^} = "Y" ]; then
	   printf "\n"
       _task-begin "Setup Network Shares"
       RET=$( cat /etc/fstab | grep -c "10.10.10.25" )
       if [ ${RET} == "0" ]; then
          echo ""  >> /etc/fstab
          echo "//10.10.10.25/documents  /media/documents  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/utilities  /media/utilities  cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/multimedia /media/multimedia cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/backups    /media/backups    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
          echo "//10.10.10.25/private    /media/private    cifs credentials=/home/$SUDO_USER/.smbcredentials,noperm,iocharset=utf8 0 0" >> /etc/fstab
       fi
       _run "rm -f ${HDIR}/.smbcredentials"
       _run "mv -f ${HDIR}/sys-setup/.smbcredentials ${HDIR}"
       _run "chmod 600 ${HDIR}/.smbcredentials"
	   _task-end
	fi

	
    #=================================
    # Set Permissions on Directories
    #=================================
    _task-begin "Setting Up Directory Permissions"
    _run "cd ${HDIR}"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/backgrounds"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/icons"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/share/themes"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} /usr/local/include"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.local"
    _run "chown -R ${SUDO_USER}:${SUDO_USER} ${HDIR}/.config"
    _task-end

    #===================================
    # Remove non required applications
    #===================================
    printf "\n${LPURPLE}=== Remove Unrequired Packages ===${RESTORE}\n"
    _del_by_list ${DELList[*]}

    #==================================
    # Cleanup
    #==================================
    _process_cleanup
}

function _process_cleanup {
   _task-begin "Remove Temporary Files"
   if [ -d ${HDIR}/sys-setup ]; then _run "rm -rf ${HDIR}/sys-setup"; fi
   _task-end

   #  Cleanup Package files
   _task-begin "Cleaning APT Repository"
   if [ ${__OS^^} != "ALPINE" ]; then
      _run "$APT $FIX"
      _run "$APT $PRG"
      _run "$APT $CLN"
      _run "$APT $REM"
   fi
   _task-end   
}

function _upgrade_apps {
   _update_os
   _run "flatpak update -y"
   
   if [ ${__OS^^} != "ALPINE" ]; then
      printf "\n${LPURPLE}=== Updating Debian (.deb) Packages ===${RESTORE}\n"
      if (( $(_exists "thorium-browser") > 0 )); then _add_thorium; fi
      if (( $(_exists "google-chrome-stable") )); then _add_chrome; fi
      if (( $(_exists "balena-etcher") > 0 )); then _add_etcher; fi
      if (( $(_exists "ulauncher") > 0 )); then _add_ulauncher; fi
      if (( $(_exists "penguins-eggs") > 0 )); then _add_eggs; fi
   fi
}

