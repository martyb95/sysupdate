#========================================================
#    Service Functions
#========================================================
function _del_service {
  if [ -f "/etc/init.d/${1}" ]; then
    _task-begin "Removing ${1^^} service"
    _run "systemctl stop ${1}"
    _run "systemctl disable ${1}"
	_task-end
  fi
}

function _del_service_by_list {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
	  _del_service ${_pkg}
	done
  fi
}

 
