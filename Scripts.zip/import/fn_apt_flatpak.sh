
#========================================================
#    General APT Functions
#========================================================
function _set_pkg_mgr {
  APT="apt"
  ADD="install -qq --allow-downgrades -y"
  REPO="add-apt-repository -y"
  CLN="autoclean -y"
  DEL="purge -y"
  FIX="install --fix-broken -y"
  PRG="autopurge -y"
  REM="autoremove -y"
  UPD="update"
  UPG="upgrade -y"
  DIST="dist-upgrade -y"
  FULL="full-upgrade -y"
  
  if [ ${__OS^^} == "ALPINE" ]; then
     APT="apk"
     ADD="add"
     REPO=""
     CLN=""
     DEL="del"
     FIX=""
     PRG=""
     REM=""
     UPD="update"
     UPG="upgrade"
     DIST="upgrade"
     FULL="upgrade"  
  fi
}

#========================================================
#    APT Functions
#========================================================
function _PKG_List {
  local _Ans=${1^^}
  local _Pkg=${2}
  
  case ${_Ans^^} in
     Y) ADDList+=(${_Pkg}) ;;
     R) if [ ${_Pkg^^} == "CLAMAV" ]; then _Pkg="clamav clamav-daemon clamtk"; fi
	    if [ ${_Pkg^^} == "LIBREOFFICE" ]; then _Pkg="libreoffice*"; fi
        if [ ${_Pkg^^} == "WINEHQ-STABLE" ]; then _Pkg="wine*"; fi
        if [ ${_Pkg^^} == "WINE" ]; then _Pkg="wine*"; fi
        DELList+=(${_Pkg})
       ;;
  esac  
}

function _add_repo {
  _task-begin "Installing Repository ${1^^}"
  if [ -v $REPO ]; then _set_pkg_mgr; fi
  _run "$REPO $1"
  _run "$APT $UPD"
  _task-end
}

function _add_repo_by_list {
  local _Repos=${*}
  if [ ${#_Repos} -gt 0 ]; then
    for _repo in ${_Repos[@]}; do
      _add_repo ${_repo}
    done
  fi
}

function _add_pkg {
  if [ -v $APT ]; then _set_pkg_mgr; fi
  if (( $(_exists $1) == 0 )); then
    _task-begin "Installing ${1^^}"
    _run "$APT $ADD $1"
    _task-end
    #if [[ ${1^^} == *"CHROMIUM"* ]]; then _chrome_ext "chromium"; fi
  fi
}

function _add_by_list {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
          _add_pkg ${_pkg}
    done
  fi
}

function _del_pkg {
  if [ -v $APT ]; then _set_pkg_mgr; fi
  if (( $(_exists $1) > 0 )); then  
    _task-begin "Removing ${1^^}"
    _run "$APT $DEL $1"
    #if [[ ${_Pkg^^} == *"CHROMIUM"* ]]; then _chrome_ext "chromium"; fi
    _task-end
  fi
}

function _del_by_list {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
      _del_pkg ${_pkg}
    done
  fi
}


#========================================================
#    FLATPAK Functions
#========================================================
function _FLT_List {
  local _Ans=${1^^}
  local _Pkg=${2}
  
  case ${_Ans^^} in
     Y) FADDList+=(${_Pkg}) ;;
     R) FDELList+=(${_Pkg}) ;;
  esac   
}

function _add_flatpak_repo {
  _task-begin "Installing ${1^^} Repo"
  _run "flatpak remote-add --if-not-exists ${1} ${2}"
  _task-end
}

function _add_flatpak_repo_by_list {
  local _Repos=${*}
  if [ ${#_Repos} -gt 0 ]; then
    for _repo in ${_Repos[@]}; do
	  _add_flatpak_repo ${_repo}
	done
  fi
}

function _add_flatpak {
  if [ $(flatpak list | grep -c ${1}) -eq 0 ]; then
    _task-begin "Installing Flatpak ${1^^}"
    _run "flatpak install -y ${1}"
	_task-end
 fi
}

function _add_flatpak_by_list {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
	  _add_flatpak ${_pkg}
	done
  fi
}

function _del_flatpak {
  if [ $(flatpak list | grep -c ${1}) -gt 0 ]; then
    _task-begin "Removing Flatpak ${1^^}"
    _run "flatpak uninstall -y ${1}"
	_task-end
  fi
}

function _del_flatpak_by_list {
  local _Pkgs=${*}
  if [ ${#_Pkgs} -gt 0 ]; then
    for _pkg in ${_Pkgs[@]}; do
	  _del_flatpak ${_pkg}
	done
  fi
}


#========================================================
#    Install Deb File Functions
#========================================================
function _add_chrome {
  local _URL="https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"

  _task-begin "Installing/Updating GOOGLE CHROME"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./google-chrome-stable_current_amd64.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./google-chrome-stable_current_amd64.deb"
  _run "rm -f ./google-chrome-stable_current_amd64.deb"
  _task-end
  #_chrome_ext ${_PKG} "google-chrome"
}

function _add_thorium {
  local _REL=$(curl -sL https://api.github.com/repos/Alex313031/thorium/releases/latest | jq -r ".tag_name")
  local _RELN=${_REL//M}
  local _URL="https://github.com/Alex313031/thorium/releases/download/${_REL}/thorium-browser_${_RELN}_amd64.deb"

  _task-begin "Installing/Updating Thorium Browser"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./thorium-browser_${_RELN}_amd64.deb"
  _run "wget -q $_URL"
  _run "$APT $ADD ./thorium-browser_${_RELN}_amd64.deb"
  _run "rm -f ./thorium-browser_${_RELN}_amd64.deb"
  _task-end
}

function _add_slimjet {
   local _URL=""
   local _DIR=""
   
  _task-begin "Installing/Updating SLIMJET Browser"
    if [ -v $APT ]; then _set_pkg_mgr; fi
  _DIR=$(curl -s https://www.slimjet.com/release/archive/ | tail --lines=4 | head --lines=1 | grep -oP '<a href=".+?">\K.+?(?=<)')
  _URL="https://www.slimjet.com/release/archive/${_DIR}slimjet_amd64.deb"
  _run "rm -f ./slimjet_amd64.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./slimjet_amd64.deb"
  _run "rm -f ./slimjet_amd64.deb"
  _task-end
  #_chrome_ext "slimjet" "slimjet"
}

function _add_etcher {
  local _REL=$(curl -sL https://api.github.com/repos/balena-io/etcher/releases/latest | jq -r ".tag_name")
  local _RELN=${_REL//v}
  local _URL=" https://github.com/balena-io/etcher/releases/download/${_REL}/balena-etcher_${_RELN}_amd64.deb"

  _task-begin "Installing/Updating Balena Etcher"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./balena-etcher_${_RELN}_amd64.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./balena-etcher_${_RELN}_amd64.deb"
  _run "rm -f ./balena-etcher_${_RELN}_amd64.deb"
  _task-end
}

function _add_ulauncher {
  local _REL=$(curl -sL https://api.github.com/repos/Ulauncher/Ulauncher/releases/latest | jq -r ".tag_name")
  local _RELN=${_REL//v}
  local _URL="https://github.com/Ulauncher/Ulauncher/releases/download/${_REL}/ulauncher_${_RELN}_all.deb"

  _task-begin "Installing/Updating Ulauncher"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./ulauncher_${_RELN}_all.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./ulauncher_${_RELN}_all.deb"
  _run " rm -f ./ulauncher_${_RELN}_all.deb"
  _task-end
}

function _add_mailspring {
  local _REL=$(curl -sL https://api.github.com/repos/Foundry376/Mailspring/releases/latest | jq -r ".tag_name")
  local _URL="https://github.com/Foundry376/Mailspring/releases/download/${_REL}/mailspring-${_REL}-amd64.deb"
  
  _task-begin "Installing/Updating MAILSPRING"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./mailspring-${_REL}-amd64.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./mailspring-${_REL}-amd64.deb "
  _run "rm -f ./mailspring-${_REL}-amd64.deb"
  _task-end
}

function _add_eggs {
  local _RELV=$(curl -sL https://api.github.com/repos/pieroproietti/penguins-eggs/releases/latest | jq -r ".tag_name")
  local _REL=${_RELV#*v}
  local _URL="https://github.com/pieroproietti/penguins-eggs/releases/download/${_RELV}/eggs_${_REL}_amd64.deb"
  
  _task-begin "Installing/Updating PENGUINS-EGGS"
  if [ -v $APT ]; then _set_pkg_mgr; fi
  _run "rm -f ./eggs_${_REL}_amd64.deb"
  _run "wget -q ${_URL}"
  _run "$APT $ADD ./eggs_${_REL}_amd64.deb"
  _run "rm -f ./eggs_${_REL}_amd64.deb"
  _task-end
}

function _install_ext {
  _task-begin "Installing browser extension $[2^^]"
  preferences_dir_path="/opt/google/chrome/extensions"
  pref_file_path="$preferences_dir_path/$1.json"
  upd_url="https://clients2.google.com/service/update2/crx"
  
  _run "mkdir -p $preferences_dir_path"
  echo "{" > "$pref_file_path"
  echo "  \"external_update_url\": \"$upd_url\"" >> "$pref_file_path"
  echo "}" >> "$pref_file_path"
  echo Added \""$pref_file_path"\" ["$2"]
  _task-end
}

function _browser_ext {
  local _DIR=""
  local _PKG=${1}
  local _DIRNAME=${2}
  if [ -z ${2} ]; then _DIRNAME=_PKG; fi
  
  if [ -z $(apk -e info ${_Pkg}) ]; then
    _task-begin "Removing ${_PKG^^} Extensions"
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/cjpalhdlnbpafiamejdnhcphjbkeiagm"
    if [ -d ${_DIR} ]; then rm -f ${_DIR}" >> ${LOG} 2>&1; fi
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/pkehgijcmpdhfbdbbnkijodmdjhbjlgp"    
    if [ -d ${_DIR} ]; then rm -f ${_DIR}" >> ${LOG} 2>&1; fi
	
           _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/ohlencieiipommannpdfcmfdpjjmeolj"
          if [ -d ${_DIR} ]; then rm -f ${_DIR}" >> ${LOG} 2>&1; fi
   
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/icpgjfneehieebagbmdbhnlpiopdcmna"
    if [ -d ${_DIR} ]; then rm -f ${_DIR}" >> ${LOG} 2>&1; fi
	_task-end
  else
    _task-begin "Installing/Updating ${_PKG^^} Extensions"
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/cjpalhdlnbpafiamejdnhcphjbkeiagm"
    if [ ! -d ${_DIR} ]; then _install_ext "cjpalhdlnbpafiamejdnhcphjbkeiagm" "ublock origin" >> ${LOG} 2>&1; fi
  
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/pkehgijcmpdhfbdbbnkijodmdjhbjlgp"    
    if [ ! -d ${_DIR} ]; then _install_ext "pkehgijcmpdhfbdbbnkijodmdjhbjlgp" "privacy badger" >> ${LOG} 2>&1; fi

    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/ohlencieiipommannpdfcmfdpjjmeolj"
    if [ ! -d ${_DIR} ]; then _install_ext "ohlencieiipommannpdfcmfdpjjmeolj" "print friendly" >> ${LOG} 2>&1; fi
   
    _DIR="${HDIR}/.config/${_DIRNAME}/Default/Extensions/icpgjfneehieebagbmdbhnlpiopdcmna"
    if [ ! -d ${_DIR} ]; then _install_ext "icpgjfneehieebagbmdbhnlpiopdcmna" "new tab redirect" >> ${LOG} 2>&1; fi
    _task-end
  fi 
}

