

# @arg $1 string The string to be trimmed.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout The trimmed string.
_trim() {
    [[ $# = 0 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2

    : "${1#"${1%%[![:space:]]*}"}"
    : "${_%"${_##*[![:space:]]}"}"
    printf '%s' "$_"
}


# @arg $1 string The input string.
# @arg $2 string The delimiter string.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout Returns an array of strings created by splitting the string parameter by the delimiter.
_split() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    declare -a arr=($(echo $1 | tr "|" "\n"))
    printf '%s' "${arr[@]}"
}


# @arg $1 string The input string.
# @arg $2 string The characters you want to strip.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout Returns the modified string.
_lstrip() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    printf '%s' "${1##$2}"
}


# @arg $1 string The input string.
# @arg $2 string The characters you want to strip.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout Returns the modified string.
_rstrip() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    printf '%s' "${1%%$2}"
}


# @arg $1 string The input string.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout Returns the lowercased string.
_tolower() {
    [[ $# = 0 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    if [[ ${BASH_VERSINFO:-0} -ge 4 ]]; then
        printf '%s' "${1,,}"
    else
        printf "%s" "${@}" | tr '[:upper:]' '[:lower:]'
    fi
}


# @arg $1 string The input string.
# @exitcode 0  If successful.
# @exitcode 2 Function missing arguments.
#
# @stdout Returns the uppercased string.
_toupper() {
    [[ $# = 0 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    if [[ ${BASH_VERSINFO:-0} -ge 4 ]]; then
        printf '%s' "${1^^}"
    else
        printf "%s" "${@}" | tr '[:lower:]' '[:upper:]'
    fi
}


# @arg $1 string The input string.
# @arg $2 string The search key.
# @exitcode 0  If match found.
# @exitcode 1  If no match found.
# @exitcode 2 Function missing arguments.
_contains() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    # Usage: string_contains hello he
    [[ "${1}" == *${2}* ]]
}


# @arg $1 string The input string.
# @arg $2 string The search key.
# @exitcode 0  If match found.
# @exitcode 1  If no match found.
# @exitcode 2 Function missing arguments.
_starts_with() {
    # Usage: string_starts_with hello he
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    [[ "${1}" == ${2}* ]]
}


# @arg $1 string The input string.
# @arg $2 string The search key.
# @exitcode 0  If match found.
# @exitcode 1  If no match found.
# @exitcode 2 Function missing arguments.
_ends_with() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    # Usage: string_ends_wit hello lo
    [[ "${1}" == *${2} ]]
}


# @arg $1 string The input string.
# @arg $2 string The search key.
# @exitcode 0  If match found.
# @exitcode 1  If no match found.
# @exitcode 2 Function missing arguments.
_regex() {
    [[ $# -lt 2 ]] && printf "%s: Missing arguments\n" "${FUNCNAME[0]}" && return 2
    if [[ ${1} =~ ${2} ]]; then
        return 0
    else
        return 1
    fi

}
