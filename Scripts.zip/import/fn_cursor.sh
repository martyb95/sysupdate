VER='\u2502'
HOR='\u2500'
LT='\u250c'
LB='\u2514'
RT='\u2510'
RB='\u2518'
LTIT='\u2524'
RTIT='\u251c'

source fn_general

function _down() {
  #moves cursor n lines down
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uB" $SIZE
}

function _up() {
  #moves cursor n lines up
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uA" $SIZE
}

function _right() {
  #moves cursor n columns right
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uC" $SIZE
}

function _left() {
  #moves cursor n columns left
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uD" $SIZE
}

function _next() {
  #moves cursor to beginning of line n lines down
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uE" $SIZE
}

function _prev() {
  #moves cursor to beginning of line n lines up
  local SIZE=$1

  if [ -z $1 ]; then SIZE=1; fi
  printf "\u001b[%uF" $SIZE
}

function _set() {
  #moves cursor to row n column m
  local ROW=$1
  local COL=$2

  if [ -z $1 ]; then ROW=1; fi
  if [ -z $2 ]; then COL=1; fi
  printf "\u001b[%u;%uH" $ROW $COL
}

function _clrscrn() {
  #OPT=0 clears from cursor until end of screen,
  #OPT=1 clears from cursor to beginning of screen
  #OPT=2 clears entire screen
  local OPT=$1

  if [ -z $1 ]; then OPT=2; fi
  if [ $1 > 2 ]; then COL=2; fi
  printf "\u001b[%uJ" $OPT
}

function _clrline() {
  #OPT=0 clears from cursor to end of line
  #OPT=1 clears from cursor to start of line
  #OPT=2 clears entire line
  local OPT=$1

  if [ -z $1 ]; then OPT=2; fi
  if [ $1 > 2 ]; then COL=2; fi
  printf "\u001b[%uK" $OPT
}

function _box() {
  local ROW=$1
  local COL=$2
  local HEIGHT=$3
  local WIDTH=$4
  local TITLE=$5
  local TOP=""
  local BOT=""
  local SPC=""
  local OFFSET=0

  OFFSET=$(($WIDTH - 2 - ${#TITLE}))
  OFFSET=$(($OFFSET/2))

  TOP="$LT"
  BOT="$LB"
  for i in {1..240}
  do
    TOP="$TOP$HOR"
    BOT="$BOT$HOR"
    SPC="$SPC "
    if (( i == $WIDTH )); then break; fi
  done
  TOP="$TOP$RT"
  BOT="$BOT$RB"

  _set $ROW $COL && printf "$LGREEN$TOP"
  for i in {1..240}
  do
    _set $((ROW+i)) $COL && printf "\u2502$SPC\u2502"
    if (( i == $(($HEIGHT-2)) )); then break; fi
  done
  _set $(($ROW+$HEIGHT-1)) $COL && printf "$BOT"

  if [[ ! -z $TITLE ]]; then 
     _set $ROW $(($COL+$OFFSET))
     printf "$LTIT$LPURPLE$TITLE$LGREEN$RTIT"
  fi
  printf "$RESTORE"
  _set $(($ROW+$HEIGHT+1)) 1
}

function _menuitem() {
  local ROW=$1
  local COL=$2
  local NUM=$3
  local TXT=$4
  
  _set $ROW $COL
  printf "$GREEN%2u. $CYAN$TXT$RESTORE" $NUM
}