REPLY=""

#========================================================
#    Input Functions
#========================================================
function _Ask(){
  if  [[ ${2} != "" ]]; then
    printf "${LGREEN}${1} ${YELLOW}[${2}]: ${RESTORE}"
    read REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="${2}" ; fi
  else
    printf "${LGREEN}${1}: ${RESTORE}"
    read REPLY
  fi
  REPLY=${REPLY^^}
}

function _AskPass(){
  local __ret="UNKNOWN"
  local __ret2=""

  while [[ ${__ret} != ${__ret2} ]]
  do
    printf "${LGREEN}Password: ${RESTORE}"
    read -s __ret
    printf "\n${LGREEN}Repeat Password: ${RESTORE}"
    read -s __ret2
    printf "\n"
    if [[ ${__ret^^} != ${__ret2^^} ]]; then
      printf "${RED}ERROR - Passwords do not match${RESTORE}\n\n"
    fi
  done
  REPLY=${__ret^^}
}

function _AskYN(){
  local __flg="N"
  while [[ ${__flg} == "N" ]]
  do
    printf "${LGREEN}${1}? ${YELLOW}[${2}]: ${RESTORE}"
    read -n 1 REPLY
    if [[ ${REPLY} == "" ]] ; then REPLY="$2" ; else echo " "; fi

    case ${REPLY^^} in
      [Y]* ) __flg="Y";;
      [N]* ) __flg="Y";;
      [R]* ) __flg="Y";;
      * ) printf "${RED}ERROR - Invalid Option Entered [Y/N]${RESTORE}\n\n"; __flg="N";;
    esac
  done
  REPLY=${REPLY^^}
}
