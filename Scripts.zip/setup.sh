#!/bin/bash


# script must NOT be run as root
if [[ $(id -u) -eq 0 ]] ; then
   printf "\n\n*************** Please run as NON root user ***************\n\n\n"
   exit 1
fi

sudo ./main.sh "$DBUS_SESSION_BUS_ADDRESS"

# Process if desktop config is required
if [ -f ~/Documents/dconf.conf ]; then 
   dconf load / < ~/Documents/dconf.conf
   mv ~/Documents/dconf.conf ~/Documents/dconf.bak
fi
