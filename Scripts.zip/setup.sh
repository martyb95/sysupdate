#!/bin/bash

# script must NOT be run as root
if [[ $(id -u) -eq 0 ]] ; then
   printf "\n\n*************** Please run as NON root user ***************\n\n\n"
   exit 1
fi

sudo ./main.sh "$DBUS_SESSION_BUS_ADDRESS"

if [ -f ${HDIR}/Documents/dconf.conf ]; then 
   _run "dconf load / < ${HDIR}/Documents/dconf.conf"
   _run "mv ${HDIR}/Documents/dconf.conf ${HDIR}/Documents/dconf.bak"
fi

if [ -f ${HDIR}/scripts/skipdir/.reboot ]; then
   _run "rm -f ${HDIR}/scripts/skipdir/.reboot"
   _run "sudo reboot"
fi