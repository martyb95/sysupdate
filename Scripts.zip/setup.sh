#!/bin/bash

# script must NOT be run as root
if [[ $(id -u) -eq 0 ]] ; then
   printf "\n\n*************** Please run as NON root user ***************\n\n\n"
   exit 1
fi

sudo ./main.sh "$DBUS_SESSION_BUS_ADDRESS"
echo "At end"