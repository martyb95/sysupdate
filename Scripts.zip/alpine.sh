#!/bin/bash

SYSList=("7zip" "acpi" "acpid" "alsa-utils" "avahi-utils" "bash" "bash-completion" "bluez"
         "blueman" "cifs-utils" "cups" "curl" "dconf-cli" "dbus-x11" "fileroller" "fuse" "git" "gvfs" "gvfs-backends"
		 "jq" "nano" "pipewire" "wireplumber" "pipewire-alsa" "pipewire-audio" "pipewire-pulse" "rar" "libspa-0.2-bluetooth" "preload"
		 "sed" "sudo" "udisks2" "unzip" "wget" "xarchiver" "xz" "zram-tools")

DELList=("firefox")
APPList+=("=== Choose Browser(s) ===||"
          "Brave Browser|@FLT-BRAVE|N" 
          "Chromium Browser|@FLT-CHROME|N" 
		  "Falkon Browser|@FLT-FALKON|Y"
          "Firefox Browser|@FLT-FIREFOX|N"
          "Floorp Browser|@FLT-FLOORP|N"
          "Google Chrome Browser|@FLT-GOOGLE|N"
          "LibreWolf Browser|@FLT-WOLF|N"
          "UnGoogled Chromium Browser|@FLT-UNGOOGLE|Y"
		  "Vivaldi Browser|@FLT-VIVALDI|N"
          "Waterfox Browser|@FLT-WATER|Y"
          "=== Choose Office Tools ===||"
		  "Abiword Word Processor|abiword|Y"
          "Bluemail Email Client|@FLT-BLUE|N"
          "Geary Email Client|geary|N"
          "gEdit Graphical Editor|gedit|N"
          "Gnome Calendar|gnome-calendar|N"
		  "Gnome Calculator|gnome-calculator|Y"
		  "gNumeric Spreadsheet|gnumeric|Y"
          "Libre Office|libreoffice|N"
          "Mailspring Email Client|@FLT-MAIL|N"
		  "Mousepad Notepad|mousepad|Y"
		  "NotepadQQ Editor|@FLT-NOTEPAD|Y"
		  "Notepad Next Editor|@FLT-NEXT|N"
		  "OnlyOffice Suite|@FLT-ONLY|Y"
          "Simple Scan|simple-scan|Y"
		  "Standard Notes|@FLT-NOTES|N"
		  "Thunderbird Email Client|thunderbird|Y"
		  "WPS Office|@FLT-WPS|N"
          "=== Choose Social Media Tools ===||"
          "Choqok Twitter Client|@FLT-TWIT|N"
          "Caprine - Facebook Client|@FLT-FACE|N"
          "FreeTube - YouTube Client|@FLT-TUBE|N"
          "=== Choose Video Conferencing Tools ===||"
          "Skype Video Conferencing|@FLT-SKYPE|N"
          "Teams Video Conferencing|@FLT-TEAMS|N"
          "WhatsApp Conferencing|@FLT-WHAT|N"
          "Zoom Video Conferencing|@FLT-ZOOM|N"
          "=== Choose Development Tools ===||"
		  "Rust Programming Lanuage|rust|N"
          "VSCodium IDE|@FLT-CODE|N"
          "VSCode IDE|@FLT-VSCODE|N"
          "=== Choose System Tools ===||"
          "BleachBit Utility|@FLT-BLEACH|Y"
          "Clam Anti Virus|clamav|N"
          "Clam Anti Virus GUI|@FLT-CLAMTK|N"
          "Disk Utility|gnome-disk-utility|Y"
		  "Fastfetch|fastfetch|Y"
		  "Flameshot Screenshot Utility|flameshot|Y"
		  "Gnome Software Manager|gnome-software|Y"
		  "gParted Disk Partioning|gparted|Y"
          "HTOP Process Viewer|htop|Y"
		  "Neofetch|neofetch|N"
          "Numlockx|numlockx|Y"
          "Pika Backup|@FLT-PIKA|Y"
		  "Putty SSH Utility|putty|Y"
		  "System Monitor|@FLT-MONITOR|Y"
          "Warehouse|@FLT-WARE|Y"
          "Flatsweep|@FLT-SWEEP|Y"
          "Impress USB Writer|@FLT-IMPRESS|Y"
          "=== Choose Emulation Tools ===||"
		  "Bottles Windows Emulation|@FLT-BOTTLES|N"
          "Play On Linux|@FLT-PLAY|N"
		  "WayDroid - Android Emulator|waydroid|N"
          "WINE|wine|N"
          "Wine GUI|@FLT-WGUI|N"
          "=== Choose Virtualization Tools ===||"
		  "DistroBox|distrobox|N"
		  "Docker|docker|N"
		  "Gnome Boxes|gnome-boxes|Y"
		  "Podman|podman|N"
		  "Virtualization Manager|virt-manager|N"
          "=== Choose Optional Applications ===||"
		  "Calibre eBook Manager|@FLT-BOOK|N"
		  "Cheese Camera Utility|cheese|N"
		  "gThumb Image Viewer|gthumb|N"
          "Kodi Media Center|kodi|N"
          "MPV Media Player|mpv|N"
          "Ristretto Image Viewer|ristretto|Y"
		  "Spotify Client|@FLT-SPOT|N"
          "Strawberry Music Player|strawberry|N"
		  "VLC Media Player|vlc|Y"
		  "XArchiver Utility|xarchiver|Y")

function _setup_environment {
  printf "\n\n${LPURPLE}=== Updating OS Environment ===${RESTORE}\n"
  # Disable Root Login
  _task-begin "Disable Root Login"
  RET=$( grep -c 'root:/sbin/nologin' /etc/passwd)
  if [ ${RET} == 0 ]; then
    _run "sed -i s'#root:/bin/ash#root:/sbin/nologin#' /etc/passwd"
  fi
  _task-end

  # Update Alpine Terminal Profile
  _task-begin "Update Alpine Terminal Profile"
  RET=$( cat /etc/profile | grep -c 'PS1="\[\033}' )
  if [ ${RET} == 0 ]; then
     _run "printf \"PS1='${PS1}'\nexport PS1\" | tee -a /etc/profile"
  fi
  printf "${OVERWRITE}${OVERWRITE}"
  _task-end

  # Remove Alpine MOTD
  _task-begin "Removing MOTD"
  if [ -f /etc/motd ]; then _run "rm /etc/motd"; fi
  _task-end

  #================ Change Shell to Bash ===========
  if [[ $(grep -c '/bin/ash' /etc/passwd) == 0 ]]; then
     _task-begin "Change Shell to BASH"
     _run "sed 's#/bin/ash#/bin/bash#' /etc/passwd"
     _task-end
  fi
               
  # Install Pipewire on Alpine
  if (( $(_Exists "pipewire") == 0 )); then
     printf "\n${LPURPLE}=== Install Pipewire ===${RESTORE}\n"
     _task-begin "Set Pipewire User Groups"
     _run "addgroup ${SUDO_USER} audio"
     _run "addgroup ${SUDO_USER} video"
     _task-end
  fi
  _run "addgroup ${SUDO_USER} plugdev"         
  _run "setup-devd udev"
}

function _del_language {
  _task-begin "Deleting Language Files"
  _task-end
}

function _start_services {
  printf "\n${LPURPLE}=== Starting Services ===${RESTORE}\n"
  _task-begin "Starting Services"
  _run "rc-update add acpid"
  _run "rc-update add avahi-daemon"
  _run "rc-update add cupsd"
  _run "rc-update add bluetooth"
  _run "rc-service sshd restart"
  _run "rc-service networkmanager restart"
  _task-end
}

function _set_aliases {
   if [[ -f $HDIR/.bash_aliases ]]; then
     if [[ ! $HDIR/.aliases ]]; then
        echo "alias update='sudo apk update && sudo apk upgrade && sudo flatpak update'" | tee $HDIR/.bash_aliases
        echo "alias install='sudo apk add '" | tee $HDIR/.bash_aliases
        echo "alias remove='sudo apk del '" | tee $HDIR/.bash_aliases
	    touch $HDIR/.aliases
	 fi
   fi
}

function _install_Desktop {
  local PROG=()
  #============================ Install Desktop ============================================
  printf "\n\n${LPURPLE}=== Installing $DSK Desktop Environment  ===${RESTORE}\n\n"
  if [ ! -f /usr/share/.desktop ]; then
     _task-begin "Installing ${DSK^^} Desktop Components"
	 PROG=("gnome-control-center" "gnome-software-plugin-flatpak" "gnome-software-plugin-apk"
	       "lightdm" "lxterminal" "networkmanager" "network-manager-applet" "networkmanager-wifi"
		   "thunar" "thunar-archive-plugin" "thunar-media-tags-plugin" "thunar-volman"
	       "wpa_supplicant" "volumeicon-alsa")

	 case ${DSK^^} in
       'LXQT') PROG+=("budgie-desktop" "budgie-indicator-applet" "plank")
	           ;;
            *) _task-begin "Installing ${DSK^^} Desktop"
               _run "setup-desktop ${DSK,,}"
               _task-end
               ;; 
     esac	 
     _task-end
	 
# apk add lxqt-desktop lximage-qt obconf-qt pavucontrol-qt

If using Xorg, the following packages are also suggested:
# apk add arandr screengrab sddm


     _add_by_list ${PROG[*]}
     _run "rc-update add lightdm"
     _run "touch /usr/share/.desktop"
  else
     printf "   ${LRED}A Desktop Exists..Skipping${RESTORE}\n"     
  fi
}

function _prereqs {
   MYUID=$(grep $SUDO_USER /etc/passwd | cut -f3 -d':')
   ADDR="unix:path=/run/user/$MYUID/bus"

   if [[ ! -f ${HDIR}/.prereq ]]; then
      printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n"      
      _task-begin "Updating Linux System"
      _run "apk update"
      _run "apk upgrade"
	  _run "apk add curl wget unzip nano xz"
	  _task-end

      _task-begin "Installing Flatpak"
      _run "apk add flatpak git"
      _run "flatpak remote-add --if-not-exists 'flathub' 'https://flathub.org/repo/flathub.flatpakrepo'"
      _task-end
	  touch ${HDIR}/.prereq
   fi
}