#!/bin/bash

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then
   printf "\n\n*************** Please run as root ***************\n\n\n"
   exit 1
fi

HDIR="/home/${SUDO_USER}"
LOG="${HDIR}/update.log"
ValidOS="DEBIAN,ALPINE,VOID,ARCH"
VER="3.10"

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release >>$LOG 2>&1
   REALOS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   REALOS=$( uname )
fi
  
OS="UNKNOWN"
case ${REALOS^^} in
    DEBIAN)      OS="DEBIAN" ;;
    ELEMENTARY)  OS="DEBIAN" ;;
    BUNSENLABS)  OS="DEBIAN" ;;
    LINUXMINT)   OS="DEBIAN" ;;
    SPARKY)      OS="DEBIAN" ;;
    UBUNTU)      OS="DEBIAN" ;;
    LBUNTU)      OS="DEBIAN" ;;
    XBUNTU)      OS="DEBIAN" ;;
    ZORIN)       OS="DEBIAN" ;;
    ALPINE)      OS="ALPINE" ;;
    VOID)        OS="VOID" ;;
	ARCH)        OS="ARCH" ;;
	ARTIX)       OS="ARCH" ;;
	MANJARO)     OS="ARCH" ;;
esac  

# Operating system must be one of the valid ones
if [[ ${ValidOS^^} != *${OS^^}* ]]; then
   printf "\n\n********** [${REALOS^^}] Is An Invalid OS. *******\n\n\n";
   exit 1
fi

if [[ ! -d /$HDIR/scripts ]]; then
   printf "\n\n********** Script Directory does NOT exist. *******\n\n\n";
   exit 1
fi

cd /$HDIR/scripts
source base.sh
case ${OS^^} in
  'ALPINE') source alpine.sh ;;
    'ARCH') source arch.sh ;;
    'VOID') source void.sh ;;
  'DEBIAN') source debian.sh ;;
esac

#=======================================
# Main Code - Start
#=======================================
_title
if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
_run "touch ${LOG}"
_run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

# === Install Prerequisites ===
_prereqs

# === Upgrade Linux Packages ===
while [[ ${STP^^} != "99" ]]
do
   _main_menu
   case ${STP^^} in
      1) _process_step_1 ;;
      2) _process_step_2 ;;
      3) _process_step_3 ;;
      4) _process_step_4 ;;
     99) break ;;
   esac
   STP="777"
done