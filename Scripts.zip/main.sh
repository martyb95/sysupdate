#!/bin/bash

#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'
LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'
OVERWRITE='\e[1A\e[K'

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then
   printf "\n\n${LRED}*************** Please run as root ***************${RESTORE}\n\n\n"
   exit 1
fi

#=======================================
# Set the DBUS address for user
#=======================================
HDIR="/home/${SUDO_USER}"
LOG="${HDIR}/update.log"
ValidOS="DEBIAN,ALPINE,VOID"
FN="main()"
VER="3.79"

#=======================================
# Error Handler
#=======================================
function errHandler {
  local ERRCMD="$1"
  local ERRMSG=$(cat ${HDIR}/error.tmp)
  TIMESTAMP="2025-12-20 14:23:52"
  printf "\n\n========= $TIMESTAMP =====================================================\n" >> ${LOG}
  printf "  ERROR - ${ERRMSG}\n" >> ${LOG}
  printf "          COMMAND:     ${ERRCMD}\n" >> ${LOG}
  printf "          FUNCTION:    ${FN}\n" >> ${LOG}
  printf "          LINE NUMBER: ${BASH_LINENO}\n" >> ${LOG}
  printf "===================================================================================\n" >> ${LOG}
  rm -f ${HDIR}/error.tmp 2>&1>/dev/null
}

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release
   REALOS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   REALOS=$( uname )
fi
  
OS="UNKNOWN"
case ${REALOS^^} in
    DEBIAN)      OS="DEBIAN" ;;
    ELEMENTARY)  OS="DEBIAN" ;;
    BUNSENLABS)  OS="DEBIAN" ;;
    LINUXMINT)   OS="DEBIAN" ;;
    SPARKY)      OS="DEBIAN" ;;
    UBUNTU)      OS="DEBIAN" ;;
    LBUNTU)      OS="DEBIAN" ;;
    XBUNTU)      OS="DEBIAN" ;;
    ZORIN)       OS="DEBIAN" ;;
    ALPINE)      OS="ALPINE" ;;
    VOID)        OS="VOID" ;;
esac  

# Operating system must be one of the valid ones
if [[ ${ValidOS^^} != *${OS^^}* ]]; then
   printf "\n\n********** [${REALOS^^}] Is An Invalid OS. *******\n\n\n";
   exit 1
fi

#=======================================
# Add script directory
#=======================================
if [[ ! -d /$HDIR/scripts ]]; then
   printf "\n\n********** Script Directory does NOT exist. *******\n\n\n";
   exit 1
fi

#=======================================
# Ensure we have the proper working 
# directories
#=======================================
cd $HDIR/scripts
if [[ ! -d /$HDIR/scripts/skipdir ]]; then mkdir -p /$HDIR/scripts/skipdir >/dev/null; fi

#=======================================
# Include the proper source files
#=======================================
source base.sh
case ${OS^^} in
  'ALPINE') source alpine.sh 1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
    'ARCH') source arch.sh   1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
    'VOID') source void.sh   1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
  'DEBIAN') source debian.sh 1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
esac

#=======================================
# Main Code - Start
#=======================================
if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
if [[ -f ${HDIR}/error.tmp ]]; then _run "rm -f ${HDIR}/error.tmp"; fi
if [[ ! -f ${LOG} ]]; then _run "touch ${LOG}"; fi
_run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

#=======================================
# Install Prerequisites
#=======================================
if [[ ! -f $HDIR/scripts/skipdir/.prereq ]]; then 
   printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n";
   _prereqs;  
fi

#=======================================
# Detect if device is a laptop
#=======================================
DEVICE=$(dmidecode -s chassis-type 2>${HDIR}/error.tmp || errHandler)
DEVTYPE=${DEVICE^^}
case ${DEVTYPE^^} in
  'NOTEBOOK') DEVTYPE="LAPTOP" ;;
  'PORTABLE') DEVTYPE="LAPTOP" ;;
  'HAND HELD') DEVTYPE="LAPTOP" ;;
  'SUB NOTEBOOK') DEVTYPE="LAPTOP" ;;
esac

#=======================================
# Get Memory Size
#=======================================
MEMSIZE=$(dmidecode | grep 'Maximum Capacity:' | cut -d ' ' -f3)

#=======================================
# Get Desktop Environment
#=======================================
DSKTOPENV=$(echo "$XDG_CURRENT_DESKTOP")
case ${DSKTOPENV^^} in
   'X-CINNAMON') DSKTOPENV="CINNAMON" ;;
esac

#=======================================
# Print out the Main Title
#=======================================
_title

#=======================================
# Process Main Menu
#=======================================
while [[ ${STP^^} != "99" ]]
do
   _main_menu
   case ${STP^^} in
      1) _main_desktop ;;
      2) _main_server ;;
      3) _process_update ;;
     99) break ;;
   esac
   if [ ${STP^^} != "99" ]; then STP="777"; fi
done