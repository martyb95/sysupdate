#!/bin/bash

#=========================================================
#      Color Codes
#=========================================================
RESTORE='\033[0m'
BLACK='\033[00;30m'
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;93m'
BROWN='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
WHITE='\033[01;97m'
LGRAY='\033[00;37m'
LRED='\033[01;91m'
LGREEN='\033[01;92m'
LYELLOW='\033[01;93m'
LBLUE='\033[01;94m'
LPURPLE='\033[01;95m'
LCYAN='\033[01;96m'
OVERWRITE='\e[1A\e[K'

# script must be run as root
if [[ $(id -u) -ne 0 ]] ; then
   printf "\n\n${LRED}*************** Please run as root ***************${RESTORE}\n\n\n"
   exit 1
fi

#=======================================
# Global Variables
#=======================================
HDIR="/home/${SUDO_USER}"
LOG="${HDIR}/update.log"
FN="main()"
VER="3.83"

OS=""
REALOS=""
ValidOS="ALPINE,VOID,ARCH,DEBIAN"

#========================================================
#    Application Functions
#========================================================
function errHandler {
  local ERRCMD="$1"
  local ERRMSG=$(cat ${HDIR}/error.tmp)
  TIMESTAMP="2025-12-20 14:23:52"
  printf "\n\n========= $TIMESTAMP =====================================================\n" >> ${LOG}
  printf "  ERROR - ${ERRMSG}\n" >> ${LOG}
  printf "          COMMAND:     ${ERRCMD}\n" >> ${LOG}
  printf "          FUNCTION:    ${FN}\n" >> ${LOG}
  printf "          LINE NUMBER: ${BASH_LINENO}\n" >> ${LOG}
  printf "===================================================================================\n" >> ${LOG}
  rm -f ${HDIR}/error.tmp 2>&1>/dev/null
}

function clean_exit {
   clear
   goto "1" "1"
   printf "\n\n   ${LRED}System Update had an Abnormal Exit\n    Ctrl-C detected!!!${RESTORE}\n\n"
   tput cnorm   # normal cursor
   unset DSKOPT
   unset DSKSTYL
   unset DSKTYP
   unset MAIN
   exit -2
}

function showMain {
   _title
   drawMenu MAIN
   processMenu MAIN
}

function dummyFunction {
  echo "in Dummy Function"
}

function desktopMenu {
   clr_screen "2"
   DSK=""
   LAY=""
   COLOR=""
   _title
   drawMenu DSKTYP
   processMenu DSKTYP
   clr_screen "2"
   _title
   drawMenu MAIN
}

function styleMenu {
   clr_screen "2"
   _title
   if [[ ${SELECT^^} == "CINNAMON DESKTOP" ]]; then
      DSK="CINNAMON"
      DSKSTYL[title]="Cinnamon Menu"
      DSKSTYL[menu]="Default Cinnamon Style;FUNC;optionsMenu~Previous Menu;QUIT;"
   elif [[ ${SELECT^^} == "GNOME DESKTOP" ]]; then
      DSK="GNOME"
      DSKSTYL[title]="Gnome Menu"
      DSKSTYL[menu]="Default Gnome Style;FUNC;optionsMenu~Previous Menu;QUIT;"
   elif [[ ${SELECT^^} == "KDE PLASMA DESKTOP" ]]; then
      DSK="KDE"
      DSKSTYL[title]="KDE Plasma Menu"
      DSKSTYL[menu]="Default KDE Style;FUNC;optionsMenu~Previous Menu;QUIT;"
   else
      DSK="XFCE"
      DSKSTYL[title]="XFCE Menu"
      DSKSTYL[menu]="Top Menu-Yellow;FUNC;optionsMenu~Top Menu-Blue;FUNC;optionsMenu~Top Menu-Green;FUNC;optionsMenu~Bottom Menu-Yellow;FUNC;optionsMenu~Bottom Menu-Blue;FUNC;optionsMenu~Bottom Menu-Green;FUNC;optionsMenu~Previous Menu;QUIT;"
   fi

   drawMenu DSKSTYL
   processMenu DSKSTYL
   clr_screen "2"
   _title
   drawMenu DSKTYP
}

function optionsMenu {
   clr_screen "2"
   _title

   LAY=$(echo "${SELECT^^}" | grep -oh "TOP")
   if [[ -z $LAY ]]; then LAY=$(echo "${SELECT^^}" | grep -oh "BOTTOM"); fi
   if [[ -z $LAY ]]; then LAY="DEFAULT"; fi

   COLOR=$(echo "${SELECT^^}" | grep -oh "YELLOW")
   if [[ -z $COLOR ]]; then COLOR=$(echo "${SELECT^^}" | grep -oh "BLUE"); fi
   if [[ -z $COLOR ]]; then COLOR=$(echo "${SELECT^^}" | grep -oh "GREEN"); fi
   if [[ -z $COLOR ]]; then COLOR="DEFAULT"; fi
   _parm_out

   DSKOPT[title]="Desktop Setup Menu"
   DSKOPT[menu]="1. Install Desktop Files;FUNC;_process_step_1~2. Install Apps;FUNC;_process_step_2~3. Customize Desktop;FUNC;_process_step_3~Previous Menu;QUIT;"

   drawMenu DSKOPT
   goto "26" "1"
   processMenu DSKOPT
   clr_screen "2"
   _title
   drawMenu DSKSTYL
}

function setupMenus {
   MAIN[row]=17
   MAIN[column]=18
   MAIN[title]="Main Update Menu"
   #MAIN[shadow]=true
   MAIN[color]="$(($FG_YELLOW+$BRIGHT));$(($BG_BLUE+$BRIGHT))"
   MAIN[hilite]="$(($FG_BLUE+$BRIGHT));$(($BG_WHITE))"
   MAIN[menu]="Setup Desktop Environment;FUNC;desktopMenu~Setup Server Environment;FUNC;optionsMenu~Update Packages;FUNC;optionsMenu~Quit;QUIT;"

   DSKTYP[row]=17
   DSKTYP[column]=18
   DSKTYP[title]="Desktop Setup"
   #DSKTYP[shadow]=true
   DSKTYP[color]="$(($FG_YELLOW+$BRIGHT));$(($BG_BLUE+$BRIGHT))"
   DSKTYP[hilite]="$(($FG_BLUE+$BRIGHT));$(($BG_WHITE))"
   DSKTYP[menu]="XFCE Desktop;FUNC;styleMenu~Cinnamon Desktop;FUNC;styleMenu~Gnome Desktop;FUNC;styleMenu~KDE Plasma Desktop;FUNC;styleMenu~Previous Menu;QUIT;"

   DSKSTYL[row]=17
   DSKSTYL[column]=18
   #DSKSTYL[shadow]=true
   DSKSTYL[color]="$(($FG_YELLOW+$BRIGHT));$(($BG_BLUE+$BRIGHT))"
   DSKSTYL[hilite]="$(($FG_BLUE+$BRIGHT));$(($BG_WHITE))"

   DSKOPT[row]=17
   DSKOPT[column]=18
   #DSKOPT[shadow]=true
   DSKOPT[color]="$(($FG_YELLOW+$BRIGHT));$(($BG_BLUE+$BRIGHT))"
   DSKOPT[hilite]="$(($FG_BLUE+$BRIGHT));$(($BG_WHITE))"
}  

#=======================================
# Get OS Name
#=======================================
if [[ -f /etc/os-release ]]; then
   # On Linux systems
   source /etc/os-release
   REALOS=$( echo $ID )
else
   # On systems other than Linux (e.g. Mac or FreeBSD)
   REALOS=$( uname )
fi

OS="UNKNOWN"
case ${REALOS^^} in
    DEBIAN)      OS="DEBIAN" ;;
    ELEMENTARY)  OS="DEBIAN" ;;
    BUNSENLABS)  OS="DEBIAN" ;;
    LINUXMINT)   OS="DEBIAN" ;;
    SPARKY)      OS="DEBIAN" ;;
    UBUNTU)      OS="DEBIAN" ;;
    LBUNTU)      OS="DEBIAN" ;;
    XBUNTU)      OS="DEBIAN" ;;
    ZORIN)       OS="DEBIAN" ;;
    ALPINE)      OS="ALPINE" ;;
    VOID)        OS="VOID" ;;
esac  

# Operating system must be one of the valid ones
if [[ ${ValidOS^^} != *${OS^^}* ]]; then
   printf "\n\n********** [${REALOS^^}] Is An Invalid OS. *******\n\n\n";
   exit 1
fi

#==============================================
# Ensure we have the proper working directories
#==============================================
if [[ ! -d /$HDIR/scripts ]]; then mkdir -p /$HDIR/scripts >/dev/null; fi
if [[ ! -d /$HDIR/scripts/skipdir ]]; then mkdir -p /$HDIR/scripts/skipdir >/dev/null; fi

#=======================================
# Include the proper source files
#=======================================
source base.sh
source ansi.sh

case ${OS^^} in
  'ALPINE') source alpine.sh 1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
    'ARCH') source arch.sh   1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
    'VOID') source void.sh   1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
  'DEBIAN') source debian.sh 1>/dev/null 2>${HDIR}/error.tmp || errHandler ;;
esac

#=======================================
# Main Code - Start
#=======================================
if [[ -f ${LOG} ]]; then _run "rm -f ${LOG}"; fi
if [[ -f ${HDIR}/error.tmp ]]; then _run "rm -f ${HDIR}/error.tmp"; fi
_run "touch ${LOG}"
_run "chown ${SUDO_USER}:${SUDO_USER} ${LOG}"

#=======================================
# Install Prerequisites
#=======================================
if [[ ! -f $HDIR/scripts/skipdir/.prereq ]]; then 
   printf "\n  ${YELLOW}Install Prerequisites${RESTORE}\n\n";
   _prereqs;  
fi

#=======================================
# Detect if device is a laptop
#=======================================
DEVICE=$(dmidecode -s chassis-type 2>${HDIR}/error.tmp || errHandler)
DEVTYPE=${DEVICE^^}
case ${DEVTYPE^^} in
  'NOTEBOOK') DEVTYPE="LAPTOP" ;;
  'PORTABLE') DEVTYPE="LAPTOP" ;;
  'HAND HELD') DEVTYPE="LAPTOP" ;;
  'SUB NOTEBOOK') DEVTYPE="LAPTOP" ;;
esac

#=======================================
# Get Memory Size
#=======================================
MEMSIZE=$(dmidecode | grep 'Maximum Capacity:' | cut -d ' ' -f3)

#=======================================
# Get Desktop Environment
#=======================================
DSKTOPENV=$(echo "$XDG_CURRENT_DESKTOP")
case ${DSKTOPENV^^} in
   'X-CINNAMON') DSKTOPENV="CINNAMON" ;;
esac


#======================================
# Start of Program
#======================================
declare -A MAIN="($(newWin))"
declare -A DSKTYP="($(newWin))"
declare -A DSKSTYL="($(newWin))"
declare -A DSKOPT="($(newWin))"
trap 'clean_exit' SIGINT

#=======================================
# Print out the Main Title
#=======================================
setupMenus
showMain

#=======================================
# Cleanup before close
#=======================================
unset DSKOPT
unset DSKSTYL
unset DSKTYP
unset MAIN
goto "25" "1"
clr_screen
goto "26" "1"

