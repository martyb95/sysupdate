#!/usr/bin/env bash

ERRMSG=""
LASTRN=""
ERRTMP="error.tmp"
LOGFIL="error.log"

set -o functrace
trap 'LASTFN="$FUNCNAME"' RETURN
trap 'err_handler' ERR
exec 2>error.tmp

function err_handler {
  ERRMSG=$(cat ${ERRTMP})
  TIMESTAMP="2025-12-20 14:23:52"
  printf "\n\n========= $TIMESTAMP =====================================================\n" >> ${LOGFIL}
  printf "  ERROR - $ERRMSG\n" >> ${LOGFIL}
  printf "          SOURCE FILE: ${BASH_SOURCE}\n" >> ${LOGFIL}
  printf "          LINE NUMBER: ${BASH_LINENO}\n" >> ${LOGFIL}
  printf "          FUNCTION:    ${LASTFN}\n" >> ${LOGFIL}
  printf "          COMMAND:     ${BASH_COMMAND}\n" >> ${LOGFIL}
  printf "===================================================================================\n" >> ${LOGFIL}
  rm ${ERRTMP} 2>&1
}

function test_func {
  rm /root/test.fil
}

test_func
echo "end of test"